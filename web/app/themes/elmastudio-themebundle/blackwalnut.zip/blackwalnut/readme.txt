
----------------------------------------------------------------------------------------------------------------------------

For the detailed theme documentation please visit:
http://www.elmastudio.de/en/themes/blackwalnut/ (English) or http://www.elmastudio.de/wordpress-themes/blackwalnut/ (German)

Please use the the Elmastudio theme forum: http://themeforum.elmastudio.de/ to ask all questions regarding the Black Walnut theme.

----------------------------------------------------------------------------------------------------------------------------


Changelog:

Version 1.0.3 (12/03/2017)
----------------------------------------------------------------------------------------------------------------------------
- New: Support for the One Click Demo Import plugin.


Version 1.0.2 (19/08/2015)
----------------------------------------------------------------------------------------------------------------------------
- Bug Fix: Update of inc/widget.php file to make theme WordPress 4.3 compatible (see inc/widgets.php)
- Bugfix: smaller CSS bugfixes in style.css
- Bugfix: Fixed image link hover error on Front Page Two
- Security Improvement: Genericons icon font update to version 3.3.1


Version 1.0.1 (26/04/2015)
----------------------------------------------------------------------------------------------------------------------------
- New: Support for logo image
- Bugfix: CSS for light slogan color on big image front page
- Bugfix: Hide Header title + tagline text
- Bugfix: Update of js/functions.js to optimize smooth scroll to top
- Enhancement: image link hovers on front page templates


Version 1.0 (21/04/2015)
----------------------------------------------------------------------------------------------------------------------------
- Black Walnut first theme release
