
-----------------------------------------------------------------------------------------------------------------------

For a detailed theme documentation + video tutorials please visit:
https://www.elmastudio.de/en/themes/namba/ (English) or https://www.elmastudio.de/wordpress-themes/namba/ (German)

Questions about Namba can be asked in the Elmastudio theme forum.

-----------------------------------------------------------------------------------------------------------------------


Version 1.1.2 (17/03/2017)
----------------------------------------------------------------------------------------------------------------------------
- New: Support for the One Click Demo Import plugin.
- Bugfix: Updated all links to https.


Version 1.1.1 (19/08/2015)
----------------------------------------------------------------------------------------------------------------------------
-Bug Fix: Update of inc/widget.php file to make theme WordPress 4.3 compatible (see inc/widgets.php)


Version 1.1 (February 20th 2014)
----------------------------------------------------------------------------------------------------------------------------
- New: Single Column blog layout option (inc/theme-options.php, style.css)
- Bugfix: Minor CSS bugfixes (style.css)
- Bugfix: Link font sizes in link post format. Please use the CSS class .link for your main post format link.
- Bugfix: Fixed 2-column layout of Recent Post by Category Widget
- Bugfix: Deleted footer logo, due to errors resulting from the custom logo in the footer
- Enhancement: Minor font size adjustments (style.css)
- Enhancement: Update to latest version of js/imagesloaded.js


Version 1.0.1 (December 1th 2013)
----------------------------------------------------------------------------------------------------------------------------
- Bugfix: Fixed height issue for embedded iframe videos (see functions.php, js/functtions.js/style.css)
	Please use an extra div container with the CSS class of video-wrapper to ensure that videos are responsive.
	e.g. <div class="video-wrapper"><iframe>...</iframe></div>
- Bugfix: Minor CSS bug fixes (see style.css)
- Bugfix: Fixed layout error on search result page (see search.php, style.css)
- Bugfix: Update for Editor Styles (see css/editor-style.css)
- Enhancement: Pagination for Single Posts (see single.php, style.css)
- Enhancement: Optimized Search form and Jetpack Subscribe for left sidebar (see style.css)


Version 1.0 (November 18th 2013)
----------------------------------------------------------------------------------------------------------------------------
- Namba theme release
