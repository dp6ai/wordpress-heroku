/* global screenReaderText */
/**
 * Theme functions file.
 *
 * Contains handlers for navigation and widget area.
 *
 * @version 1.0
 */

( function($) {
	var $body, $window, $sidebar, adminbarOffset, top = false,
	    bottom = false, windowWidth, windowHeight, lastWindowPos = 0,
	    topOffset = 0, bodyHeight, sidebarHeight, resizeTimer,
		secondary, button;

	// Overlay (main menu + widget area) open/close
	$('.overlay-open').on( 'click', function () {
		$('html').addClass('overlay-show');
		$('body').addClass('overlay-show');
    });

    $('#overlay-close').on( 'click', function () {
		$('html').removeClass('overlay-show');
		$('body').removeClass('overlay-show');
    });
   
   // Hide Desktop Off Canvas Menu on Click into main website area
    $('#overlay-wrap').on( 'click', function () {
	    $('html').removeClass('overlay-show');
		$('body').removeClass('overlay-show');
    });

    // Mobile Widget Area open/close
    $('#offcanvas-widgets-open').on( 'click', function () {
		$( "#sidebar-offcanvas" ).slideToggle( "fast", function() {
  		});
    });

    // Desktio Search open/close
    $('.search-open').on( 'click', function () {
		$( ".desktop-search" ).slideToggle( "fast", function() {
  		});
    });

	// Fade in Featured Images
	$(document).ready(function() {
		if ( window.innerWidth >= 1060 ) {
			$('body').toggleClass('imgfade-on');
		$('.fadein').viewportChecker({
		    classToAdd: 'inview', // Class to add to the elements when they are visible
		    offset: 100,
		    removeClassAfterAnimation: true
		   });
		}
	});

	// Sticky Desktop Header Bar
	$(function() {
		var stickyheader = $('.sticky-header');
	    $(window).scroll(function() {
	        var scroll = $(window).scrollTop();
	
	        if (scroll >= 158) {
	            $('body').addClass('header-stick');
	            stickyheader.removeClass('hidden');
	        } else {
	            $('body').removeClass('header-stick');
	            stickyheader.addClass('hidden');
	        }
	    });
	});


	// Sticky Last Sidebar Element
	$(document).ready(function() {
	if ( window.innerWidth >= 1060 ) {
		$(".blog #secondary .widget:last-child").stick_in_parent({
			parent: "#blog-wrap",
			offset_top: 80
		});
	}
	});

	// Sticky Last Sidebar Element - Single Post
	$(document).ready(function() {
	if ( window.innerWidth >= 1060 ) {
	$(".single-post #secondary .widget:last-child").stick_in_parent({
		parent: "#singlepost-wrap",
		offset_top: 80
		});
	}
	});

	// Sticky Share Buttons - Single Post
	$(document).ready(function() {
	if ( window.innerWidth >= 1440 ) {
	$(".sd-content").stick_in_parent({
		parent: "#socialicons-sticky",
		offset_top: 80
		});
	}
	});
	
	// Responsive Videos.
	$('#primary').fitVids();
	$('#singlepost-wrap').fitVids();

    // Add dropdown toggle that display child menu items.
	$( '.menu-item-has-children > a' ).after( '<button class="dropdown-toggle" aria-expanded="false">' + screenReaderText.expand + '</button>' );

	// Toggle buttons and submenu items with active children menu items.
	$( '.current-menu-ancestor > button' ).addClass( 'toggle-on' );
	$( '.current-menu-ancestor > .sub-menu' ).addClass( 'toggled-on' );

	$( '.dropdown-toggle' ).click( function( e ) {
		var _this = $( this );
		e.preventDefault();
		_this.toggleClass( 'toggle-on' );
		_this.next( '.children, .sub-menu' ).toggleClass( 'toggled-on' );
		_this.attr( 'aria-expanded', _this.attr( 'aria-expanded' ) === 'false' ? 'true' : 'false' );
		_this.html( _this.html() === screenReaderText.expand ? screenReaderText.collapse : screenReaderText.expand );
	} );

	secondary = $( '#secondary' );
	button = $( '.site-branding' ).find( '.secondary-toggle' );

	// Enable menu toggle for small screens.
	( function() {
		var menu, widgets, social;
		if ( ! secondary || ! button ) {
			return;
		}

		// Hide button if there are no widgets and the menus are missing or empty.
		menu    = secondary.find( '.nav-menu' );
		widgets = secondary.find( '#widget-area' );
		social  = secondary.find( '#social-navigation' );
		if ( ! widgets.length && ! social.length && ( ! menu || ! menu.children().length ) ) {
			button.hide();
			return;
		}

		button.on( 'click.uku-light', function() {
			secondary.toggleClass( 'toggled-on' );
			secondary.trigger( 'resize' );
			$( this ).toggleClass( 'toggled-on' );
			if ( $( this, secondary ).hasClass( 'toggled-on' ) ) {
				$( this ).attr( 'aria-expanded', 'true' );
				secondary.attr( 'aria-expanded', 'true' );
			} else {
				$( this ).attr( 'aria-expanded', 'false' );
				secondary.attr( 'aria-expanded', 'false' );
			}
		} );
	} )();
	
	
	
	
	

} )( jQuery );

