<?php
/**
 * The Header for our theme
 *
 * Displays all of the <head> section and everything up till <div id="overlay-wrap">
 *
 * @package Uku Light
 * @since Uku Light 1.0
 * @version 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

	<header id="masthead" class="site-header cf" role="banner">

		<div id="site-branding">
			<?php if ( is_front_page() ) : ?>
				<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
			<?php else : ?>
				<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
			<?php endif; ?>
			
			<?php if (  '' != get_theme_mod( 'custom_logo' ) ) : ?>
			 <div class="custom-logo-wrap">
			 	<?php uku_light_the_custom_logo(); ?>
			 </div><!-- end .custom-logo-wrap -->
			 <?php endif; ?>

			<p class="site-description"><?php bloginfo( 'description' ); ?></p>
			<button id="overlay-open" class="overlay-open overlay-btn"><span><?php esc_html_e( 'Menu', 'uku-light' ); ?></span></button>
			<?php if (has_nav_menu( 'social' ) ) : ?>
				<nav id="header-social" class="header-social social-nav" role="navigation">
				<?php wp_nav_menu( array(
					'theme_location'	=> 'social',
					'container' 		=> 'false',
					'depth' 			=> -1));
				?>
				</nav><!-- end #header-social -->
			<?php endif; ?>
		</div><!-- end #site-branding -->

		<nav id="desktop-navigation" class="desktop-navigation cf" role="navigation">
			<?php
				wp_nav_menu( array(
					'theme_location'	=> 'primary',
					'container' 		=> false,));
			?>
		</nav><!-- .main-navigation -->

		<?php if ( '' == get_theme_mod( 'uku-light_hidesearch' ) ) : ?>
		<button id="search-open" class="search-open search-btn"><span><?php esc_html_e( 'Search', 'uku-light' ); ?></span></button>
			<div class="desktop-search">
				<?php get_search_form(); ?>
			</div><!-- end .desktop-search -->
		<?php endif; ?>

		<div class="sticky-header hidden">
			<button id="overlay-open-sticky" class="overlay-open overlay-btn"><span><?php esc_html_e( 'Menu', 'uku-light' ); ?></span></button>
			<?php if ( '' == get_theme_mod( 'uku-light_hidesearch' ) ) : ?>
				<button id="search-open-sticky" class="search-open search-btn"><span><?php esc_html_e( 'Search', 'uku-light' ); ?></span></button>
			<?php endif; ?>
			
			<?php if (  '' != get_theme_mod( 'custom_logo' ) ) : ?>
			 <div class="custom-logo-wrap">
			 	<?php uku_light_the_custom_logo(); ?>
			 </div><!-- end .custom-logo-wrap -->
			<?php else : ?>
				<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
			<?php endif; ?>

			<?php if (has_nav_menu( 'social' ) ) : ?>
				<nav id="header-social-sticky" class="header-social social-nav" role="navigation">
					<?php wp_nav_menu( array(
						'theme_location'	=> 'social',
						'container' 		=> 'false',
						'depth' 			=> -1));
					?>
				</nav><!-- end #header-social-sticky -->
			<?php endif; ?>
		</div><!-- end .sticky-header -->

			<div class="inner-offcanvas-wrap">
				<div class="close-btn-wrap">
					<button id="overlay-close" class="overlay-btn"><span><?php esc_attr_e( 'Close', 'uku-light' ); ?></span></button>
				</div><!-- end .close-btn-wrap -->
	
				<?php if ( '' == get_theme_mod( 'uku-light_hidesearch' ) ) : ?>
				<div class="mobile-search">
					<?php get_search_form(); ?>
				</div><!-- end .mobile-search -->
				<?php endif; ?>
	
				<?php if (has_nav_menu( 'social' ) ) : ?>
					<nav id="mobile-social" class="social-nav" role="navigation">
					<?php wp_nav_menu( array(
						'theme_location'	=> 'social',
						'container' 		=> 'false',
						'depth' 			=> -1));
					?>
					</nav><!-- end #mobile-social -->
				<?php endif; ?>

				<nav id="overlay-nav" class="main-nav cf" role="navigation">
				<?php
					wp_nav_menu( array(
						'theme_location'	=> 'primary',
						'container' 		=> false,));
				?>
				</nav><!-- .main-navigation -->
	
				<?php get_sidebar( 'offcanvas' ); ?>

			</div><!-- end .desktop-offcanvas-wrap -->
	</header><!-- end #masthead -->

	<div id="overlay-wrap" class="overlay-wrap cf"></div><!-- end #overlay-wrap -->

	<?php if ( get_header_image()  && is_front_page() ) : ?>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" class="header-image"><img src="<?php header_image(); ?>" width="<?php echo get_custom_header()->width; ?>" height="<?php echo get_custom_header()->height; ?>" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"></a>
	<?php endif; ?>
	