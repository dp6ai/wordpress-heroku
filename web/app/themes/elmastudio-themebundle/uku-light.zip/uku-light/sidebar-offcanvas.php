<?php
/**
 * The template for the off canvas widget areas
 *
 * @package Uku Light
 * @since Uku Light 1.0
 * @version 1.0
 */

if ( ! is_active_sidebar( 'sidebar-offcanvas' ) ) {
	return;
}

// If we get this far, we have widgets. Let's do this.
?>

<button id="offcanvas-widgets-open"><span><?php esc_html_e( 'More Info', 'uku-light' ); ?></span></button>
<aside id="sidebar-offcanvas" class="sidebar-offcanvas cf" role="complementary">
	<?php if ( is_active_sidebar( 'sidebar-offcanvas' ) ) : ?>
		<div class="widget-area">
			<?php dynamic_sidebar( 'sidebar-offcanvas' ); ?>
		</div><!-- .widget-area -->
	<?php endif; ?>

</aside><!-- .sidebar-offcanvas -->
