<?php
/**
 * The template for displaying the footer.
 *
 * @package Uku Light
 * @since Uku Light 1.0
 * @version 1.0
 */
?>

<footer id="colophon" class="site-footer cf">

	<div class="footer-wrap">
		<p class="title-footer"><?php bloginfo( 'name' ); ?></p>
	<?php // Footer Menus.
	if ( has_nav_menu( 'footer-one' ) || has_nav_menu( 'footer-two' ) || has_nav_menu( 'footer-three' ) || has_nav_menu( 'footer-four' ) ) : ?>
		<?php get_template_part( 'template-parts/footermenus' ); ?>
	<?php endif; ?>

	<div id="site-info" class="cf">
		<ul class="credit" role="contentinfo">
		<?php if ( get_theme_mod( 'uku-light_credit' ) ) : ?>
			<li><?php echo wp_kses_post( get_theme_mod( 'uku-light_credit' ) ); ?></li>
		<?php else : ?>
			<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'uku-light' ) ); ?>"><?php printf( esc_html__( 'Proudly powered by %s', 'uku-light' ), 'WordPress' ); ?></a>
			<span class="sep"> | </span>
			<?php printf( esc_html__( 'Theme: %1$s by %2$s.', 'uku-light' ), 'Uku Light', '<a href="http://www.elmastudio.de/en/">Elmastudio</a>' ); ?>
		<?php endif; ?>
		</ul><!-- end .credit -->
	</div><!-- end #site-info -->

	<?php if (has_nav_menu( 'social' ) ) : ?>
	<nav id="footer-social" class="social-nav" role="navigation">
		<span><?php esc_html_e( 'Follow us', 'uku-light' ); ?></span>
		<?php wp_nav_menu( array(
			'theme_location'	=> 'social',
			'container' 		=> 'false',
			'depth' 			=> -1));  ?>
	</nav><!-- end #footer-social -->
	<?php endif; ?>

	</div><!-- end .footer-wrap -->
</footer><!-- end #colophon -->

<?php wp_footer(); ?>

</body>
</html>
