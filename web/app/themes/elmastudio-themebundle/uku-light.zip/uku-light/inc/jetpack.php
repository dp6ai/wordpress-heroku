<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package Uku Light
 * @since Uku Light 1.0
 * @version 1.0
 */

function uku_light_jetpack_setup() {

	/**
		* Add theme support for Infinite Scroll.
 	*/
	add_theme_support( 'infinite-scroll', array(
		 'type'           => 'click',
		'container' 		=> 'primary',
		'wrapper'        => true,
	) );

}
add_action( 'after_setup_theme', 'uku_light_jetpack_setup' );
