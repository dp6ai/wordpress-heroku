<?php
/**
 * Implement Theme Customizer additions and adjustments.
 *
 * @package Uku Light
 * @since Uku Light 1.0
 * @version 1.0
 */

function uku_light_customize_register( $wp_customize ) {   

	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';

	// Rename the label to "Site Title Color" because this only affects the site title in this theme.
	$wp_customize->get_control( 'header_textcolor' )->label = esc_html__( 'Site Title Color', 'uku-light' );

	// Custom Uku Light panels:
	$wp_customize->add_panel( 'uku_light_themeoptions', array(
		'priority'       	=> 1,
		'theme_supports' 	=> '',
		'title'          	=> esc_html__('Theme Options', 'uku-light'),
	) );

	// Uku Light Theme Options Sections:
	$wp_customize->add_section( 'uku_light_general', array(
		'title'        		=> esc_html__( 'General', 'uku-light' ),
		'priority'      	=> 1,
		'panel'  			=> 'uku_light_themeoptions',
	) );

	$wp_customize->add_section( 'uku_light_header', array(
		'title'        		=> esc_html__( 'Header', 'uku-light' ),
		'priority'      	=> 2,
		'panel'  			=> 'uku_light_themeoptions',
	) );
	
	$wp_customize->add_section( 'uku_light_images', array(
		'title'        		=> esc_html__( 'Images', 'uku-light' ),
		'priority'      	=> 3,
		'panel'  			=> 'uku_light_themeoptions',
	) );

	// Uku Light Custom Colors.
	$wp_customize->add_setting( 'uku_light_link_color' , array(
    	'default'     		=> '#51a8dd',
    	'sanitize_callback' => 'sanitize_hex_color',
		'transport'   		=> 'refresh',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'uku_light_link_color', array(
		'label'				=> esc_html__( 'Link Color', 'uku-light' ),
		'section'			=> 'colors',
		'settings'			=> 'uku_light_link_color',
	) ) );
	
	$wp_customize->add_setting( 'uku_light_linkhover_color' , array(
    	'default'     		=> '#0c6ca6',
    	'sanitize_callback' => 'sanitize_hex_color',
		'transport'   		=> 'refresh',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'uku_light_linkhover_color', array(
		'label'				=> esc_html__( 'Link Hover Color', 'uku-light' ),
		'section'			=> 'colors',
		'settings'			=> 'uku_light_linkhover_color',
	) ) );

	$wp_customize->add_setting( 'uku_light_footer_bg_color' , array(
    	'default'     		=> '#1a1a1a',
    	'sanitize_callback' => 'sanitize_hex_color',
		'transport'   		=> 'refresh',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'uku_light_footer_bg_color', array(
		'label'				=> esc_html__( 'Footer Background Color', 'uku-light' ),
		'section'			=> 'colors',
		'settings'			=> 'uku_light_footer_bg_color',
	) ) );

	$wp_customize->add_setting( 'uku_light_offcanvas_bg_color' , array(
    	'default'     		=> '#f4f4f4',
    	'sanitize_callback' => 'sanitize_hex_color',
		'transport'   		=> 'refresh',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'uku_light_offcanvas_bg_color', array(
		'label'				=> esc_html__( 'Off Canvas Background Color', 'uku-light' ),
		'section'			=> 'colors',
		'settings'			=> 'uku_light_offcanvas_bg_color',
	) ) );
	
	$wp_customize->add_setting( 'uku_light_offcanvas_text_color' , array(
    	'default'     		=> '#2b2b2b',
    	'sanitize_callback' => 'sanitize_hex_color',
		'transport'   		=> 'refresh',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'uku_light_offcanvas_text_color', array(
		'label'				=> esc_html__( 'Off Canvas Text Color', 'uku-light' ),
		'section'			=> 'colors',
		'settings'			=> 'uku_light_offcanvas_text_color',
	) ) );

	// Uku Light Custom Header - Additional Style Option
	$wp_customize->add_setting( 'uku_light_headerstyle', array(
		'default'      		=> 'header-fullwidth',
		'sanitize_callback' => 'uku_light_sanitize_headerstyle',
	) );

	$wp_customize->add_control( 'uku_light_headerstyle', array(
		'label'         	=> esc_html__( 'Header Image Style', 'uku-light' ),
		'description'		=> esc_html__( 'Choose the Header image style you like to use.', 'uku-light' ),
		'section'       	=> 'header_image',
		'priority'      	=> 10,
		'type'          	=> 'select',
		'choices' 			=> array(
        	'header-fullwidth' 	=> esc_html__( 'fullwidth', 'uku-light' ),
        	'header-boxed' 		=> esc_html__( 'boxed', 'uku-light' ),
        	'header-fullscreen' => esc_html__( 'fullscreen', 'uku-light' ),
		),
	) );

	// Uku Light Theme Options - General
	$wp_customize->add_setting( 'uku_light_sidebar', array(
		'default'      		=> 'sidebar-right',
		'sanitize_callback' => 'uku_light_sanitize_sidebar',
	) );

	$wp_customize->add_control( 'uku_light_sidebar', array(
		'label'         	=> esc_html__( 'Sidebar position', 'uku-light' ),
		'section'       	=> 'uku_light_general',
		'priority'      	=> 1,
		'type'          	=> 'select',
		'choices' 			=> array(
        	'sidebar-right' 	=> esc_html__( 'sidebar right', 'uku-light' ),
        	'sidebar-left' 		=> esc_html__( 'sidebar left', 'uku-light' ),
        	'sidebar-no'  		=> esc_html__( 'no sidebar', 'uku-light' ),
		),
	) );

	$wp_customize->add_setting( 'uku_light_credit', array(
		'default'       	=> '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'uku_light_credit', array(
		'label'         	=> esc_html__( 'Footer credit text', 'uku-light' ),
		'description'		=> esc_html__( 'Customize the footer credit text. (HTML is allowed)', 'uku-light' ),
		'section'       	=> 'uku_light_general',
		'type'          	=> 'text',
		'priority'			=> 3,
	) );
	
	// Uku Light Theme Options - Header
	$wp_customize->add_setting( 'uku_light_hidesearch', array(
		'default'			=> '',
		'sanitize_callback' => 'uku_light_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'uku_light_hidesearch', array(
		'label'				=> esc_html__( 'Hide search in Header', 'uku-light' ),
		'section'			=> 'uku_light_header',
		'type'				=> 'checkbox',
		'priority'			=> 1,
	) );

	$wp_customize->add_setting( 'uku_light_header_font', array(
		'default'      		=> 'dark',
		'sanitize_callback' => 'uku_light_sanitize_header_font',
	) );

	$wp_customize->add_control( 'uku_light_header_font', array(
		'label'         	=> esc_html__( 'Header Font', 'uku-light' ),
		'description'		=> esc_html__( '(You can choose the light header font in combination with the fullscreen header image or fullscreen slider style.)', 'uku-light' ),
		'section'       	=> 'uku_light_header',
		'priority'      	=> 2,
		'type'          	=> 'select',
		'choices' 			=> array(
        	'light' 	=> esc_html__( 'light', 'uku-light' ),
        	'dark' 		=> esc_html__( 'dark', 'uku-light' ),
		),
	) );

	$wp_customize->add_setting( 'uku_light_fixedheader_style', array(
		'default'      		=> 'light',
		'sanitize_callback' => 'uku_light_sanitize_fixedheader_style',
	) );

	$wp_customize->add_control( 'uku_light_fixedheader_style', array(
		'label'         	=> esc_html__( 'Fix-positioned Header style', 'uku-light' ),
		'description'		=> esc_html__( '(Choose a dark or light colored fix-positioned header bar.)', 'uku-light' ),
		'section'       	=> 'uku_light_header',
		'priority'      	=> 3,
		'type'          	=> 'select',
		'choices' 			=> array(
        	'light' 	=> esc_html__( 'light', 'uku-light' ),
        	'dark' 		=> esc_html__( 'dark', 'uku-light' ),
		),
	) );

	$wp_customize->add_setting( 'uku_light_fixedheader', array(
		'default'			=> '',
		'sanitize_callback' => 'uku_light_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'uku_light_fixedheader', array(
		'label'				=> esc_html__( 'Hide fix-positioned Header', 'uku-light' ),
		'description'		=> esc_html__( '(By default the fix-positioned Header is visible on wider screens, if the browser window is scrolled.)', 'uku-light' ),
		'section'			=> 'uku_light_header',
		'type'				=> 'checkbox',
		'priority'			=> 4,
	) );

	// Uku Light Theme Options - Images
	$wp_customize->add_setting( 'uku_light_imggradient', array(
		'default'       	=> '0.7',
		'sanitize_callback' => 'uku_light_sanitize_imggradient',
	) );

	$wp_customize->add_control( 'uku_light_imggradient', array(
		'label'         	=> esc_html__( 'Image Bottom Gradient', 'uku-light' ),
		'description'		=> esc_html__( 'Level of transparency (in percent) for the bottom gradient of Featured images with text on the image. (The default value is 70%.)', 'uku-light' ),
		'section'       	=> 'uku_light_images',
		'priority'      	=> 1,
		'type'          	=> 'select',
		'choices' 			=> array(
			'0'   => esc_html__( '0', 'uku-light' ),
        	'0.1' => esc_html__( '10', 'uku-light' ),
        	'0.2' => esc_html__( '20', 'uku-light' ),
        	'0.3' => esc_html__( '30', 'uku-light' ),
        	'0.4' => esc_html__( '40', 'uku-light' ),
        	'0.5' => esc_html__( '50', 'uku-light' ),
        	'0.6' => esc_html__( '60', 'uku-light' ),
        	'0.7' => esc_html__( '70', 'uku-light' ),
        	'0.8' => esc_html__( '80', 'uku-light' ),
        	'0.9' => esc_html__( '90', 'uku-light' ),
        	'0.99' => esc_html__( '100', 'uku-light' ),
		),
	) );

	$wp_customize->add_setting( 'uku_light_imgoverlay_color' , array(
    	'default'     		=> '#000000',
    	'sanitize_callback' => 'sanitize_hex_color',
		'transport'   		=> 'refresh',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'uku_light_imgoverlay_color', array(
		'label'				=> esc_html__( 'Image Overlay Color', 'uku-light' ),
		'description'		=> esc_html__( 'Image overlay color for Featured images with text on the image.', 'uku-light' ),
		'section'			=> 'uku_light_images',
		'priority'      	=> 2,
		'settings'			=> 'uku_light_imgoverlay_color',
	) ) );
	
	$wp_customize->add_setting( 'uku_light_imgoverlay_transparency', array(
		'default'       	=> '0',
		'sanitize_callback' => 'uku_light_sanitize_imgoverlay_transparency',
	) );

	$wp_customize->add_control( 'uku_light_imgoverlay_transparency', array(
		'label'         	=> esc_html__( 'Image Overlay Transparency', 'uku-light' ),
		'description'		=> esc_html__( 'Overlay transparency (in percent) for Featured images with text on the image.', 'uku-light' ),
		'section'       	=> 'uku_light_images',
		'priority'      	=> 3,
		'type'          	=> 'select',
		'choices' 			=> array(
			'0'   => esc_html__( '0', 'uku-light' ),
        	'0.1' => esc_html__( '10', 'uku-light' ),
        	'0.2' => esc_html__( '20', 'uku-light' ),
        	'0.3' => esc_html__( '30', 'uku-light' ),
        	'0.4' => esc_html__( '40', 'uku-light' ),
        	'0.5' => esc_html__( '50', 'uku-light' ),
        	'0.6' => esc_html__( '60', 'uku-light' ),
        	'0.7' => esc_html__( '70', 'uku-light' ),
        	'0.8' => esc_html__( '80', 'uku-light' ),
        	'0.9' => esc_html__( '90', 'uku-light' ),
        	'1' => esc_html__( '100', 'uku-light' ),
		),
	) );
	
	$wp_customize->add_setting( 'uku_light_image_font', array(
		'default'      		=> 'light',
		'sanitize_callback' => 'uku_light_sanitize_header_font',
	) );

	$wp_customize->add_control( 'uku_light_image_font', array(
		'label'         	=> esc_html__( 'Image Font', 'uku-light' ),
		'description'		=> esc_html__( 'You can choose a dark image font, if you have Featured images in very light colors.', 'uku-light' ),
		'section'       	=> 'uku_light_images',
		'priority'      	=> 4,
		'type'          	=> 'select',
		'choices' 			=> array(
        	'light' 	=> esc_html__( 'light', 'uku-light' ),
        	'dark' 		=> esc_html__( 'dark', 'uku-light' ),
		),
	) );

}
add_action( 'customize_register', 'uku_light_customize_register' );

/**
 * Sanitize Checkboxes.
 */
function uku_light_sanitize_checkbox( $input ) {
	if ( 1 == $input ) {
		return true;
	} else {
		return false;
	}
}

/**
 * Sanitize Blog Layout Sidebar Position.
 */
function uku_light_sanitize_sidebar( $uku_light_sidebar ) {
	if ( ! in_array( $uku_light_sidebar, array( 'sidebar-right', 'sidebar-left', 'sidebar-no' ) ) ) {
		$uku_light_sidebar = 'sidebar-right';
	}
	return $uku_light_sidebar;
}

/**
 * Sanitize Custom Header Image Style.
 */
function uku_light_sanitize_headerstyle( $uku_light_headerstyle ) {
	if ( ! in_array( $uku_light_headerstyle, array( 'header-fullwidth', 'header-boxed', 'header-fullscreen' ) ) ) {
		$uku_light_headerstyle = 'header-fullwidth';
	}
	return $uku_light_headerstyle;
}

/**
 * Sanitize Custom Fix-positioned header style.
 */
function uku_light_sanitize_fixedheader_style( $uku_light_fixedheader_style ) {
	if ( ! in_array( $uku_light_fixedheader_style, array( 'light', 'dark' ) ) ) {
		$uku_light_fixedheader_style = 'light';
	}
	return $uku_light_fixedheader_style;
}

/**
 * Sanitize header font.
 */
function uku_light_sanitize_header_font( $uku_light_header_font ) {
	if ( ! in_array( $uku_light_header_font, array( 'light', 'dark' ) ) ) {
		$uku_light_header_font = 'dark';
	}
	return $uku_light_header_font;
}

/**
 * Sanitize the image font.
 */
function uku_light_sanitize_image_font( $uku_light_image_font ) {
	if ( ! in_array( $uku_light_image_font, array( 'light', 'dark' ) ) ) {
		$uku_light_image_font = 'light';
	}
	return $uku_light_image_font;
}

/**
 * Sanitize Image Gradient Transparency.
 */
function uku_light_sanitize_imggradient( $uku_light_imggradient ) {
	if ( ! in_array( $uku_light_imggradient, array( '0','0.1', '0.2', '0.3', '0.4', '0.5', '0.6', '0.7', '0.8', '0.9', '0.99' ) ) ) {
		$uku_light_imggradient = '0.7';
	}
	return $uku_light_imggradient;
}

/**
 * Sanitize Image Overlay Transparency.
 */
function uku_light_sanitize_imgoverlay_transparency( $uku_light_imgoverlay_transparency ) {
	if ( ! in_array( $uku_light_imgoverlay_transparency, array( '0','0.1', '0.2', '0.3', '0.4', '0.5', '0.6', '0.7', '0.8', '0.9', '1' ) ) ) {
		$uku_light_imgoverlay_transparency = '0';
	}
	return $uku_light_imgoverlay_transparency;
}
