<?php
/**
 * Uku Light functions and definitions
 *
 * @package Uku Light
 * @since Uku Light 1.0
 * @version 1.0.1
 */


/*-----------------------------------------------------------------------------------*/
/* Sets up theme defaults and registers support for various WordPress features.
/*-----------------------------------------------------------------------------------*/

function uku_light_setup() {

	// Make Uku Light available for translation. Translations can be added to the /languages/ directory.
	load_theme_textdomain( 'uku-light', get_template_directory() . '/languages' );

	// This theme styles the visual editor to resemble the theme style.
	add_editor_style( array( 'css/editor-style.css', uku_light_fonts_url() ) );

	// Add default posts and comments RSS feed links to head
	add_theme_support( 'automatic-feed-links' );

	// Let WordPress manage the document title.
	add_theme_support( 'title-tag' );

	// This theme uses wp_nav_menu().
	register_nav_menus( array (
		'primary'				=> esc_html__( 'Primary menu', 'uku-light' ),
		'social' 				=> esc_html__( 'Social Icons (Header and Footer)', 'uku-light' ),
		'footer-one' 		=> esc_html__( 'Footer 1', 'uku-light' ),
		'footer-two' 		=> esc_html__( 'Footer 2', 'uku-light' ),
		'footer-three' 	=> esc_html__( 'Footer 3', 'uku-light' ),
		'footer-four' 	=> esc_html__( 'Footer 4', 'uku-light' ),
	) );

	// Implement the Custom Header feature
	require get_template_directory() . '/inc/custom-header.php';

	// This theme allows users to set a custom background.
	add_theme_support( 'custom-background', apply_filters( 'uku_light_custom_background_args', array(
		'default-color'	=> 'fff',
		'default-image'	=> '',
	) ) );

	// Enable support for Video Post Formats.
	add_theme_support( 'post-formats', array (
		'video',
	) );

	// Enable support for custom logo.
	add_theme_support( 'custom-logo', array(
		'width'       => 520,
		'height'      => 236,
	) );

	// This theme uses post thumbnails.
	add_theme_support( 'post-thumbnails' );

	//  Adding several sizes for Post Thumbnails
	add_image_size( 'uku-light-standard-blog', 1024, 576, true  );
	add_image_size( 'uku-light-bigthumb', 1440, 580, true );

}
add_action( 'after_setup_theme', 'uku_light_setup' );

/*-----------------------------------------------------------------------------------*/
/* Sets the content width in pixels, based on the theme's design and stylesheet.
/*-----------------------------------------------------------------------------------*/

function uku_light_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'uku_light_content_width', 900 );
}
add_action( 'after_setup_theme', 'uku_light_content_width', 0 );


/*-----------------------------------------------------------------------------------*/
/* Register Google fonts for Uku Light.
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'uku_light_fonts_url' ) ) :

function uku_light_fonts_url() {
	$fonts_url = '';
	$fonts     = array();
	$subsets   = 'latin,latin-ext';

	/* translators: If there are characters in your language that are not supported by Noticia Text, translate this to 'off'. Do not translate into your own language. */
	if ( 'off' !== esc_html_x( 'on', 'Noticia Text font: on or off', 'uku-light' ) ) {
		$fonts[] = 'Noticia Text:400,400italic,700,700italic';
	}

	/* translators: If there are characters in your language that are not supported by Kanit, translate this to 'off'. Do not translate into your own language. */
	if ( 'off' !== esc_html_x( 'on', 'Kanit font: on or off', 'uku-light' ) ) {
		$fonts[] = 'Kanit:400,500,600,700';
	}

	/* translators: If there are characters in your language that are not supported by Ubuntu Mono, translate this to 'off'. Do not translate into your own language. */
	if ( 'off' !== esc_html_x( 'on', 'Ubuntu Mono font: on or off', 'uku-light' ) ) {
		$fonts[] = 'Ubuntu Mono:400';
	}

	if ( $fonts ) {
		$fonts_url = add_query_arg( array(
			'family' => urlencode( implode( '|', $fonts ) ),
			'subset' => urlencode( $subsets ),
		), 'https://fonts.googleapis.com/css' );
	}

	return $fonts_url;
}
endif;

/*-----------------------------------------------------------------------------------*/
/*  Enqueue scripts and styles
/*-----------------------------------------------------------------------------------*/

function uku_light_scripts() {
	global $wp_styles;

	// Add fonts, used in the main stylesheet.
	wp_enqueue_style( 'uku_light-fonts', uku_light_fonts_url(), array(), null );

	// Loads JavaScript to pages with the comment form to support sites with threaded comments (when in use)
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) )
	wp_enqueue_script( 'comment-reply' );

	// Loads stylesheets.
	wp_enqueue_style( 'uku_light-style', get_stylesheet_uri(), array(), '20160507' );

	// Loads Custom Uku Light JavaScript functionality
	wp_enqueue_script( 'uku_light-script', get_template_directory_uri() . '/js/functions.js', array( 'jquery' ), '20160507', true );
	wp_localize_script( 'uku_light-script', 'screenReaderText', array(
		'expand'   => '<span class="screen-reader-text">' . esc_html__( 'expand child menu', 'uku-light' ) . '</span>',
		'collapse' => '<span class="screen-reader-text">' . esc_html__( 'collapse child menu', 'uku-light' ) . '</span>',
	) );

	// Add Genericons font, used in the main stylesheet.
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/genericons/genericons.css', array(), '3.4.1' );

	// Loading viewpoint checker script
	wp_enqueue_script( 'uku-light-viewportchecker', get_template_directory_uri() . '/js/jquery.viewportchecker.js', array( 'jquery' ), '1.8.7' );

	// Loads Scripts Sticky Sidebar Element
	wp_enqueue_script( 'uku-light-sticky-kit', get_template_directory_uri() . '/js/sticky-kit.js', array( 'jquery' ) );

	// Loading FitVids responsive Video script
	wp_enqueue_script( 'uku-light-fitvids', get_template_directory_uri() . '/js/jquery.fitvids.js', array( 'jquery' ), '1.1' );

}
add_action( 'wp_enqueue_scripts', 'uku_light_scripts' );

/*-----------------------------------------------------------------------------------*/
/* Enqueue Google fonts style to admin screen for custom header display.
/*-----------------------------------------------------------------------------------*/

function uku_light_admin_fonts() {
	wp_enqueue_style( 'uku-light-fonts', uku_light_fonts_url(), array(), null );
}
add_action( 'admin_print_scripts-appearance_page_custom-header', 'uku_light_admin_fonts' );


/*-----------------------------------------------------------------------------------*/
/* Add title to custom menu
/*-----------------------------------------------------------------------------------*/

function uku_light_get_menu_by_location( $location ) {
		if( empty($location) ) return false;

		$locations = get_nav_menu_locations();
		if( ! isset( $locations[$location] ) ) return false;

		$menu_obj = get_term( $locations[$location], 'nav_menu' );

		return $menu_obj;
}

/*-----------------------------------------------------------------------------------*/
/* Add custom max excerpt lengths.
/*-----------------------------------------------------------------------------------*/

function uku_light_custom_excerpt_length( $length ) {
	return 23;
}
add_filter( 'excerpt_length', 'uku_light_custom_excerpt_length', 999 );

/*-----------------------------------------------------------------------------------*/
/* Replace "[...]" with custom read more in excerpts.
/*-----------------------------------------------------------------------------------*/

function uku_light_excerpt_more( $more ) {
	global $post;
	return '&hellip;';
}
add_filter( 'excerpt_more', 'uku_light_excerpt_more' );


/*-----------------------------------------------------------------------------------*/
/* Displays the optional custom logo.
/*-----------------------------------------------------------------------------------*/
if ( ! function_exists( 'uku_light_the_custom_logo' ) ) :
function uku_light_the_custom_logo() {
	if ( function_exists( 'the_custom_logo' ) ) {

		the_custom_logo();
	}
}

/*-----------------------------------------------------------------------------------*/
/* Add Theme Customizer CSS
/*-----------------------------------------------------------------------------------*/

function uku_light_styles_method() {
	wp_enqueue_style(
		'custom-style',
		get_template_directory_uri() . '/css/custom_script.css'
	);
		$uku_light_link_color = esc_attr(get_theme_mod( 'uku_light_link_color' ));
		$uku_light_linkhover_color = esc_attr(get_theme_mod( 'uku_light_linkhover_color' ));
		$uku_light_footer_bg_color = esc_attr(get_theme_mod( 'uku_light_footer_bg_color' ));
		$uku_light_offcanvas_bg_color = esc_attr(get_theme_mod( 'uku_light_offcanvas_bg_color' ));
		$uku_light_offcanvas_text_color = esc_attr(get_theme_mod( 'uku_light_offcanvas_text_color' ));
		$uku_light_imgoverlay_color = esc_attr(get_theme_mod( 'uku_light_imgoverlay_color' ));
		$uku_light_imggradient = esc_attr(get_theme_mod( 'uku_light_imggradient' ));
		$custom_css = "
			.entry-content a,
			.comment-text a,
			#desktop-navigation ul li a:hover,
			#overlay-close:hover,
			.widget-area .widget ul li a:hover,
			#sidebar-offcanvas .widget a:hover,
			.textwidget a:hover,
			#overlay-nav a:hover,
			.author-links a:hover,
			.single-post .post-navigation a:hover,
			.single-attachment .post-navigation a:hover,
			.author-bio a,
			.single-post .hentry .entry-meta a:hover,
			.entry-header a:hover,
			.entry-header h2.entry-title a:hover,
			.blog .entry-meta a:hover {
				color: $uku_light_link_color;
			}
			.single-post .post-navigation a:hover,
			.single-attachment .post-navigation a:hover {
				border-bottom: 2px solid $uku_light_link_color;
			}
			.single-post .entry-cats a,
			.blog #primary .hentry.has-post-thumbnail:nth-child(4n+1) .entry-cats a,
			#desktop-navigation .sub-menu li a:hover,
			#desktop-navigation .children li a:hover,
			.widget_mc4wp_form_widget input[type='submit'] {
				background: $uku_light_link_color;
			}
			.desktop-search input.search-field:active,
			.desktop-search input.search-field:focus {
				border-bottom: 1px solid $uku_light_link_color;
			}
			.entry-content a:hover,
			.comment-text a:hover,
			.author-bio a:hover {
				color: $uku_light_linkhover_color;
			}
			.blog #primary .hentry.has-post-thumbnail:nth-child(4n+1) .entry-cats a:hover,
			.single-post .entry-cats a:hover,
			#colophon .footer-ad-btn:hover,
			.comments-show #comments-toggle,
			.widget_mc4wp_form_widget input[type='submit']:hover,
			#comments-toggle:hover,
			input[type='submit']:hover,
			input#submit:hover,
			#primary #infinite-handle span:hover,
			.desktop-search input[type='submit']:hover,
			.widget_search input[type='submit']:hover,
			.post-password-form input[type='submit']:hover,
			#offcanvas-widgets-open:hover {
				background: $uku_light_linkhover_color;
			}
			#colophon .footer-ad-textwrap .footer-ad-btn:hover,
			.comments-show #comments-toggle,
			#comments-toggle:hover,
			input[type='submit']:hover,
			input#submit:hover,
			.blog #primary #infinite-handle span:hover,
			.desktop-search input[type='submit']:hover,
			.widget_search input[type='submit']:hover,
			.post-password-form input[type='submit']:hover,
			#offcanvas-widgets-open:hover {
				border: 2px solid $uku_light_linkhover_color !important;
			}
			#colophon {background: $uku_light_footer_bg_color;}
			.mobile-search, .inner-offcanvas-wrap {background: <?php echo esc_attr(get_theme_mod( 'uku_light_offcanvas_bg_color' )); ?>;}
			.social-nav ul li a,
			#overlay-nav ul li a,
			#offcanvas-widgets-open,
			.dropdown-toggle,
			#sidebar-offcanvas .widget h2.widget-title,
			#sidebar-offcanvas .widget,
			#sidebar-offcanvas .widget a {
				color: $uku_light_offcanvas_text_color;
			}
			#sidebar-offcanvas .widget h2.widget-title {border-top: 1px solid $uku_light_offcanvas_text_color;}
			#offcanvas-widgets-open {border: 2px solid $uku_light_offcanvas_text_color;}
			@media screen and (min-width: 66.25em) {
				#overlay-nav ul li,
				#overlay-nav ul ul.sub-menu,
				#overlay-nav ul ul.children {border-bottom: 1px solid $uku_light_offcanvas_text_color;}
				#overlay-close {color: $uku_light_offcanvas_text_color;}
				#overlay-nav {border-top: 1px solid $uku_light_offcanvas_text_color;}
			}
			.blog #primary .hentry.has-post-thumbnail:nth-child(4n+1) .entry-thumbnail a:after,
			.header-image:after, .single-post .big-thumb .entry-thumbnail a:after {background-color: $uku_light_imgoverlay_color;}
			.blog #primary .hentry.has-post-thumbnail:nth-child(4n+1) .meta-main-wrap,
			.big-thumb .title-wrap {
				background: -moz-linear-gradient(top, rgba(0,0,0,0) 0%, rgba(0,0,0,$uku_light_imggradient) 100%);
				background: -webkit-linear-gradient(top, rgba(0,0,0,0) 0%,rgba(0,0,0,$uku_light_imggradient) 100%);
				background: linear-gradient(to bottom, rgba(0,0,0,0) 0%,rgba(0,0,0,$uku_light_imggradient) 100%);
			}
		";
		wp_add_inline_style( 'custom-style', $custom_css );
}
add_action( 'wp_enqueue_scripts', 'uku_light_styles_method' );


/*-----------------------------------------------------------------------------------*/
/* Comments template uku_light_comment
/*-----------------------------------------------------------------------------------*/
function uku_light_comment( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	switch ( $comment->comment_type ) :
		case '' :
	?>

	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
		<div id="comment-<?php comment_ID(); ?>" class="comment">
			<div class="comment-avatar">
				<?php echo get_avatar( $comment, 80 ); ?>
			</div>

			<div class="comment-wrap">
				<div class="comment-details">
					<div class="comment-author">

						<?php printf( ( '%s' ), wp_kses_post( sprintf( '%s', get_comment_author_link() ) ) ); ?>
					</div><!-- end .comment-author -->
					<div class="comment-meta">
						<span class="comment-time"><a href="<?php echo esc_url( get_comment_link( $comment->comment_ID ) ); ?>">
							<?php
							/* translators: 1: date */
								printf( esc_html__( '%1$s', 'uku-light' ),
								get_comment_date());
							?></a>
						</span>
						<?php edit_comment_link( esc_html__(' Edit', 'uku-light'), '<span class="comment-edit">', '</span>'); ?>
					</div><!-- end .comment-meta -->
				</div><!-- end .comment-details -->

				<div class="comment-text">
				<?php comment_text(); ?>
					<?php if ( $comment->comment_approved == '0' ) : ?>
						<p class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'uku-light' ); ?></p>
					<?php endif; ?>
				</div><!-- end .comment-text -->
				<?php if ( comments_open () ) : ?>
					<div class="comment-reply"><?php comment_reply_link( array_merge( $args, array( 'reply_text' => esc_html__( 'Reply', 'uku-light' ), 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?></div>
				<?php endif; ?>
			</div><!-- end .comment-wrap -->
		</div><!-- end .comment -->

	<?php
			break;
		case 'pingback'  :
		case 'trackback' :
	?>
	<li class="pingback">
		<p><?php esc_html_e( 'Pingback:', 'uku-light' ); ?> <?php comment_author_link(); ?></p>
		<p class="pingback-edit"><?php edit_comment_link(); ?></p>
	<?php
			break;
	endswitch;
}
endif;

/*-----------------------------------------------------------------------------------*/
/* Register widgetized areas
/*-----------------------------------------------------------------------------------*/

function uku_light_widgets_init() {

	register_sidebar( array (
		'name' => esc_html__( 'Blog Sidebar', 'uku-light' ),
		'id' => 'sidebar-1',
		'description' => esc_html__( 'Widgets appear in the default sidebar.', 'uku-light' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget' => "</section>",
		'before_title' => '<h2 class="widget-title">',
		'after_title' => '</h2>',
	) );

	register_sidebar( array (
		'name' => esc_html__( 'Page Sidebar', 'uku-light' ),
		'id' => 'sidebar-2',
		'description' => esc_html__( 'Widgets appear in the sidebar on pages.', 'uku-light' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget' => "</section>",
		'before_title' => '<h2 class="widget-title">',
		'after_title' => '</h2>',
	) );

	register_sidebar( array (
		'name' => esc_html__( 'Widget Area - Off Canvas', 'uku-light' ),
		'id' => 'sidebar-offcanvas',
		'description' => esc_html__( 'Widgets appear in the off canvas area.', 'uku-light' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget' => "</section>",
		'before_title' => '<h2 class="widget-title">',
		'after_title' => '</h2>',
	) );

}
add_action( 'widgets_init', 'uku_light_widgets_init' );

/*-----------------------------------------------------------------------------------*/
/* Extends the default WordPress body classes
/*-----------------------------------------------------------------------------------*/
function uku_light_body_class( $classes ) {

	if ( is_page_template( 'page-templates/full-width.php' ) ) {
		$classes[] = 'page-fullwidth';
	}
	if ( has_header_image() ) {
		$classes[] = 'headerimg-on';
	}
	if ( '' != get_the_post_thumbnail ()) {
		$classes[] = 'has-thumb';
	}
	if ('sidebar-left' == get_theme_mod( 'uku_light_sidebar' ) ) {
		$classes[] = 'sidebar-left';
	}
	if ( is_page_template( 'page-templates/no-sidebar.php' ) ) {
		$classes[] = 'no-sidebar';
	}
	if ('sidebar-no' == get_theme_mod( 'uku_light_sidebar' ) ) {
		$classes[] = 'no-sidebar';
	}
	if ('header-boxed' == get_theme_mod( 'uku_light_headerstyle' ) ) {
		$classes[] = 'header-boxed';
	}
	if ('header-fullscreen' == get_theme_mod( 'uku_light_headerstyle' ) ) {
		$classes[] = 'header-fullscreen';
	}
	if ('dark' == get_theme_mod( 'uku_light_fixedheader' ) ) {
		$classes[] = 'hide-header-sticky';
	}
	if ('dark' == get_theme_mod( 'uku_light_fixedheader_style' ) ) {
		$classes[] = 'fixedheader-dark';
	}
	if ('light' == get_theme_mod( 'uku_light_header_font' ) ) {
		$classes[] = 'headerfont-light';
	}
	if ('dark' == get_theme_mod( 'uku_light_image_font' ) ) {
		$classes[] = 'imagefont-dark';
	}
	if ( ! is_active_sidebar( 'sidebar-offcanvas' ) ) {
		$classes[] = 'offcanvas-widgets-off';
	}

	// Option to add body classes via custom fields
	if ( get_post_meta( get_the_ID(), 'sidebar-left', true ) ) {
		$classes[] = 'sidebar-left';
	}
	if ( get_post_meta( get_the_ID(), 'no-sidebar', true ) ) {
		$classes[] = 'no-sidebar';
	}
	if ( get_post_meta( get_the_ID(), 'header-fullscreen', true ) ) {
		$classes[] = 'header-fullscreen';
	}
	if ( get_post_meta( get_the_ID(), 'header-boxed', true ) ) {
		$classes[] = 'header-boxed';
	}
	if ( get_post_meta( get_the_ID(), 'headerimg-on', true ) ) {
		$classes[] = 'headerimg-on';
	}
	if ( get_post_meta( get_the_ID(), 'headerfont-light', true ) ) {
		$classes[] = 'headerfont-light';
	}
	if ( get_post_meta( get_the_ID(), 'imagefont-dark', true ) ) {
		$classes[] = 'imagefont-dark';
	}

	return $classes;
}
add_filter( 'body_class', 'uku_light_body_class' );

/*-----------------------------------------------------------------------------------*/
/* Customizer additions
/*-----------------------------------------------------------------------------------*/
require get_template_directory() . '/inc/customizer.php';

/*-----------------------------------------------------------------------------------*/
/* Custom template tags for this theme.
/*-----------------------------------------------------------------------------------*/
require get_template_directory() . '/inc/template-tags.php';

/*-----------------------------------------------------------------------------------*/
/* Load Jetpack compatibility file.
/*-----------------------------------------------------------------------------------*/
require get_template_directory() . '/inc/jetpack.php';
