
--- Uku Light -------------------------------------------------------
Theme Author: Elmastudio (http://www.elmastudio.de/en/)
Requires at least: WordPress 4.5
Version: 1.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: one-column, two-columns, right-sidebar, left-sidebar, custom-background, custom-colors, custom-header, custom-menu, featured-image-header, editor-style, featured-images, flexible-header, rtl-language-support, threaded-comments, translation-ready, full-width-template, theme-options, blog, entertainment, news, photography

--- Description -----------------------------------------------
Uku Light is a flexible, responsive blog theme a modern, blog design, an off canvas area, social and footer menus and a big header image. If you need more features like additional front page post sections or a featured post slider you can always upgrade to the Premium Uku theme. Find out more about all Uku theme features on the Elmastudio website.

--- Theme Changelog -------------------------------------------

Version 1.0:
- Uku Light theme release.

Version 1.0.1:
- Included copyright notice.
- Included scripts in full version (not minified).
- Optimized CSS for long titles.
- Escaped/validated text strings.

Version 1.0.2:
- Escaped text strings.
- Added inc/template-tags.php.

---------------------------------------------------------------

Uku Light WordPress Theme, Copyright 2017 Elmastudio
Uku Light is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.

Uku Light WordPress Theme is derived from Underscores WordPress Theme, Copyright 2013 Automattic, Inc.
Underscores WordPress Theme is distributed under the terms of the GNU GPL

Uku Light WordPress Theme bundles the following third-party resources:

Genericons icon font, Copyright 2013 Automattic
Genericons are licensed under the terms of the GNU GPL, Version 2 (or later)
Source: http://www.genericons.com

FitVids 1.1, Copyright 2013, Chris Coyier - http://css-tricks.com + Dave Rupert - http://daverupert.com
FitVids is released under the WTFPL license - http://sam.zoy.org/wtfpl/
Source: http://fitvidsjs.com/

Sticky-kit v1.1.3, Leaf Corcoran 2015, http://leafo.net
Sticky-kit is released under the MIT license.
Source: http://leafo.net/sticky-kit/

jQuery-viewport-checker, Copyright 2014, Dirk Groenen
jQuery-viewport-checker is released under the MIT license.
Source: https://github.com/dirkgroenen/jQuery-viewport-checker
