<?php
/**
 * The main template file.
 *
 * @package Uku Light
 * @since Uku Light 1.0
 * @version 1.0
 */

get_header(); ?>

	<div id="blog-wrap" class="blog-wrap cf">

		<div id="primary" class="site-content cf" role="main">
			<h3 class="blog-title"><?php esc_html_e('Latest Posts', 'uku-light') ?></h3>

				<?php /* Start the Loop */ ?>
				<?php while ( have_posts() ) : the_post(); ?>

					<?php get_template_part('template-parts/content' ); ?>

				<?php endwhile; // end of the loop. ?>

			<?php the_posts_pagination( array(
				'next_text' => '<span class="meta-nav">' . esc_html__( 'Older', 'uku-light' ) . '</span> ' .
					'<span class="screen-reader-text">' . esc_html__( 'Older Posts', 'uku-light' ) . '</span> ',
				'prev_text' => '<span class="meta-nav">' . esc_html__( 'Newer', 'uku-light' ) . '</span> ' .
					'<span class="screen-reader-text">' . esc_html__( 'Newer Posts', 'uku-light' ) . '</span> ',
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . esc_html__( 'Page', 'uku-light' ) . ' </span>',
			) ); ?>
		</div><!-- end #primary -->

		<?php get_sidebar(); ?>

	</div><!-- end .blog-wrap -->

<?php get_footer(); ?>
