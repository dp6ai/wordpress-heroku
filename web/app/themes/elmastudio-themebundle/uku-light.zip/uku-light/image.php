<?php
/**
 * The template for displaying image attachments.
 *
 * @package Uku Light
 * @since Uku Light 1.0
 * @version 1.0
 */

// Retrieve attachment metadata.
$metadata = wp_get_attachment_metadata();

get_header();
?>

<div id="singlepost-wrap" class="singlepost-wrap cf">

	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		
		<header class="entry-header">
			<h1 class="entry-title"><?php the_title(); ?></a></h1>
			<div class="entry-meta cf">
				<div class="meta-columnone">
					<div class="entry-date">
						<a href="<?php the_permalink(); ?>"><?php echo get_the_date(); ?></a>
					</div><!-- end .entry-date -->
				</div><!-- end .meta-columnone -->
				<div class="meta-columntwo">
					<?php if ( comments_open() ) : ?>
					<div class="entry-comments-single">
						<span class="entry-comments-title"><?php esc_html_e( 'Comments', 'uku-light' ); ?></span>
						<span class="entry-comments"><?php comments_popup_link( esc_html__( '0', 'uku-light' ), esc_html__( '1', 'uku-light' ), esc_html__( '%', 'uku-light' ) ); ?></span>
					</div><!-- end .entry-comments -->
					<?php endif; // comments_open() ?>
				</div><!-- end .meta-columntwo -->
				
				<div class="meta-columnthree">
					<?php edit_post_link( esc_html__( 'Edit Post', 'uku-light' ), '<span class="entry-edit">', '</span>' ); ?>
				</div><!-- end .meta-columnthree -->
			</div><!-- end .entry-meta -->
		</header><!--end .entry-header -->

		<div class="contentwrap">	
			<div class="entry-content">
				<div class="attachment">
					<?php echo wp_get_attachment_image( get_the_ID() ); ?>
					<?php if ( ! empty( $post->post_excerpt ) ) : ?>
						<div class="entry-caption">
							<?php the_excerpt(); ?>
						</div>
					<?php endif; ?>
				</div><!-- .attachment -->
			</div><!-- .entry-content -->

			<?php
			// If comments are open or we have at least one comment, load up the comment template
				if ( comments_open() || '0' != get_comments_number() )
				comments_template();
			?>

			<div class="post-navigation cf">
				<nav id="nav-single" class="cf">
					<div class="nav-next"><?php next_image_link( '%link', ( '<span>' . esc_html__( 'Next Image', 'uku-light' ) . '</span>' ) ); ?></div>
					<div class="nav-previous"><?php previous_image_link( '%link', ( '<span>' . esc_html__( 'Previous Image', 'uku-light' ) . '</span>' ) ); ?></div>
				</nav><!-- #nav-single -->
			</div><!-- end .nav-wrap -->
		</div><!-- end .content-wrap -->

	</article><!-- end post -<?php the_ID(); ?> -->

	<?php get_sidebar(); ?>

</div><!-- end .singlepost-wrap -->

<?php get_footer(); ?>
