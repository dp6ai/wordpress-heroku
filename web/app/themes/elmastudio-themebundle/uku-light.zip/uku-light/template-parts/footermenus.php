<?php
/**
 * The template for the footer menus
 *
 * @subpackage Uku Light
 * @since Uku Light 1.0
  * @version 1.0
 */
?>

<div class="footer-menus-wrap cf">

	<?php if (has_nav_menu( 'footer-one' ) ) : ?>
	<nav id="footer-menu-one" class="footer-menu" role="navigation">
		<?php
			wp_nav_menu( array(
			'theme_location'	=> 'footer-one',
			'items_wrap'=> '<ul id="%1$s" class="%2$s">%3$s</ul>',
			'container' 		=> 'false',
			));  ?>
	</nav><!-- end #footer-one -->
	<?php endif; ?>

	<?php if (has_nav_menu( 'footer-two' ) ) : ?>
	<nav id="footer-menu-two" class="footer-menu" role="navigation">
		<?php 
			wp_nav_menu( array(
			'theme_location'	=> 'footer-two',
			'items_wrap'=> '<ul id="%1$s" class="%2$s">%3$s</ul>',
			'container' 		=> 'false',
			));  ?>
	</nav><!-- end #footer-two -->
	<?php endif; ?>

	<?php if (has_nav_menu( 'footer-three' ) ) : ?>
	<nav id="footer-menu-three" class="footer-menu" role="navigation">
		<?php
			wp_nav_menu( array(
			'theme_location'	=> 'footer-three',
			'items_wrap'=> '<ul id="%1$s" class="%2$s">%3$s</ul>',
			'container' 		=> 'false',
			));  ?>
	</nav><!-- end #footer-three -->
	<?php endif; ?>

	<?php if (has_nav_menu( 'footer-four' ) ) : ?>
	<nav id="footer-menu-four" class="footer-menu" role="navigation">
		<?php
			wp_nav_menu( array(
			'theme_location'	=> 'footer-four',
			'items_wrap'=> '<ul id="%1$s" class="%2$s">%3$s</ul>',
			'container' 		=> 'false',
			));  ?>
	</nav><!-- end #footer-four -->
	<?php endif; ?>

</div><!-- end .footer-menus-wrap -->
