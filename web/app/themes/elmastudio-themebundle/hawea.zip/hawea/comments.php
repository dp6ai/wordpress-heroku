<?php
/**
 * The template for displaying Comments.
 *
 * @package Hawea
 * @since Hawea 1.0
 * @version 1.0
 */

 /*
 * If the current post is protected by a password and the visitor has not yet
 * entered the password we will return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>

	<div id="comments" class="comments-area">

	<?php if ( have_comments() ) : ?>

	<h3 class="comments-title">
		<?php
			printf( _n( '1 Comment', '%1$s Comments', get_comments_number(), 'hawea' ),
				number_format_i18n( get_comments_number() ) );
		?>
	</h3>

	<ol class="commentlist">
		<?php
			wp_list_comments( array( 'callback' => 'hawea_comment' ) );
		?>
	</ol><!-- end .comment-list -->

		<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : // are there comments to navigate through ?>
		<nav id="nav-comments">
			<div class="nav-previous"><?php previous_comments_link( ( '<span>' . __( 'Older Comments', 'hawea' ) . '</span>' ) ); ?></div>
			<div class="nav-next"><?php next_comments_link( ( '<span>' . __( 'Newer Comments', 'hawea' ) . '</span>' ) ); ?></div>
		</nav><!-- end #comment-nav -->
		<?php endif; // check for comment navigation ?>

	<?php
		// If comments are closed and there are no comments, let's leave a little note, shall we?
		if ( ! comments_open() && '0' != get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) :
	?>
		<p class="nocomments"><?php esc_html_e( 'Comments are closed.', 'hawea' ); ?></p>
	<?php endif; ?>

	<?php endif; // have_comments() ?>

	<?php $comment_args = array(
		'comment_field' => '<p class="comment-form-comment"><label for="comment">'.esc_html__('Comment', 'hawea').'</label><textarea id="comment" name="comment" cols="45" rows="8" aria-required="true" placeholder="' . esc_html__( 'Write a comment', 'hawea' ) . '"></textarea></p>',
		'fields' => apply_filters( 'comment_form_default_fields', array(
		'author' => '<p class="comment-form-author">' . '<label for="author">' . esc_html__( 'Name', 'hawea' ) . '</label><input id="author" name="author" type="text" placeholder="' . esc_html__( 'Name', 'hawea' ) . '" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30" aria-required="true"/></p>',   
		'email'  => '<p class="comment-form-email">' . '<label for="email">' . esc_html__( 'Email', 'hawea' ) . '</label> ' . ( $req ? '<span>*</span>' : '' ) . '<input id="email" name="email" type="text" placeholder="' . esc_html__( 'Email', 'hawea' ) . '" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" size="30" aria-required="true"/>'.'</p>',
		'url'    => '<p class="comment-form-url"><label for="url">' . esc_html__( 'Website', 'hawea' ) . '</label>' . '<input id="url" name="url" type="text" placeholder="' . esc_html__( 'Website', 'hawea' ) . '" value="' . esc_attr( $commenter['comment_author_url'] ) . '" size="30" /></p>',
    'comment_notes_after' => '',
    ) )
);




	comment_form($comment_args); ?>

	</div><!-- #comments .comments-area -->
