
-----------------------------------------------------------------------------------------------------------------------------------

For the detailed theme documentation please visit:
https://www.elmastudio.de/en/themes/hawea/ (English) or https://www.elmastudio.de/wordpress-themes/hawea/ (German)

Please use the the Elmastudio theme forum to ask all questions regarding the Hawea theme.

-----------------------------------------------------------------------------------------------------------------------------------


Changelog:

Version 1.0.9 (13. September 2017):
-----------------------------------------------------------------------------------------------------------------------------------
- Bugfix: Update of jQuery viewport checker script due to bug in newest Google Chrome version. (see: assets(js/jquery.viewportchecker.min.js)

Version 1.0.8 (06/04/2017)
-----------------------------------------------------------------------------------------------------------------------------------
- New: Support for the new WooCommerce product image gallery.
- Bugfix: Smaller CSS fixes for WooCommerce 3.0.

Version 1.0.7 (08/03/2017)
-----------------------------------------------------------------------------------------------------------------------------------
- New Added support for the One Click Demo Import plugin.

Version 1.0.6 (08/12/2016)
-----------------------------------------------------------------------------------------------------------------------------------
- Enhancement: Smaller CSS optimizations (style.css)
- Bugfix: Layout fix for Search Result page, if no search results found (search.php)


Version 1.0.5 (01/06/2016)
-----------------------------------------------------------------------------------------------------------------------------------
- Bugfix: CSS optimizations for Add to Cart button (style.css)
- Bugfix: German language translations (language folder)


Version 1.0.4 (10/05/2016)
-----------------------------------------------------------------------------------------------------------------------------------
- Bugfix: CSS optimizations for search results with products (style.css, js/postmasonry.js)
- Enhancement: Further CSS optimizations to support WooCommerce Germanized plugin (style.css)


Version 1.0.3 (26/04/2016)
-----------------------------------------------------------------------------------------------------------------------------------
- Enhancement: Further CSS optimizations to support WooCommerce Germanized plugin (style.css)


Version 1.0.2 (03/03/2016)
-----------------------------------------------------------------------------------------------------------------------------------
- Enhancement: General CSS optimizations to support the WooCommerce Germanized plugin (style.css)
- Enhancement: Optimizations for editor CSS styles (css/editor-style.css)


Version 1.0.1 (26/02/2016)
-----------------------------------------------------------------------------------------------------------------------------------
- Bugfix: Optimize Hawea to be used without the WooCommerce plugin (see functions.php, header.php, template-parts/shop-menu.php, woocommerce folder)
- Enhancement: General CSS optimizations (style.css)


Version 1.0 (15/02/2016)
-----------------------------------------------------------------------------------------------------------------------------------
- Hawea theme release
