
---------------------------------------------------------------------------------------------------------------------------
For detailed Kerikeri theme documentationw (PDF & video tutorials in English and German) please visit:
https://www.elmastudio.de/wordpress-themes/kerikeri/
---------------------------------------------------------------------------------------------------------------------------

Kerikeri Changelog:

Version 1.0.3 - 13/03/2017
----------------------------------
- New: Support for the One Click Demo Import plugin.


Version 1.0.2 - 09/03/2014
----------------------------------
- Bugfix: Updated jquery.fitvids.js in folder "js" to fix Chrome font bug
- Enhancement: Deleted deprecated add_custom_background (see functions.php)


Version 1.0.1 - March 21th 2012
----------------------------------
- Bugfix for Retina display optimized social links icons (see style.css line 2198-2312).
- Added styles for RSS widget.


Version 1.0 - March 16th 2012
----------------------------------
- Kerikeri theme release
