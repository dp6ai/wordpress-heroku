
Meola Changelog:

Version 1.0.5 - 17/03/2017
----------------------------------
- New: Support for the One Click Demo Import plugin.
- Bugfix: Updated all links to https.
- Bugfix: Updated deprecated functions.


Version 1.0.4 - 09/03/2014
----------------------------------
- Bugfix: Updated jquery.fitvids.js in folder "js" to fix Chrome font bug
- Enhancement: Deleted deprecated add_custom_background (see functions.php)


Version 1.0.3 - Jan 27th 2013
----------------------------------
- Updated code for Responsive Slider WordPress plugin Version 0.1.8 (see header.php, 135)


Version 1.0.2 - July 30th 2012
----------------------------------
- Better padding for image captions (see style.css, 657 and 3162)
- Bugfix for individual footer text floating next to top button. (see footer.php, 16-18)
- Optimized styling for image gallery and gallery captions on pages (see style.css 1241-1260 and 2828-2834)
- Optimized styling of 3-column Recent Posts Widget (see style.css, 2895-2904)
- Optimzed image alignment in visual editor (see editor-style.css, 245-260)
- Change of image dimensions in Flickr widget to standard image dimensions (see style.css, 1769, 2548, 2893 and 3193)
- Center aligned Flickr widget (see style.css, 1790 inline-block)


Version 1.0.1 - July 23th 2012
----------------------------------
- CSS Optimizations for IE8 and below (see style.css, 2252-2581)
- Flickr Widget Optimization (see style.css, 2876-2879 and 3172-3176)


Version 1.0 - July 23th 2012
----------------------------------
- Meola theme release


---------------------------------------------------------------------------------------------------------------------------
Social Icons by Gedy Riviera: lifetreecreative.com/icons/
---------------------------------------------------------------------------------------------------------------------------
