

Changelog:

Version 1.0.4 - 17/03/2017
----------------------------------
- New: Support for the One Click Demo Import plugin.
- Bugfix: Updated deprecated code.
- Enhancement: Support for Wordpress title-tag.


Version 1.0.3 - 17/04/2014
----------------------------------
- Bugfix: Javascript bug fix for two-column blog layout in WordPress 3.9 version (see js/custom.js)


Version 1.0.2 - 09/03/2014
----------------------------------
1. Bugfix: Updated jquery.fitvids.js in folder "js" to fix Chrome font bug
2. Enhancement: Deleted deprecated add_custom_background (see functions.php)


Version 1.0.1 - January 26th 2012
----------------------------------
1. Fixed language switching for Facebook like and share button (see footer.php line 76)
2. Bugfix calling the respond.js script  (see functions.php line 51)
3. Mozilla Firefox bugfix displaying the two colum blog frontpage correctly
	 (changed width to 49.9 instead of 50% font #content. post (see style.css line 1895 and 2090)
4. Fixed dots in comments reply link (see functions.php line 184 and style.css 580)
5. Added .banner class to use for images (e.g. in a text widget)
6. Bugfix for displaying the Facebook send button (deleted overflow:hidden in style.css line 502)
7. Optimized list stylings (see style.css from line 114)
8. Fixed Mozilla Firefox bug for input text field padding


Version 1.0 - December 22th 2011
----------------------------------
1. Nori theme release
