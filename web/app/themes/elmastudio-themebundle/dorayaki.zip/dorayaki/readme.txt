
-----------------------------------------------------------------------------------------------------------------------

For a detailed theme documentation + video tutorials please visit:
http://www.elmastudio.de/en/themes/dorayaki/ (English) or http://www.elmastudio.de/wordpress-themes/dorayaki/ (German)

Questions about Dorayaki can be asked in the Elmastudio theme forum: http://themeforum.elmastudio.de/

-----------------------------------------------------------------------------------------------------------------------

Version 1.0.4 (13/03/2017)
----------------------------------------------------------------------------------------------------------------------------
- New: Support for the One Click Demo Import plugin.


Version 1.0.3 (19/08/2015)
----------------------------------------------------------------------------------------------------------------------------
- Bug Fix: Update of inc/widget.php file to make theme WordPress 4.3 compatible (see inc/widgets.php)


Version 1.0.2 (09/03/2014)
------------------------------------------------------------------------------------------------------------------------
- Bugfix: Updated jquery.fitvids.js in folder "js" to fix Chrome font bug


Version 1.0.1 (August 31th 2013)
------------------------------------------------------------------------------------------------------------------------
- Enhancement: Optimized Google Webfonts integration (functions.php)
- Enhancement: Custom CSS option on theme options page (inc/theme-options.php)
- Enhancement: Blog content centered, if no main sidebar widgets set (style.css, functions.php)
- Enhancement: 3 new default header images (functions.php, folder: images/headers)
- Bug Fix: Minor CSS fixes (style.css)
- Bug Fix: CSS fixes for the Widgetize Pages Light plugin (style.css)
- Bug Fix: CSS Fix for 2 column contact form/info on fullwidth pages (style.css)
- Bug Fix: Showing exzerpts for post formats (content-link.php, content-quote.php)
- Bug Fix: Changed dfault title to not uppercase, so Umlaute are visible (style.css)


Version 1.0 (July 31th 2013)
------------------------------------------------------------------------------------------------------------------------

- Dorayaki Theme release
