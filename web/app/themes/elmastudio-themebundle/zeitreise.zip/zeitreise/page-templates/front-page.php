<?php
/**
 * Template Name: Front Page
 *
 * Description: A page template for a Custom Front Page
 *
 * @package Zeitreise
 * @since Zeitreise 1.0
 * @version 1.0
 */

get_header(); ?>

<div id="primary" class="site-content" role="main">

	<?php if( '' !== get_post()->post_content ) : ?>
		<?php
			// Start the Loop.
			while ( have_posts() ) : the_post();

				// Include the page content template.
				get_template_part( 'template-parts/content', 'page' );

			endwhile;
		?>
	<?php endif; // check, if front page has content ?>

	<?php if ( post_type_exists( 'jetpack-portfolio' ) ) : ?>
		<?php get_template_part( 'template-parts/front-portfolio' ); ?>
	<?php endif; // check, if Jetpack portfolio is active ?>

	<?php get_template_part( 'template-parts/front-posts' ); ?>


	<?php if ( is_active_sidebar( 'team' ) ) : ?>
		<div id="front-team" class="front-section cf">
		<?php if ( get_theme_mod( 'zeitreise_team_title' ) ) : ?>
			<h3 class="section-title fadethis"><?php esc_html_e( get_theme_mod( 'zeitreise_team_title' ) ); ?></h3>
		<?php else : ?>
			<h3 class="section-title fadethis"><?php esc_html_e('Team', 'zeitreise') ?></h3>
		<?php endif; // custom Team title ?>
			<div class="team-wrap cf fadethis">
				<?php dynamic_sidebar( 'team' ); ?>
			</div><!-- end .team-wrap -->
		</div><!-- end #front-team -->
	<?php endif; // is_active_sidebar('team')  ?>

	<?php if ( post_type_exists( 'jetpack-testimonial' ) ) : ?>
		<?php get_template_part( 'template-parts/front-testimonials' ); ?>
	<?php endif; // check, if Jetpack testimonnial is active ?>

</div><!-- end #primary -->

<?php get_footer(); ?>
