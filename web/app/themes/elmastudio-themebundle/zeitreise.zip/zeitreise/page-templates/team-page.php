<?php
/**
 * Template Name: Team Page
 *
 * Description: A page template for a Team Page
 *
 * @package Zeitreise
 * @since Zeitreise 1.0
 * @version 1.0
 */

get_header(); ?>

<div id="primary" class="site-content" role="main">

	<?php
		// Start the Loop.
		while ( have_posts() ) : the_post();

			// Include the page content template.
			get_template_part( 'template-parts/content', 'page' );

		endwhile;
	?>
	<?php if ( is_active_sidebar( 'team' ) ) : ?>
			<div class="team-wrap cf">
				<?php dynamic_sidebar( 'team' ); ?>
			</div><!-- end .team-wrap -->
	<?php endif; // is_active_sidebar('team')  ?>

</div><!-- end #primary -->
<?php get_footer(); ?>
