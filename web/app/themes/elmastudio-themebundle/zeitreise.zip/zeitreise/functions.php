<?php
/**
 * Zeitreise functions and definitions
 *
 * @package Zeitreise
 * @since Zeitreise 1.0
 * @version 1.0
 */


/*-----------------------------------------------------------------------------------*/
/* Sets up the content width value based on the theme's design.
/*-----------------------------------------------------------------------------------*/

if ( ! isset( $content_width ) )
		$content_width = 1005;

function zeitreise_adjust_content_width() {
		global $content_width;

		if ( is_page_template( 'full-width.php' ) )
				$content_width = 2010;
}
add_action( 'template_redirect', 'zeitreise_adjust_content_width' );


/*-----------------------------------------------------------------------------------*/
/* Sets up theme defaults and registers support for various WordPress features.
/*-----------------------------------------------------------------------------------*/

function zeitreise_setup() {

	// Make Zeitreise available for translation. Translations can be added to the /languages/ directory.
	load_theme_textdomain( 'zeitreise', get_template_directory() . '/languages' );

	// This theme styles the visual editor to resemble the theme style.
	add_editor_style( array( 'css/editor-style.css', zeitreise_font_url() ) );

	// Add default posts and comments RSS feed links to head
	add_theme_support( 'automatic-feed-links' );

	// Let WordPress manage the document title.
	add_theme_support( 'title-tag' );

	// This theme uses wp_nav_menu().
	register_nav_menus( array (
		'primary' => __( 'Primary menu', 'zeitreise' ),
		'footer-social' => __( 'Footer Social menu', 'zeitreise' )
	) );

	// Implement the Custom Header feature
	require get_template_directory() . '/inc/custom-header.php';

	// This theme allows users to set a custom background.
	add_theme_support( 'custom-background', apply_filters( 'zeitreise_custom_background_args', array(
		'default-color'	=> 'fff',
		'default-image'	=> '',
	) ) );

	// This theme uses post thumbnails.
	add_theme_support( 'post-thumbnails' );

	//  Adding several sizes for Post Thumbnails
	add_image_size( 'zeitreise-small', 975, 975, true );
	add_image_size( 'zeitreise-big', 2010, false );
	add_image_size( 'zeitreise-portfolio', 1320, false );

}
add_action( 'after_setup_theme', 'zeitreise_setup' );


/*-----------------------------------------------------------------------------------*/
/*  Returns the Google font stylesheet URL if available.
/*-----------------------------------------------------------------------------------*/

function zeitreise_font_url() {
	$fonts_url = '';

	/* Translators: If there are characters in your language that are not
	 * supported by Martel Sans translate this to 'off'. Do not translate
	 * into your own language.
	 */
	$martelsans = _x( 'on', 'Martel Sans: on or off', 'zeitreise' );

	if ( 'off' !== $martelsans ) {
		$font_families = array();

		if ( 'off' !== $martelsans )
			$font_families[] = 'Martel Sans:400,700,800,900';

		$query_args = array(
			'family' => urlencode( implode( '|', $font_families ) ),
			'subset' => urlencode( 'latin,latin-ext' ),
		);
		$fonts_url = add_query_arg( $query_args, "https://fonts.googleapis.com/css" );
	}

	return esc_url_raw( $fonts_url );
}


/*-----------------------------------------------------------------------------------*/
/*  Enqueue scripts and styles
/*-----------------------------------------------------------------------------------*/

function zeitreise_scripts() {
	global $wp_styles;

	// Add fonts, used in the main stylesheet.
	wp_enqueue_style( 'zeitreise-fonts', zeitreise_font_url(), array(), null );

	// Loads JavaScript to pages with the comment form to support sites with threaded comments (when in use)
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) )
	wp_enqueue_script( 'comment-reply' );

	// Loads stylesheets.
	wp_enqueue_style( 'zeitreise-style', get_stylesheet_uri(), array(), '20151030' );
	wp_enqueue_style( 'zeitreise-animatecss', get_template_directory_uri() . '/css/animate.min.css', array(), '3.4.0' );

	// Loading bar script
	wp_enqueue_script( 'zeitreise-loadingbar', get_template_directory_uri() . '/js/pace.min.js', array( 'jquery' ), '1.0.0' );

	// Loading viewpoint checker script
	wp_enqueue_script( 'zeitreise-viewportchecker', get_template_directory_uri() . '/js/jquery.viewportchecker.min.js', array( 'jquery' ), '1.8.5' );

	/// Loads waypoints JavaScript
	wp_enqueue_script( 'zeitreise-waypoints', get_template_directory_uri() . '/js/jquery.waypoints.min.js', array( 'jquery' ), '4.0.0' );
	wp_enqueue_script( 'zeitreise-waypoints-sticky', get_template_directory_uri() . '/js/sticky.min.js', array( 'jquery' ), '4.0.0' );

	// Loads Custom Zeitreise JavaScript functionality
	wp_enqueue_script( 'zeitreise-script', get_template_directory_uri() . '/js/functions.js', array( 'jquery' ), '20150704', true );
	wp_localize_script( 'zeitreise-script', 'screenReaderText', array(
		'expand'   => '<span class="screen-reader-text">' . __( 'expand child menu', 'zeitreise' ) . '</span>',
		'collapse' => '<span class="screen-reader-text">' . __( 'collapse child menu', 'zeitreise' ) . '</span>',
	) );

	// Loads Scripts for Featured Post Slider
	wp_enqueue_style( 'zeitreise-slick-style', get_template_directory_uri() . '/js/slick/slick.css' );
	wp_enqueue_script( 'zeitreise-slick', get_template_directory_uri() . '/js/slick/slick.min.js', array( 'jquery' ) );

}
add_action( 'wp_enqueue_scripts', 'zeitreise_scripts' );


/*-----------------------------------------------------------------------------------*/
/* Enqueue Google fonts style to admin screen for custom header display.
/*-----------------------------------------------------------------------------------*/
function zeitreise_admin_fonts() {
	wp_enqueue_style( 'zeitreise-fonts', zeitreise_font_url(), array(), null );
}
add_action( 'admin_print_scripts-appearance_page_custom-header', 'zeitreise_admin_fonts' );


/*-----------------------------------------------------------------------------------*/
/* Get our wp_nav_menu() fallback, wp_page_menu(), to show a home link.
/*-----------------------------------------------------------------------------------*/

function zeitreise_page_menu_args( $args ) {
	$args['show_home'] = true;
	return $args;
}
add_filter( 'wp_page_menu_args', 'zeitreise_page_menu_args' );


/*-----------------------------------------------------------------------------------*/
/* Sets the authordata global when viewing an author archive.
/*-----------------------------------------------------------------------------------*/

function zeitreise_setup_author() {
	global $wp_query;

	if ( $wp_query->is_author() && isset( $wp_query->post ) ) {
		$GLOBALS['authordata'] = get_userdata( $wp_query->post->post_author );
	}
}
add_action( 'wp', 'zeitreise_setup_author' );


/*-----------------------------------------------------------------------------------*/
/* Short Title.
/*-----------------------------------------------------------------------------------*/

function zeitreise_title_limit($length, $replacer = '...') {
 $string = the_title('','',FALSE);
 if(strlen($string) > $length)
 $string = (preg_match('/^(.*)\W.*$/', substr($string, 0, $length+1), $matches) ? $matches[1] : substr($string, 0, $length)) . $replacer;
 echo $string;
}

/*-----------------------------------------------------------------------------------*/
/* Multiple Custom Excerpt Lengths
/*-----------------------------------------------------------------------------------*/

function zeitreise_excerpt($limit) {
 $excerpt = explode(' ', get_the_excerpt(), $limit);
 if (count($excerpt)>=$limit) {
 array_pop($excerpt);
 $excerpt = implode(" ",$excerpt).'...';
 } else {
 $excerpt = implode(" ",$excerpt);
 }
 $excerpt = preg_replace('`[[^]]*]`','',$excerpt);
 return $excerpt;
}

function content($limit) {
 $content = explode(' ', get_the_content(), $limit);
 if (count($content)>=$limit) {
 array_pop($content);
 $content = implode(" ",$content).'...';
 } else {
 $content = implode(" ",$content);
 }
 $content = preg_replace('/[.+]/','', $content);
 $content = apply_filters('the_content', $content);
 $content = str_replace(']]>', ']]&gt;', $content);
 return $content;
}


/*-----------------------------------------------------------------------------------*/
/* Add custom max excerpt lengths.
/*-----------------------------------------------------------------------------------*/

function custom_excerpt_length( $length ) {
	return 70;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );


/*-----------------------------------------------------------------------------------*/
/* Replace "[...]" with custom read more in excerpts.
/*-----------------------------------------------------------------------------------*/

function zeitreise_excerpt_more( $more ) {
	global $post;
	return '&hellip;';
}
add_filter( 'excerpt_more', 'zeitreise_excerpt_more' );



/*-----------------------------------------------------------------------------------*/
/* Add Theme Customizer CSS
/*-----------------------------------------------------------------------------------*/

function zeitreise_customize_css() {
		?>
	<style type="text/css">
	<?php if ('' != get_theme_mod( 'zeitreise_slideone_image' ) ) { ?>
	#slideone {background-image: url('<?php echo get_theme_mod('zeitreise_slideone_image'); ?>');}
	<?php } ?>
	<?php if ('' != get_theme_mod( 'zeitreise_slidetwo_image' ) ) { ?>
	#slidetwo {background-image: url('<?php echo get_theme_mod('zeitreise_slidetwo_image'); ?>');}
	<?php } ?>
	<?php if ('' != get_theme_mod( 'zeitreise_slidethree_image' ) ) { ?>
	#slidethree {background-image: url('<?php echo get_theme_mod('zeitreise_slidethree_image'); ?>');}
	<?php } ?>
	<?php if ('' != get_theme_mod( 'zeitreise_slidefour_image' ) ) { ?>
	#slidefour {background-image: url('<?php echo get_theme_mod('zeitreise_slidefour_image'); ?>');}
	<?php } ?>
	<?php if ('' != get_theme_mod( 'zeitreise_slidefive_image' ) ) { ?>
	#slidefive {background-image: url('<?php echo get_theme_mod('zeitreise_slidefive_image'); ?>');}
	<?php } ?>

	<?php if ('' != get_theme_mod( 'zeitreise_header_slogan' ) &&  is_front_page() ) { ?>
		p.header-slogan {display: block;}
	<?php } ?>

	<?php if ('' != get_theme_mod( 'zeitreise_header_lighttext' ) &&  is_front_page() ) { ?>
		#site-branding,
		#site-branding a,
		.slide-text,
		.slide-text a,
		#overlay-open.header-white {
			color: #fff;
		}
	<?php } ?>

	.entry-content a, .widget p a, .textwidget a {color: <?php echo get_theme_mod('link_color'); ?>;}

	<?php if ('#000000' != get_theme_mod( 'overlay_bg_color' ) ) { ?>
	#overlay-wrap, .pace .pace-progress, .testimonials-wrap {background: <?php echo get_theme_mod('overlay_bg_color'); ?>;}
	<?php } ?>

	</style>
		<?php
}
add_action( 'wp_head', 'zeitreise_customize_css');


/*-----------------------------------------------------------------------------------*/
/* Remove inline styles printed when the gallery shortcode is used.
/*-----------------------------------------------------------------------------------*/

add_filter('use_default_gallery_style', '__return_false');


if ( ! function_exists( 'zeitreise_comment' ) ) :



/*-----------------------------------------------------------------------------------*/
/* Comments template zeitreise_comment
/*-----------------------------------------------------------------------------------*/
function zeitreise_comment( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	switch ( $comment->comment_type ) :
		case '' :
	?>

	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
		<div id="comment-<?php comment_ID(); ?>" class="comment">
			<div class="comment-avatar">
				<?php echo get_avatar( $comment, 60 ); ?>
			</div>

			<div class="comment-wrap">
				<div class="comment-details">
					<div class="comment-author">

						<?php printf( ( '%s' ), wp_kses_post( sprintf( '%s', get_comment_author_link() ) ) ); ?>
					</div><!-- end .comment-author -->
					<div class="comment-meta">
						<span class="comment-time"><a href="<?php echo esc_url( get_comment_link( $comment->comment_ID ) ); ?>">
							<?php
							/* translators: 1: date */
								printf( esc_html__( '%1$s', 'zeitreise' ),
								get_comment_date());
							?></a>
						</span>
						<?php edit_comment_link( esc_html__(' Edit', 'zeitreise'), '<span class="comment-edit">', '</span>'); ?>
					</div><!-- end .comment-meta -->
				</div><!-- end .comment-details -->

				<div class="comment-text">
				<?php comment_text(); ?>
					<?php if ( $comment->comment_approved == '0' ) : ?>
						<p class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'zeitreise' ); ?></p>
					<?php endif; ?>
				</div><!-- end .comment-text -->
				<?php if ( comments_open () ) : ?>
					<div class="comment-reply"><?php comment_reply_link( array_merge( $args, array( 'reply_text' => esc_html__( 'Reply', 'zeitreise' ), 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?></div>
				<?php endif; ?>
			</div><!-- end .comment-wrap -->
		</div><!-- end .comment -->

	<?php
			break;
		case 'pingback'  :
		case 'trackback' :
	?>
	<li class="pingback">
		<p><?php esc_html_e( 'Pingback:', 'zeitreise' ); ?> <?php comment_author_link(); ?></p>
		<p class="pingback-edit"><?php edit_comment_link(); ?></p>
	<?php
			break;
	endswitch;
}
endif;


/*-----------------------------------------------------------------------------------*/
/* Register widgetized areas
/*-----------------------------------------------------------------------------------*/

function zeitreise_widgets_init() {

	register_sidebar( array (
		'name' => esc_html__( 'Overlay Widget Area', 'zeitreise' ),
		'id' => 'sidebar-overlay',
		'description' => esc_html__( 'Widgets appear in the right column of the black overlay area.', 'zeitreise' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array (
		'name' => esc_html__( 'Team Widget Area', 'zeitreise' ),
		'id' => 'team',
		'description' => esc_html__( 'Widget area to include the Team widget.', 'zeitreise' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array (
		'name' => esc_html__( 'Footer (left)', 'zeitreise' ),
		'id' => 'footer-1',
		'description' => esc_html__( 'Widgets will appear in the left-aligned column of the 3-column footer.', 'zeitreise' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array (
		'name' => esc_html__( 'Footer (center)', 'zeitreise' ),
		'id' => 'footer-2',
		'description' => esc_html__( 'Widgets will appear in the center column of the 3-column footer.', 'zeitreise' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array (
		'name' => esc_html__( 'Footer (right)', 'zeitreise' ),
		'id' => 'footer-3',
		'description' => esc_html__( 'Widgets will appear in the right-aligned column of the 3-column footer.', 'zeitreise' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

}
add_action( 'widgets_init', 'zeitreise_widgets_init' );


/*-----------------------------------------------------------------------------------*/
/* Extends the default WordPress body classes
/*-----------------------------------------------------------------------------------*/
function zeitreise_body_class( $classes ) {

	if ( is_page_template( 'page-templates/front-page.php' ) ) {
		$classes[] = 'template-front';
	}

	if ( !is_page_template( 'page-templates/front-page.php' ) ) {
		$classes[] = 'not-front';
	}

	if ( is_page_template( 'page-templates/full-width.php' ) ) {
		$classes[] = 'fullwidth';
	}

	if ( is_page_template( 'page-templates/portfolio-page.php' ) ) {
		$classes[] = 'portfolio-template';
	}

	if ( is_page_template( 'page-templates/team-page.php' ) ) {
		$classes[] = 'team-template';
	}

	if ( is_page_template( 'page-templates/services-page.php' ) ) {
		$classes[] = 'services-template';
	}

	if ( '' != get_theme_mod( 'zeitreise_slideone_image' ) ) {
		$classes[] = 'headerslider';
	}

	if ( '' != get_theme_mod( 'zeitreise_slidetwo_image' ) ) {
		$classes[] = 'headerslider';
	}

	if ( '' != get_theme_mod( 'zeitreise_slidethree_image' ) ) {
		$classes[] = 'headerslider';
	}

	if ( '' != get_theme_mod( 'zeitreise_slidefour_image' ) ) {
		$classes[] = 'headerslider';
	}

	if ( '' != get_theme_mod( 'zeitreise_slidefive_image' ) ) {
		$classes[] = 'headerslider';
	}

	if ('two-columns' == get_theme_mod( 'zeitreise_portfolio_grid' ) ) {
		$classes[] = 'masonry';
	}

	if ('two-columns' == get_theme_mod( 'zeitreise_portfolio_grid' ) ) {
		$classes[] = 'masonry';
	}

	if ('three-columns' == get_theme_mod( 'zeitreise_portfolio_grid' ) ) {
		$classes[] = 'masonry';
	}

	if ('one-column' == get_theme_mod( 'zeitreise_portfolio_grid' ) ) {
		$classes[] = 'portfolio-one-column';
	}

	if ('two-columns' == get_theme_mod( 'zeitreise_portfolio_grid' ) ) {
		$classes[] = 'two-columns';
	}

	if ('three-columns' == get_theme_mod( 'zeitreise_portfolio_grid' ) ) {
		$classes[] = 'three-columns';
	}

	if ('two-columns' == get_theme_mod( 'zeitreise_teammember_columns' ) ) {
		$classes[] = 'team-twocolumns';
	}

	if ('three-columns' == get_theme_mod( 'zeitreise_teammember_columns' ) ) {
		$classes[] = 'team-threecolumns';
	}

	if ('four-columns' == get_theme_mod( 'zeitreise_teammember_columns' ) ) {
		$classes[] = 'team-fourcolumns';
	}

	return $classes;
}
add_filter( 'body_class', 'zeitreise_body_class' );


/*-----------------------------------------------------------------------------------*/
/* Customizer additions
/*-----------------------------------------------------------------------------------*/
require get_template_directory() . '/inc/customizer.php';

/*-----------------------------------------------------------------------------------*/
/* Load Jetpack compatibility file.
/*-----------------------------------------------------------------------------------*/
require get_template_directory() . '/inc/jetpack.php';

/*-----------------------------------------------------------------------------------*/
/* Grab the Zeitreise Custom shortcodes.
/*-----------------------------------------------------------------------------------*/
require( get_template_directory() . '/inc/shortcodes.php' );

/*-----------------------------------------------------------------------------------*/
/* Grab the Zeitreise Custom widgets.
/*-----------------------------------------------------------------------------------*/
require( get_template_directory() . '/inc/widgets.php' );

/*-----------------------------------------------------------------------------------*/
/* Add One Click Demo Import code.
/*-----------------------------------------------------------------------------------*/
require get_template_directory() . '/inc/demo-installer.php';
