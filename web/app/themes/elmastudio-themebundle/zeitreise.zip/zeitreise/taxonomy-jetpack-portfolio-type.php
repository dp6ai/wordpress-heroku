<?php
/**
 * The template for displaying Archive pages for Portfolio items.
 *
 * @package Zeitreise
 * @since Zeitreise 1.0
 * @version 1.0
 */

get_header(); ?>

	<div id="primary" class="site-content cf test" role="main">

		<?php if ( have_posts() ) : ?>
		
		<header class="archive-header">
			<h1 class="archive-title">
				<?php printf( esc_html__( 'All projects filed under &lsquo;%s&rsquo;', 'zeitreise' ), '<span>' . single_term_title( '', false ) . '</span>' ); ?>
			</h1>
		</header><!-- end .archive-header -->

		<?php /* Start the Loop */ ?>

			<div class="portfolio-wrap cf">
				<div class="masonry-container">

				<?php while ( have_posts() ) : the_post(); ?>

					<?php get_template_part( 'template-parts/content', 'portfolio' ); ?>

				<?php endwhile; ?>

				<?php // Previous/next page navigation.
				the_posts_pagination( array(
					'next_text' => '<span class="meta-nav">' . __( 'Next', 'zeitreise' ) . '</span> ' .
					'<span class="screen-reader-text">' . __( 'Next', 'zeitreise' ) . '</span> ',
					'prev_text' => '<span class="meta-nav">' . __( 'Previous', 'zeitreise' ) . '</span> ' .
					'<span class="screen-reader-text">' . __( 'Previous', 'zeitreise' ) . '</span> ' .
					'<span class="project-title">%title</span>',
					'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'zeitreise' ) . ' </span>',
				) ); ?>
			
				</div><!-- end .masonry-container -->
			</div><!-- .portfolio-wrap -->

		<?php endif; ?>

	</div><!-- end #primary -->

<?php get_footer(); ?>
