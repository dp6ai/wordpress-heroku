<?php
/**
 *
 * @package Zeitreise
 * @since Zeitreise 1.0
  * @version 1.0
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('cf'); ?>>

	<header id="portfolio-header" class="entry-header portfolio-header">
		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
		<div class="entry-meta cf">
		<?php
			echo get_the_term_list( $post->ID, 'jetpack-portfolio-tag', '<div class="entry-tags"><span> '. __( 'Tagged: ', 'zeitreise' ) .' </span> ', ', ', '</div>' );
		?>
		<?php
			echo get_the_term_list( get_the_ID(), 'jetpack-portfolio-type', '<div class="entry-cats"><span> '. __( 'Filed under: ', 'zeitreise' ) .' </span> ', ', ','</div>' );
		?>
		<?php edit_post_link( __( 'Edit', 'zeitreise' ), '<span class="edit-link">', '</span>' ); ?>

	</div><!-- end .entry-meta -->
	</header><!-- end .entry-header -->

	<div class="content-wrap">
		<div class="entry-thumbnail">
			<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
		</div><!-- end .entry-thumbnail -->

		<div class="entry-content">
			<?php the_content( __( 'Continue reading <span class="meta-nav">&rarr;</span>', 'zeitreise' ) ); ?>
			<?php
				wp_link_pages( array(
					'before' => '<div class="page-links">' . __( 'Pages:', 'zeitreise' ),
					'after'  => '</div>',
				) );
			?>
		</div><!-- end .entry-content -->
	</div><!-- emd .content-wrap -->

</article><!-- #post-## -->
