<?php
/**
 * The template for the latest posts on the Front page
 *
 * @subpackage Zeitreise
 * @since Zeitreise 1.0
 * @version 1.0
 */
?>

<?php
	// Get a number of Front page recent posts set in the customizer
	$postnumber = get_theme_mod('zeitreise_postnumber');

		$args = array(
			'posts_per_page' => $postnumber,
			'post_status'	 => 'publish',
	);

	$zeitreise_front_query = new WP_Query( $args );
?>

	<div id="front-blog" class="front-section cf">

		<?php if ( get_theme_mod( 'zeitreise_postsfront_title' ) ) : ?>
			<h3 class="section-title fadethis"><?php esc_html_e( get_theme_mod( 'zeitreise_postsfront_title' ) ); ?></h3>
		<?php else : ?>
			<h3 class="section-title fadethis"><?php esc_html_e('Insights', 'zeitreise') ?></h3>
		<?php endif; // custom Recent Posts title ?>

		<?php // The Loop
		if($zeitreise_front_query->have_posts()) : ?>
	  		<?php while($zeitreise_front_query->have_posts()) : $zeitreise_front_query->the_post() ?>

	  		<?php if (is_sticky()) : ?>

		  	 <div class="sticky-post-wrap cf">
				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<div class="entry-thumbnail fadethis">
						<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('zeitreise-big'); ?></a>
					</div><!-- end .entry-thumbnail -->
					<div class="entry-title-wrap fadethis">
						<header class="entry-header">
				   			<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
				   		</header><!-- end .entry-header -->
						<footer class="entry-meta">
							<div class="entry-date">
								<a href="<?php the_permalink(); ?>"><?php echo get_the_date(); ?></a>
							</div><!-- end .entry-date -->
							<?php edit_post_link( esc_html__( 'Edit', 'zeitreise' ), '<div class="entry-edit">', '</div>' ); ?>
						</footer><!-- end .entry-meta -->
					</div><!-- end .entry-title-wrap -->
						<div class="entry-summary fadethis">
							<?php the_excerpt(); ?>
						</div><!-- end .entry-summary -->
				</article><!-- #post-## -->
		  	 </div><!-- end .sticky-post-wrap -->

		  	 <?php else : ?>

	  	 	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<div class="entry-thumbnail fadethis">
					<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('zeitreise-small'); ?></a>
				</div><!-- end .entry-thumbnail -->
				<div class="entry-text-wrap fadethis">
					<header class="entry-header">
			   			<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
			   		</header><!-- end .entry-header -->
					<footer class="entry-meta">
						<div class="entry-date">
							<a href="<?php the_permalink(); ?>"><?php echo get_the_date(); ?></a>
						</div><!-- end .entry-date -->
						<?php edit_post_link( esc_html__( 'Edit', 'zeitreise' ), '<div class="entry-edit">', '</div>' ); ?>
					</footer><!-- end .entry-meta -->
				</div><!-- end .entry-text-wrap -->
			</article><!-- #post-## -->

			<?php endif; // is_sticky() ?>

		<?php endwhile; ?>
		<?php
		/* Restore original Post Data */
			wp_reset_postdata();
		?>
	</div><!-- end #front-blog -->
<?php endif; // have_posts() blog ?>
