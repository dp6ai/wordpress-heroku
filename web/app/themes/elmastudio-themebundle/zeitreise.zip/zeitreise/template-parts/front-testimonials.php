<?php
/**
 * The template for testimonials on the Front page
 *
 * @subpackage Zeitreise
 * @since Zeitreise 1.0
 * @version 1.0
 */
?>

<?php
	// Get a number of Front page portfolio items from the customizer options
	$testimonialsnumber = get_theme_mod('zeitreise_testimonialnumber');

	$zeitreise_testimonials = new WP_Query( array(
		'post_type'      => 'jetpack-testimonial',
		'posts_per_page' => $testimonialsnumber,
		'no_found_rows'  => true,
	) );
?>

<?php if ( $zeitreise_testimonials->have_posts() ) : ?>

	<div id="front-testimonials" class="front-section cf">
		
		<?php if ( get_theme_mod( 'zeitreise_testimonials_title' ) ) : ?>
			<h3 class="section-title fadethis"><?php esc_html_e( get_theme_mod( 'zeitreise_testimonials_title' ) ); ?></h3>
		<?php else : ?>
			<h3 class="section-title fadethis"><?php esc_html_e('Testimonials', 'zeitreise') ?></h3>
		<?php endif; // custom Testimonials title ?>

		<div class="testimonials-wrap fadethis">
			<div class="slider-container">
				<?php while ( $zeitreise_testimonials->have_posts() ) : $zeitreise_testimonials->the_post() ?>
				<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<div class="testimonial-content">
						<?php the_content(); ?>
					</div>
					<?php the_title(  sprintf( '<p class="testimonial-title">'), '</p>' ); ?>
				</div><!-- #post-## -->
				<?php
				/* Restore original Post Data */
					wp_reset_postdata();
				?>
			<?php endwhile; ?>
			</div><!-- end .slider-container -->
		</div><!-- end .testimonials-wrap -->

	</div><!-- end #front-testimonials -->

<?php endif; // have_posts() testimonials ?>
