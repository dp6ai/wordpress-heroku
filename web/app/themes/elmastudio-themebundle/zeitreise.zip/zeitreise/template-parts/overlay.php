<?php
/**
 * The template for for the Overlay area
 *
 * @package Zeitreise
 * @since Zeitreise 1.0
  * @version 1.0
 */
?>

<button id="overlay-open" class="overlay-btn"><span><?php esc_html_e( 'Menu', 'zeitreise' ); ?></span></button>
<div id="overlay-wrap" class="overlay-wrap cf">
	<div class="nav-sidebar-wrap cf">
		<nav id="site-nav" class="main-navigation cf" role="navigation">
			<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_id' => 'primary-menu', 'menu_class' => 'nav-menu', 'container' => 'false' ) ); ?>
		</nav><!-- end #site-nav -->
		<?php get_sidebar( 'overlay' ); ?>
	</div><!-- end .nav-sidebar-wrap -->
	<button id="overlay-close" class="overlay-btn"><span><?php esc_html_e( 'Close', 'zeitreise' ); ?></span></button>
</div><!-- end #overlay-wrap -->
