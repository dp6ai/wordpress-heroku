<?php
/**
 * The template for displaying Portfolio projects
 *
 * @package Zeitreise
 * @since Zeitreise 1.0
 * @version 1.0
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('cf'); ?>>
	<div class="portfolio-thumbnail">
		<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('zeitreise-portfolio'); ?></a>
	</div><!-- end .entry-thumbnail -->
	<header class="portfolio-header">
		<div class="centered-wrap">
			<div class="centered">
				<?php the_title( sprintf( '<h2 class="portfolio-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
			</div><!-- end .centered -->
		</div><!-- end .centered-wrap -->
	</header>		
</article><!-- end .project -->
