<?php
/**
 * The template for portfolio projects on the Front page
 *
 * @subpackage Zeitreise
 * @since Zeitreise 1.0
 * @version 1.0
 */
?>

<?php
	// Get a number of Front page portfolio items from the customizer options
	$portfolionumber = get_theme_mod('zeitreise_portfolionumber');

	$zeitreise_portfolio = new WP_Query( array(
		'post_type'      => 'jetpack-portfolio',
		'posts_per_page' => $portfolionumber,
		'no_found_rows'  => true,
	) );
?>

<?php if ( $zeitreise_portfolio->have_posts() ) : ?>

	<div id="front-portfolio" class="front-section cf">

		<?php if ( get_theme_mod( 'zeitreise_portfolio_title' ) ) : ?>
			<h3 class="section-title fadethis"><?php esc_html_e( get_theme_mod( 'zeitreise_portfolio_title' ) ); ?></h3>
		<?php else : ?>
			<h3 class="section-title fadethis"><?php esc_html_e('Selected Projects', 'zeitreise') ?></h3>
		<?php endif; // custom Portfolio title ?>

		<div class="portfolio-wrap">
		<?php while ( $zeitreise_portfolio->have_posts() ) : $zeitreise_portfolio->the_post() ?>
			<div id="post-<?php the_ID(); ?>" <?php post_class('cf'); ?>>
				<div class="portfolio-thumbnail fadethis">
					<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('zeitreise-portfolio'); ?></a>
				</div><!-- end .entry-thumbnail -->
				<header class="portfolio-header">
					<div class="centered-wrap">
						<div class="centered">
							<?php the_title( sprintf( '<h2 class="portfolio-title fadethis"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
							<?php
								echo get_the_term_list( get_the_ID(), 'jetpack-portfolio-type', '<div class="entry-cats fadethis"> ', ', ','</div>' );
							?>
						</div><!-- end .centered -->
					</div><!-- end .centered-wrap -->
				</header>
			</div><!-- #post-## -->
			<?php
			/* Restore original Post Data */
				wp_reset_postdata();
			?>
		<?php endwhile; ?>
		</div><!-- .portfolio-wrap -->

		<?php if( get_theme_mod ( 'zeitreise_portfolio_text' ) ) : ?>
			<div class="portfolio-text-wrap">
				<?php echo wpautop( get_theme_mod( 'zeitreise_portfolio_text' ) ); ?>
			</div><!-- end .portfolio-text-wrap -->
		<?php endif; // Portfolio text in the customizer is used ?>
	</div><!-- end #front-portfolio -->

<?php endif; // have_posts() portfolio ?>
