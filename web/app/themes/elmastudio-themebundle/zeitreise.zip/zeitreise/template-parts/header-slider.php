<?php
/**
 * The template for for the Header slider
 *
 * @package Zeitreise
 * @since Zeitreise 1.0
  * @version 1.0
 */
?>

<div class="header-slider">
	<?php if ( '' != get_theme_mod( 'zeitreise_slideone_image' ) ) : ?>
		<div id="slideone" class="slide-img">
			<div class="slide-content">
				<p class="slide-text"><a href="<?php echo wp_kses_post( get_theme_mod( 'zeitreise_slideone_link' ) ); ?>"><?php echo wp_kses_post( get_theme_mod( 'zeitreise_slideone_text' ) ); ?></a></p>
			</div>
		</div><!-- end #slideone -->
	<?php endif; ?>

	<?php if ( '' != get_theme_mod( 'zeitreise_slidetwo_image' ) ) : ?>
		<div id="slidetwo" class="slide-img">
			<div class="slide-content">
				<p class="slide-text"><a href="<?php echo wp_kses_post( get_theme_mod( 'zeitreise_slidetwo_link' ) ); ?>"><?php echo wp_kses_post( get_theme_mod( 'zeitreise_slidetwo_text' ) ); ?></a></p>
			</div>
		</div><!-- end #slidetwo -->
	<?php endif; ?>
	
	<?php if ( '' != get_theme_mod( 'zeitreise_slidethree_image' ) ) : ?>
		<div id="slidethree" class="slide-img">
			<div class="slide-content">
				<p class="slide-text"><a href="<?php echo wp_kses_post( get_theme_mod( 'zeitreise_slidethree_link' ) ); ?>"><?php echo wp_kses_post( get_theme_mod( 'zeitreise_slidethree_text' ) ); ?></a></p>
			</div>
		</div><!-- end #slidethree -->
	<?php endif; ?>
	
	<?php if ( '' != get_theme_mod( 'zeitreise_slidefour_image' ) ) : ?>
		<div id="slidefour" class="slide-img">
			<div class="slide-content">
				<p class="slide-text"><a href="<?php echo wp_kses_post( get_theme_mod( 'zeitreise_slidefour_link' ) ); ?>"><?php echo wp_kses_post( get_theme_mod( 'zeitreise_slidefour_text' ) ); ?></a></p>
			</div>
		</div><!-- end #slidefour -->
	<?php endif; ?>
	
	<?php if ( '' != get_theme_mod( 'zeitreise_slidefive_image' ) ) : ?>
		<div id="slidefive" class="slide-img">
			<div class="slide-content">
				<p class="slide-text"><a href="<?php echo wp_kses_post( get_theme_mod( 'zeitreise_slidefive_link' ) ); ?>"><?php echo wp_kses_post( get_theme_mod( 'zeitreise_slidefive_text' ) ); ?></a></p>
			</div>
		</div><!-- end #slidefive -->
	<?php endif; ?>
</div><!-- end .header-slider -->
