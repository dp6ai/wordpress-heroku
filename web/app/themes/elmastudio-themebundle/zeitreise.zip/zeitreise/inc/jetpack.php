<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package Zeitreise
 * @since Zeitreise 1.0
 * @version 1.0
 */

function zeitreise_jetpack_setup() {

	/**
		* Add theme support for Portfolio and Testimonials.
	*/
	add_theme_support( 'jetpack-portfolio' );
	add_theme_support( 'jetpack-testimonial' );

	/**
		* Add theme support for Responsive Videos.
	*/
    add_theme_support( 'jetpack-responsive-videos' );

	/**
		* Add theme support for Infinite Scroll.
 	*/
	add_theme_support( 'infinite-scroll', array(
		'container' 		=> 'primary',
		'footer_widgets' 	=> array( 'footer-one', 'footer-two', 'footer-three' ),
		'footer'    		=> 'main-wrap',
	) );
}
add_action( 'after_setup_theme', 'zeitreise_jetpack_setup' );


/**
 * Load Jetpack scripts.
 */
function zeitreise_jetpack_scripts() {
{
		wp_enqueue_script( 'zeitreise-portfolio', get_template_directory_uri() . '/js/portfolio.js', array( 'jquery', 'masonry' ), '20151015', true );
	}
}
add_action( 'wp_enqueue_scripts', 'zeitreise_jetpack_scripts' );
