<?php
/**
 * Available Zeitreise Custom Widgets
 *
 * @package Zeitreise
 * @since Zeitreise 1.0
  * @version 1.0
 */


/*-----------------------------------------------------------------------------------*/
/* Zeitreise Team Widget
/*-----------------------------------------------------------------------------------*/

class zeitreise_team extends WP_Widget {

	public function __construct() {
		parent::__construct( 'widget_zeitreise_team', esc_html__( 'Team Member (Zeitreise)', 'zeitreise' ), array(
			'classname'   => 'widget_zeitreise_team',
			'description' => esc_html__( 'Show a Team member with profile image and team position.', 'zeitreise' ),
		) );
	}

	public function widget($args, $instance) {
		extract( $args );
		$title = $instance['title'];
		$teamimg = $instance['teamimg'];
		$teamposition = $instance['teamposition'];
		$teamtext = $instance['teamtext'];
		$teamlink = $instance['teamlink'];
		$teamid = $instance['teamid'];

		echo $before_widget; ?>

		<div class="team-member cf fadethis">
			<?php if ( ($teamlink != '') && ($teamimg != '') ) : ?>
				<a href="<?php echo ( esc_url($teamlink)  ); ?>" class="team-img-link"><img src="<?php echo ( esc_url($teamimg)  ); ?>" class="team-img" alt="team-member-profile"></a>
			<?php elseif  ( ($teamimg != '') ) : ?>
				<img src="<?php echo ( esc_url($teamimg)  ); ?>" class="team-img" alt="team-member-profile">
			<?php endif; ?>

			<div class="team-name-wrap">
				
				<?php if ( is_page_template( 'page-templates/team-page.php' ) && ($teamid != '') ) : ?>
					<h3 id="<?php echo ( esc_html($teamid)  ); ?>" class="widget-title"><span><?php echo ( esc_html($title)  ); ?></span></h3>
				<?php else : ?>
					<h3 class="widget-title"><a href="<?php echo ( esc_url($teamlink)  ); ?>"><?php echo ( esc_html($title)  ); ?></a></h3>
				<?php endif; ?>
			
				<?php if($teamposition != '') {
					echo '<div class="team-position"> ' . ( wp_kses_post($teamposition) ) . ' </div>';
				}
				?>
				<?php if ( ($teamtext != '') && is_page_template( 'page-templates/team-page.php' ) ) {
					echo '<div class="team-text"> ' . (wp_kses_post(wpautop($teamtext)) )  . ' </div>';
				}
				?>
			</div><!-- end .team-name-wrap -->
		</div><!-- end .team-member -->

	   <?php
	   echo $after_widget;

	   // Reset the post globals as this query will have stomped on it
	   wp_reset_postdata();
	   }

   function update($new_instance, $old_instance) {

   		$instance['title'] = $new_instance['title'];
   		$instance['teamimg'] = $new_instance['teamimg'];
   		$instance['teamposition'] = $new_instance['teamposition'];
   		$instance['teamtext'] = $new_instance['teamtext'];
   		$instance['teamlink'] = $new_instance['teamlink'];
   		$instance['teamid'] = $new_instance['teamid'];

       return $new_instance;
   }

   function form($instance) {
   		$title = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
   		$teamimg = isset( $instance['teamimg'] ) ? esc_attr( $instance['teamimg'] ) : '';
   		$teamposition = isset( $instance['teamposition'] ) ? esc_attr( $instance['teamposition'] ) : '';
   		$teamtext = isset( $instance['teamtext'] ) ? esc_attr( $instance['teamtext'] ) : '';
   		$teamlink = isset( $instance['teamlink'] ) ? esc_attr( $instance['teamlink'] ) : '';
   		$teamid = isset( $instance['teamid'] ) ? esc_attr( $instance['teamid'] ) : '';
	?>

	<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php esc_html_e('Team Member Name:','zeitreise'); ?></label>
		<input type="text" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo esc_attr($title); ?>" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" />
	</p>

	<p>
	<label for="<?php echo $this->get_field_id('teamimg'); ?>"><?php esc_html_e('Profile Image URL:','zeitreise'); ?></label>
	<input type="text" name="<?php echo $this->get_field_name('teamimg'); ?>" value="<?php echo esc_attr($teamimg); ?>" class="widefat" id="<?php echo $this->get_field_id('teamimg'); ?>" />
	</p>

	<p>
	<label for="<?php echo $this->get_field_id('teamposition'); ?>"><?php esc_html_e('Position (optional):','zeitreise'); ?></label>
	<input type="text" name="<?php echo $this->get_field_name('teamposition'); ?>" value="<?php echo esc_attr($teamposition); ?>" class="widefat" id="<?php echo $this->get_field_id('teamposition'); ?>" />
	</p>

	<p>
	<label for="<?php echo $this->get_field_id('teamtext'); ?>"><?php esc_html_e('About text (optional):','zeitreise'); ?></label>
	<textarea name="<?php echo esc_attr( $this->get_field_name('teamtext') ); ?>" class="widefat" rows="8" cols="12" id="<?php echo esc_attr( $this->get_field_id('teamtext') ); ?>"><?php echo $teamtext; ?></textarea>
	</p>

	<p>
	<label for="<?php echo $this->get_field_id('teamlink'); ?>"><?php esc_html_e('Link to Team Members Profile on Team Page (optional):','zeitreise'); ?></label>
	<input type="text" name="<?php echo $this->get_field_name('teamlink'); ?>" value="<?php echo esc_url($teamlink); ?>" class="widefat" id="<?php echo $this->get_field_id('teamlink'); ?>" />
	</p>
	
	<p>
	<label for="<?php echo $this->get_field_id('teamid'); ?>"><?php esc_html_e('ID of Team Members Profile on Team Page (optional):','zeitreise'); ?></label>
	<input type="text" name="<?php echo $this->get_field_name('teamid'); ?>" value="<?php echo esc_attr($teamid); ?>" class="widefat" id="<?php echo $this->get_field_id('teamid'); ?>" />
	</p>

	<?php
	}
}

register_widget('zeitreise_team');
