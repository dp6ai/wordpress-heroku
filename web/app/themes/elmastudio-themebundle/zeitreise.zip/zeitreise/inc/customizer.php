<?php
/**
 * Implement Theme Customizer additions and adjustments.
 *
 * @package Zeitreise
 * @since Zeitreise 1.0
 * @version 1.0.1
 */


function zeitreise_customize_register( $wp_customize ) {

	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';

	// Rename the label to "Site Title Color" because this only affects the site title in this theme.
	$wp_customize->get_control( 'header_textcolor' )->label = esc_html__( 'Site Title Color', 'zeitreise' );

	$wp_customize->get_section('header_image')->title = esc_html__( 'Logo', 'zeitreise' );



	// Add custom Zeitreise panels
	$wp_customize->add_panel( 'zeitreise_themeoptions', array(
		'priority'       	=> 1,
		'capability'     	=> 'edit_theme_options',
		'theme_supports' 	=> '',
		'title'          	=> esc_html__('Theme Options', 'zeitreise'),
		'description'    	=> esc_html__('Several settings pertaining my theme', 'zeitreise'),
	) );

	$wp_customize->add_panel( 'zeitreise_headerslider', array(
		'priority'       	=> 2,
		'theme_supports' 	=> '',
		'title'          	=> esc_html__('Front Page Header Images', 'zeitreise'),
		'description'    	=> esc_html__('include an image slider or one big header image on the Front page', 'zeitreise'),
	) );

	// Zeitreise Theme Options Sections
	$wp_customize->add_section( 'zeitreise_general', array(
		'title'        		=> esc_html__( 'General', 'zeitreise' ),
		'priority'      	=> 1,
		'panel'  			=> 'zeitreise_themeoptions',
	) );

	$wp_customize->add_section( 'zeitreise_frontpage', array(
		'title'         	=> esc_html__( 'Front Page', 'zeitreise' ),
		'priority'      	=> 2,
		'panel'  			=> 'zeitreise_themeoptions',
	) );

	$wp_customize->add_section( 'zeitreise_portfolio', array(
		'title'         	=> esc_html__( 'Portfolio Page', 'zeitreise' ),
		'priority'			=> 4,
		'panel'  			=> 'zeitreise_themeoptions',
	) );

	// Zeitreise Header Slider Sections
	$wp_customize->add_section( 'zeitreise_headerslider_slideone', array(
		'title'				=> esc_html__( '1. Slide', 'zeitreise' ),
		'priority'			=> 1,
		'panel'  			=> 'zeitreise_headerslider',
	) );

	$wp_customize->add_section( 'zeitreise_headerslider_slidetwo', array(
		'title'				=> esc_html__( '2. Slide', 'zeitreise' ),
		'priority'			=> 2,
		'panel'  			=> 'zeitreise_headerslider',
	) );

	$wp_customize->add_section( 'zeitreise_headerslider_slidethree', array(
		'title'				=> esc_html__( '3. Slide', 'zeitreise' ),
		'priority'			=> 3,
		'panel'  			=> 'zeitreise_headerslider',
	) );

	$wp_customize->add_section( 'zeitreise_headerslider_slidefour', array(
		'title'				=> esc_html__( '4. Slide', 'zeitreise' ),
		'priority'			=> 4,
		'panel'  			=> 'zeitreise_headerslider',
	) );

	$wp_customize->add_section( 'zeitreise_headerslider_slidefive', array(
		'title'				=> esc_html__( '5. Slide', 'zeitreise' ),
		'priority'			=> 5,
		'panel'  			=> 'zeitreise_headerslider',
	) );



	// Add the custom settings and controls.
	$wp_customize->add_setting( 'header_background_color', array(
		'default'           => '#ffffff',
		'sanitize_callback' => 'sanitize_hex_color',
		'transport'         => 'refresh',
	) );


	// Custom Colors.
	$wp_customize->add_setting( 'link_color' , array(
    	'default'     		=> '#555555',
    	'sanitize_callback' => 'sanitize_hex_color',
		'transport'   		=> 'refresh',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'link_color', array(
		'label'				=> esc_html__( 'Link Color', 'zeitreise' ),
		'section'			=> 'colors',
		'settings'			=> 'link_color',
	) ) );

	$wp_customize->add_setting( 'overlay_bg_color' , array(
    	'default'     		=> '#000000',
    	'sanitize_callback' => 'sanitize_hex_color',
		'transport'   		=> 'refresh',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'overlay_bg_color', array(
		'label'				=> esc_html__( 'Dark Background Colors', 'zeitreise' ),
		'description'		=> esc_html__( '(customize menu overlay and testimonials background colors)', 'zeitreise' ),
		'section'			=> 'colors',
		'settings'			=> 'overlay_bg_color',
	) ) );


	// Theme Options - General
	$wp_customize->add_setting( 'zeitreise_archive_excerpts', array(
		'default'			=> '',
		'sanitize_callback' => 'zeitreise_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'zeitreise_archive_excerpts', array(
		'label'				=> esc_html__( 'Automatic archive excerpts', 'zeitreise' ),
		'description'		=> esc_html__( '(Show automatic excerpts on archives and search results.)', 'zeitreise' ),
		'section'			=> 'zeitreise_general',
		'type'				=> 'checkbox',
		'priority'			=> 2,
	) );

	$wp_customize->add_setting( 'zeitreise_blog_excerpts', array(
		'default'			=> '',
		'sanitize_callback' => 'zeitreise_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'zeitreise_blog_excerpts', array(
		'label'				=> esc_html__( 'Automatic blog excerpts', 'zeitreise' ),
		'description'		=> esc_html__( '(Show automatic excerpts on default blog.)', 'zeitreise' ),
		'section'			=> 'zeitreise_general',
		'type'				=> 'checkbox',
		'priority'			=> 3,
	) );

	$wp_customize->add_setting( 'zeitreise_credit_text', array(
		'default'       	=> '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'zeitreise_credit_text', array(
		'label'         	=> esc_html__( 'Footer credit text', 'zeitreise' ),
		'description'		=> esc_html__( 'Customize the footer credit text. (HTML is allowed)', 'zeitreise' ),
		'section'       	=> 'zeitreise_general',
		'type'          	=> 'text',
		'priority'			=> 4,
	) );

	// Theme Options - Front Page
	$wp_customize->add_setting( 'zeitreise_header_lighttext', array(
		'default'       	=> '',
		'sanitize_callback' => 'zeitreise_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'zeitreise_header_lighttext', array(
		'label'         	=> esc_html__( 'Light Header text color', 'zeitreise' ),
		'description'		=> esc_html__( '(Choose a light text color, if you have a dark background image).', 'zeitreise' ),
		'section'       	=> 'zeitreise_frontpage',
		'type'          	=> 'checkbox',
		'priority'			=> 1,
	) );

	$wp_customize->add_setting( 'zeitreise_postnumber', array(
		'default'       	=> '2',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'zeitreise_postnumber', array(
		'label'         	=> esc_html__( 'Number of posts', 'zeitreise' ),
		'description'		=> esc_html__( '(Sticky posts are not counted, unless they are also most recent posts.)', 'zeitreise' ),
		'section'       	=> 'zeitreise_frontpage',
		'type'          	=> 'text',
		'priority'			=> 2,
	) );

	$wp_customize->add_setting( 'zeitreise_portfolionumber', array(
		'default'       	=> '3',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'zeitreise_portfolionumber', array(
		'label'         	=> esc_html__( 'Number of Portfolio projects', 'zeitreise' ),
		'section'       	=> 'zeitreise_frontpage',
		'type'          	=> 'text',
		'priority'			=> 3,
	) );

	$wp_customize->add_setting( 'zeitreise_testimonialnumber', array(
		'default'       	=> '3',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'zeitreise_testimonialnumber', array(
		'label'         	=> esc_html__( 'Number of testimonials', 'zeitreise' ),
		'section'       	=> 'zeitreise_frontpage',
		'type'          	=> 'text',
		'priority'			=> 4,
	) );

	$wp_customize->add_setting( 'zeitreise_portfolio_text', array(
		'default'       	=> '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'zeitreise_portfolio_text', array(
		'label'         	=> esc_html__( 'Text below portfolio', 'zeitreise' ),
		'description'		=> esc_html__( '(Add text below your portfolio projects to link to your portfolio page. HTML is allowed.)', 'zeitreise' ),
		'section'       	=> 'zeitreise_frontpage',
		'type'          	=> 'textarea',
		'priority'			=> 5,
	) );

	$wp_customize->add_setting( 'zeitreise_portfolio_title', array(
		'default'       	=> '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'zeitreise_portfolio_title', array(
		'label'         	=> esc_html__( 'Portfolio Title', 'zeitreise' ),
		'description'		=> esc_html__( '(Customize the Portfolio title "Selected Projects" on the Front page.)', 'zeitreise' ),
		'section'       	=> 'zeitreise_frontpage',
		'type'          	=> 'text',
		'priority'			=> 6,
	) );

	$wp_customize->add_setting( 'zeitreise_postsfront_title', array(
		'default'       	=> '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'zeitreise_postsfront_title', array(
		'label'         	=> esc_html__( 'Recent Posts Title', 'zeitreise' ),
		'section'       	=> 'zeitreise_frontpage',
		'type'          	=> 'text',
		'priority'			=> 7,
	) );

	$wp_customize->add_setting( 'zeitreise_team_title', array(
		'default'       	=> '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'zeitreise_team_title', array(
		'label'         	=> esc_html__( 'Team Title', 'zeitreise' ),
		'section'       	=> 'zeitreise_frontpage',
		'type'          	=> 'text',
		'priority'			=> 8,
	) );

	$wp_customize->add_setting( 'zeitreise_testimonials_title', array(
		'default'       	=> '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'zeitreise_testimonials_title', array(
		'label'         	=> esc_html__( 'Testimonials Title', 'zeitreise' ),
		'section'       	=> 'zeitreise_frontpage',
		'type'          	=> 'text',
		'priority'			=> 9,
	) );

	$wp_customize->add_setting( 'zeitreise_teammember_columns', array(
		'default'      		=> 'three-column',
		'sanitize_callback' => 'zeitreise_sanitize_teammember_columns',
	) );

	$wp_customize->add_control( 'zeitreise_teammember_columns', array(
		'label'         	=> esc_html__( 'Team Member Columns', 'zeitreise' ),
		'section'       	=> 'zeitreise_frontpage',
		'priority'      	=> 10,
		'type'          	=> 'select',
		'choices' 			=> array(
        	'two-columns' 	=> esc_html__( '2-columns', 'zeitreise' ),
        	'three-columns' => esc_html__( '3-columns', 'zeitreise' ),
        	'four-columns'  => esc_html__( '4-columns', 'zeitreise' ),
		),
	) );


	// Theme Options - Portfolio Page

	$wp_customize->add_setting( 'zeitreise_portfolio_grid', array(
		'default'      		=> 'one-column',
		'sanitize_callback' => 'zeitreise_sanitize_portfolio_grid',
	) );

	$wp_customize->add_control( 'zeitreise_portfolio_grid', array(
		'label'         	=> esc_html__( 'Grid on Portfolio Page', 'zeitreise' ),
		'section'       	=> 'zeitreise_portfolio',
		'priority'      	=> 1,
		'type'          	=> 'select',
		'choices' 			=> array(
        	'one-column' 	=> esc_html__( '1-column', 'zeitreise' ),
        	'two-columns' 	=> esc_html__( '2-columns Masonry', 'zeitreise' ),
        	'three-columns' => esc_html__( '3-columns Masonry', 'zeitreise' ),
		),
	) );


	// Header Slider - Slide 1
	$wp_customize->add_setting( 'zeitreise_slideone_link', array(
		'default'       	=> '',
		'sanitize_callback' => 'esc_url_raw',
	) );

	$wp_customize->add_control( 'zeitreise_slideone_link', array(
		'label'         	=> esc_html__( 'Slide 1: Link URL', 'zeitreise' ),
		'section'       	=> 'zeitreise_headerslider_slideone',
		'type'          	=> 'text',
		'priority'			=> 1,
	) );

	$wp_customize->add_setting( 'zeitreise_slideone_text', array(
		'default'       	=> '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'zeitreise_slideone_text', array(
		'label'         	=> esc_html__( 'Slide 1: Link Text', 'zeitreise' ),
		'section'       	=> 'zeitreise_headerslider_slideone',
		'type'          	=> 'textarea',
		'priority'			=> 2,
	) );

	$wp_customize->add_setting( 'zeitreise_slideone_image', array(
		'default'       	=> '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize,'zeitreise_slideone_image', array(
        'label'      		=> esc_html__( 'Upload slide image', 'zeitreise' ),
        'section'    		=> 'zeitreise_headerslider_slideone',
        'priority'			=> 3,
	) ) );


	// Header Slider - Slide 2
	$wp_customize->add_setting( 'zeitreise_slidetwo_link', array(
		'default'       	=> '',
		'sanitize_callback' => 'esc_url_raw',
	) );

	$wp_customize->add_control( 'zeitreise_slidetwo_link', array(
		'label'         	=> esc_html__( 'Slide 2: Link URL', 'zeitreise' ),
		'section'       	=> 'zeitreise_headerslider_slidetwo',
		'type'          	=> 'text',
		'priority'			=> 1,
	) );

	$wp_customize->add_setting( 'zeitreise_slidetwo_text', array(
		'default'       	=> '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'zeitreise_slidetwo_text', array(
		'label'         	=> esc_html__( 'Slide 2: Link Text', 'zeitreise' ),
		'section'       	=> 'zeitreise_headerslider_slidetwo',
		'type'          	=> 'textarea',
		'priority'			=> 2,
	) );

	$wp_customize->add_setting( 'zeitreise_slidetwo_image', array(
		'default'       	=> '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize,'zeitreise_slidetwo_image', array(
        'label'      		=> esc_html__( 'Upload slide image', 'zeitreise' ),
        'section'			=> 'zeitreise_headerslider_slidetwo',
        'priority'			=> 3,
	) ) );


	// Header Slider - Slide 3
	$wp_customize->add_setting( 'zeitreise_slidethree_link', array(
		'default'       	=> '',
		'sanitize_callback' => 'esc_url_raw',
	) );

	$wp_customize->add_control( 'zeitreise_slidethree_link', array(
		'label'         	=> esc_html__( 'Slide 3: Link URL', 'zeitreise' ),
		'section'       	=> 'zeitreise_headerslider_slidethree',
		'type'				=> 'text',
		'priority'			=> 1,
	) );

	$wp_customize->add_setting( 'zeitreise_slidethree_text', array(
		'default'       	=> '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'zeitreise_slidethree_text', array(
		'label'         	=> esc_html__( 'Slide 3: Link Text', 'zeitreise' ),
		'section'       	=> 'zeitreise_headerslider_slidethree',
		'type'          	=> 'textarea',
		'priority'			=> 2,
	) );

	$wp_customize->add_setting( 'zeitreise_slidethree_image', array(
		'default'       	=> '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize,'zeitreise_slidethree_image', array(
        'label'      		=> esc_html__( 'Upload slide image', 'zeitreise' ),
        'section'    		=> 'zeitreise_headerslider_slidethree',
        'priority'			=> 3,
	) ) );


	// Header Slider - Slide 4
	$wp_customize->add_setting( 'zeitreise_slidefour_link', array(
		'default'       	=> '',
		'sanitize_callback' => 'esc_url_raw',
	) );

	$wp_customize->add_control( 'zeitreise_slidefour_link', array(
		'label'         	=> esc_html__( 'Slide 4: Link URL', 'zeitreise' ),
		'section'       	=> 'zeitreise_headerslider_slidefour',
		'type'          	=> 'text',
		'priority'			=> 1,
	) );

	$wp_customize->add_setting( 'zeitreise_slidefour_text', array(
		'default'       	=> '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'zeitreise_slidefour_text', array(
		'label'         	=> esc_html__( 'Slide 4: Link Text', 'zeitreise' ),
		'section'       	=> 'zeitreise_headerslider_slidefour',
		'type'          	=> 'textarea',
		'priority'			=> 2,
	) );

	$wp_customize->add_setting( 'zeitreise_slidefour_image', array(
		'default'       	=> '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize,'zeitreise_slidefour_image', array(
        'label'      		=> esc_html__( 'Upload slide image', 'zeitreise' ),
        'section'    		=> 'zeitreise_headerslider_slidefour',
        'priority'			=> 3,
	) ) );


	// Header Slider - Slide 5
	$wp_customize->add_setting( 'zeitreise_slidefive_link', array(
		'default'       	=> '',
		'sanitize_callback' => 'esc_url_raw',
	) );

	$wp_customize->add_control( 'zeitreise_slidefive_link', array(
		'label'         	=> esc_html__( 'Slide 5: Link URL', 'zeitreise' ),
		'section'       	=> 'zeitreise_headerslider_slidefive',
		'type'          	=> 'text',
		'priority'			=> 1,
	) );

	$wp_customize->add_setting( 'zeitreise_slidefive_text', array(
		'default'       	=> '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'zeitreise_slidefive_text', array(
		'label'         	=> esc_html__( 'Slide 5: Link Text', 'zeitreise' ),
		'section'       	=> 'zeitreise_headerslider_slidefive',
		'type'          	=> 'textarea',
		'priority'			=> 2,
	) );

	$wp_customize->add_setting( 'zeitreise_slidefive_image', array(
		'default'       	=> '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize,'zeitreise_slidefive_image', array(
        'label'				=> esc_html__( 'Upload slide image', 'zeitreise' ),
        'section'			=> 'zeitreise_headerslider_slidefive',
        'priority'			=> 3,
	) ) );

}
add_action( 'customize_register', 'zeitreise_customize_register' );

/**
 * Sanitize Checkboxes.
 */
function zeitreise_sanitize_checkbox( $input ) {
	if ( 1 == $input ) {
		return true;
	} else {
		return false;
	}
}

/**
 * Sanitize Porfolio Grid values.
 */
function zeitreise_sanitize_portfolio_grid( $zeitreise_portfolio_grid ) {
	if ( ! in_array( $zeitreise_portfolio_grid, array( 'one-column', 'two-columns', 'three-columns' ) ) ) {
		$zeitreise_portfolio_grid = 'one-column';
	}

	return $zeitreise_portfolio_grid;
}

/**
 * Sanitize Teammember columns values.
 */
function zeitreise_sanitize_teammember_columns( $zeitreise_teammember_columns ) {
	if ( ! in_array( $zeitreise_teammember_columns, array( 'two-columns', 'three-columns', 'four-columns' ) ) ) {
		$zeitreise_teammember_columns = 'three-columns';
	}

	return $zeitreise_teammember_columns;
}

