<?php
/**
 * The template for displaying the footer.
 *
 * @package Zeitreise
 * @since Zeitreise 1.0
 * @version 1.0
 */
?>

<footer id="colophon" class="site-footer cf">

	<div class="footer-wrap">

		<?php get_sidebar( 'footer' ); ?>
		
		<?php if (has_nav_menu( 'footer-social' ) ) : ?>
				<nav id="footer-social-nav" role="navigation">
					<?php wp_nav_menu( array('theme_location' => 'footer-social', 'container' => 'false', 'depth' => -1 ));  ?>
				</nav><!-- end #footer-social -->
			<?php endif; ?>

		<div id="site-info">
			<ul class="credit" role="contentinfo">
				<?php if ( get_theme_mod( 'zeitreise_credit_text' ) ) : ?>
					<li><?php echo wp_kses_post( get_theme_mod( 'zeitreise_credit_text' ) ); ?></li>
				<?php else : ?>
				<li class="copyright">&copy; <?php echo date('Y'); ?> <a href="<?php echo home_url( '/' ); ?>"><?php bloginfo(); ?></a></li>
				<li class="wp-credit"><?php esc_html_e('Powered by', 'zeitreise') ?> <a href="<?php echo esc_url( __( 'https://wordpress.org/', 'zeitreise' ) ); ?>" ><?php esc_html_e( 'WordPress', 'zeitreise' ); ?></a></li>
				<li class="theme-author"><?php printf( esc_html__( 'Theme: %1$s by %2$s', 'zeitreise' ), 'Zeitreise', '<a href="http://www.elmastudio.de/en/" rel="designer">Elmastudio</a>' ); ?></li>
				<?php endif; ?>
			</ul><!-- end .credit -->
		</div><!-- end #site-info -->

	</div><!-- end .footer-wrap -->

</footer><!-- end #colophon -->
</div><!-- end .main-content-container -->
</div><!-- end #container -->

<?php wp_footer(); ?>

</body>
</html>
