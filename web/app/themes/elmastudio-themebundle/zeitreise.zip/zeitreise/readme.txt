
-----------------------------------------------------------------------------------------------------------------------------------

View theme documentation:
https://www.elmastudio.de/en/themes/zeitreise/ (English)
https://www.elmastudio.de/wordpress-themes/zeitreise/ (German)

-----------------------------------------------------------------------------------------------------------------------------------

Changelog:

Version 1.0.4 (13. September 2017):
-----------------------------------------------------------------------------------------------------------------------------------
- Bugfix: Update of jQuery viewport checker script due to bug in newest Google Chrome version.
(js/jquery.viewportchecker.min.js and functions.js)

Version 1.0.3 (08/03/2017)
-----------------------------------------------------------------------------------------------------------------------------------
- New: Support for the One Click Demo Import plugin.

Version 1.0.2 (21/04/2016)
-----------------------------------------------------------------------------------------------------------------------------------
- Bugfix: Update of code in js/functions.js
- Bugfix: CSS optimization for custom logo on small screens (style.css)

Version 1.0.1 (22/12/2015)
-----------------------------------------------------------------------------------------------------------------------------------
- Bugfix: Fixed German theme translation bug (languages folder)
- Bugfix: Some smaller CSS bug fixes (style.css)


Version 1.0 (17/11/2015)
-----------------------------------------------------------------------------------------------------------------------------------
- Zeitreise theme release
