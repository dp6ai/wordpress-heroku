<?php
/**
 * The Template for displaying all single portfolio posts.
 *
 * @package Suidobashi
 */

get_header(); ?>

	<div id="primary" class="site-content cf" role="main">

		<?php while ( have_posts() ) : the_post(); ?>

			<?php get_template_part( 'template-parts/content', 'portfolio-single' ); ?>

			<?php the_post_navigation( array(
				'next_text' => '<span class="meta-nav">' . __( 'Next project', 'zeitreise' ) . '</span> ' .
					'<span class="screen-reader-text">' . __( 'Next project:', 'zeitreise' ) . '</span> ' .
					'<span class="post-title">%title</span>',
				'prev_text' => '<span class="meta-nav">' . __( 'See next project', 'zeitreise' ) . '</span> ' .
					'<span class="screen-reader-text">' . __( 'previous project:', 'zeitreise' ) . '</span> ' .
					'<span class="project-title">%title</span>',
			) ); ?>
			
			<?php
				// If comments are open or we have at least one comment, load up the comment template
				if ( comments_open() || '0' != get_comments_number() ) :
					comments_template();
				endif;
			?>

		<?php endwhile; // end of the loop. ?>

	</div><!-- #primary -->

<?php get_footer(); ?>
