<?php
/**
 * The overlay widget area
 *
 * @package Zeitreise
 * @since Zeitreise 1.0
 * @version 1.0
 */
?>

<?php
	/* Check, if the overlay sidebar widget area has widgets.
	 *
	 * If none of the sidebar widget areas have widgets, let's bail early.
	 */
	if (   ! is_active_sidebar( 'sidebar-overlay' )
		)
		return;
	// If we get this far, we have widgets. Let do this.
?>

<?php if ( is_active_sidebar( 'sidebar-overlay' ) ) : ?>
	<div id="overlay-widgetarea-one" class="sidebar-overlay widget-area" role="complementary">
		<?php dynamic_sidebar( 'sidebar-overlay' ); ?>
	</div><!-- end #overlay-widgetarea-one -->
<?php endif; ?>