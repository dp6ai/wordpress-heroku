
---------------------------------------------------------------------------------------------------------------------------
For detailed Pohutukawa theme documentationw (PDF & video tutorials in English and German) please visit:
http://www.elmastudio.de/wordpress-themes/pohutukawa/
---------------------------------------------------------------------------------------------------------------------------

Pohutukawa Changelog:

Version 1.0.2 - 15/03/2017
----------------------------------
- New: Support for the One Click Demo Import plugin.
- Bugfix: Updated deprecated functions in functions.php and inc/theme-options.php
- Bugfix: Updated theme to support https.

Version 1.0.1 - 09/03/2014
----------------------------------
- Bugfix: Updated jquery.fitvids.js in folder "js" to fix Chrome font bug
- Enhancement: Deleted deprecated add_custom_background (see functions.php)


Version 1.0 - 20/02/2012
----------------------------------
- Pohutukawa theme release
