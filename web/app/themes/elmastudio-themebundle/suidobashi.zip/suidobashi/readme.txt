------------------------------------------------------------------------------------------------------------------------------------
For a detailed theme documentation + video tutorials please visit:
http://www.elmastudio.de/en/themes/suidobashi/ (English) or http://www.elmastudio.de/wordpress-themes/suidobashi/ (German)

Please use the the Elmastudio theme forum: http://themeforum.elmastudio.de/ to ask all questions regarding the Suidobashi theme.
------------------------------------------------------------------------------------------------------------------------------------


Changelog:

Version 1.0.5 (13/03/2017)
------------------------------- -----------------------------------------------------------------------------------------------------
- New: Support for the One Click Demo Import plugin.


Version 1.0.4 (12/03/2015)
------------------------------- -----------------------------------------------------------------------------------------------------
-	Bugfix: CSS optimizations for retina logo, if not fixed-positioned (functions.php)


Version 1.0.3 (15/01/2015)
------------------------------- -----------------------------------------------------------------------------------------------------
-	Bugfix: Fixed the hide site title option (inc/customizer.php)


Version 1.0.2 (03/01/2015)
------------------------------- -----------------------------------------------------------------------------------------------------
-	Bugfix: CSS optimizations for site title (style.css)
-	New: RTL language support (rtl.css)
-	New: Option to set count of further projects below single projects under Appearance / Customize / Theme
	(single-jetpack-portfolio.php, inc/customizer.php)
-	Enhancement: Update of German theme translation (languages folder)
- 	New: Added support for new <title> tag handling to functions.php and deleted hard-coded title tag in header.php


Version 1.0.1 (07/12/2014)
------------------------------- -----------------------------------------------------------------------------------------------------
-	Bugfixes: CSS optimizations for further Portfolio projects (style.css)
-	Bugfixes: CSS optimizations for layout on 21' and 27' monitors (style.css)
-	Bugfixes: Optimizations in js/suidobashi.js


Version 1.0 (05/12/2014)
------------------------------------------------------------------------------------------------------------------------------------
-	Suidobashi theme release
