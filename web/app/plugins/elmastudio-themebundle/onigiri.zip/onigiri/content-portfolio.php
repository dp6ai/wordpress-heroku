<?php
/**
 * The template for displaying Projects on index view
 *
 * @package Onigiri
 * @since Onigiri 1.0
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('portfolio-entry'); ?>>
	<div class="project-wrap">
	<div class="entry-thumbnail">
		<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
	</div><!-- end .entry-thumbnail -->
	<div class="title-wrap">
		<header class="entry-header cf">
		<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' ); ?>
		</header><!-- end .entry-header -->
	</div><!-- end .title-wrap -->
	</div><!-- end .project-wrap -->
</article><!-- end .project -->