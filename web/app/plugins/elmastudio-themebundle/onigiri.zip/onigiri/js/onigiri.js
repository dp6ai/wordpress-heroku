/**
 * Onigiri JavaScript
 *
 * The main JavaScript file for Onigiri.
 */
( function($) {

	/*
	* Mobile Menu.
	*/
	$('#site-nav').hide();
	$('#mobile-menu-toggle').on( 'click', function () {
		$('#site-nav').slideToggle('600');
    });

	/*
	* Scalable Videos via FitVids.
	*/
	$('#primary').fitVids();

	/*
	* Fade content in, if page loaded.
	*/
	$( window ).load( function() {

		// Show content
		$( '#spinner' ).fadeOut( 250, function() {
			$( this ).remove();
		} );
		$( '#primary' ).delay( 500 ).animate( {
			'opacity': 1
		}, 400 );

	} );

} )(jQuery);