<?php
/**
 * The template for displaying content in the single.php template
 *
 * @package Onigiri
 * @since Onigiri 1.0
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php if ( '' != get_the_post_thumbnail() && ! post_password_required() ) : ?>
		<div class="entry-thumbnail">
			<a href="<?php the_permalink(); ?>" title="<?php echo esc_attr( sprintf( __( 'Permalink to %s', 'onigiri' ), the_title_attribute( 'echo=0' ) ) ); ?>"><?php the_post_thumbnail(); ?></a>
		</div><!-- end .entry-thumbnail -->
	<?php endif; ?>

	<header class="entry-header">
		<?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>
		<div class="entry-details">
			<?php the_category(', '); ?>
			<a class="date" href="<?php the_permalink(); ?>"><span><?php echo get_the_date(); ?></span></a>
			<?php edit_post_link( __( 'Edit', 'onigiri' ), ', ', '' ); ?>
		</div><!-- end .entry-details -->
	</header><!-- end .entry-header -->

	<div class="entry-content">
		<?php the_content(); ?>
		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">',
				'after'  => '</div>',
			) );
		?>
	</div><!-- end .entry-content -->

	<footer class="entry-meta cf">
		<?php $tags_list = get_the_tag_list();
		if ( $tags_list ): ?>
			<div class="entry-tags"><?php the_tags('', ' ', ''); ?></div>
		<?php endif; // get_the_tag_list() ?>

		<?php if ( get_the_author_meta( 'description' ) ): ?>
			<div class="authorbox cf">
				<h3 class="author-name"><span><?php _e('by ', 'onigiri') ?></span><?php printf( "<a href='" .  esc_url(get_author_posts_url( get_the_author_meta( 'ID' ) )) . "' rel='author'>" . get_the_author() . "</a>" ); ?></h3>
				<?php echo get_avatar( get_the_author_meta( 'user_email' ), apply_filters( 'onigiri_author_bio_avatar_size', 80 ) ); ?>
				<p class="author-description"><?php the_author_meta( 'description' ); ?></p>
			</div><!-- end .author-wrap -->
		<?php endif; ?>
	</footer><!-- end .entry-meta -->
</article><!-- end .post-<?php the_ID(); ?> -->