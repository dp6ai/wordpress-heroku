<?php
/**
 * The template for displaying 404 error pages.
 *
 * @package Onigiri
 * @since Onigiri 1.0
 */

get_header(); ?>

	<div id="primary" class="site-content cf" role="main">

		<section id="post-0" class="page no-results not-found cf">
			<header class="entry-header">
				<h1 class="entry-title"><a href="%s" rel="bookmark"><?php _e( '404! Oops, that page can&rsquo;t be found', 'onigiri' ); ?></a></h1>
				<div class="entry-details">
				<?php edit_post_link( __( 'Edit this Page', 'onigiri' ), '', '' ); ?>
				</div><!-- end .entry-details -->
			</header><!--end .entry-header -->
			<div class="entry-content">
				<p><?php _e( 'It looks like nothing was found at this location. Maybe try another search term?', 'onigiri' ); ?></p>
				<?php get_search_form(); ?>
			</div><!-- end .entry-content -->
		</section><!-- end #post-0 -->

</div><!-- end #primary -->

<?php get_footer(); ?>