------------------------------------------------------------------------------------------------------------------------------------
For a detailed theme documentation + video tutorials please visit:
https://www.elmastudio.de/en/themes/onigiri/ (English) or https://www.elmastudio.de/wordpress-themes/onigiri/ (German)

Please use the the Elmastudio theme forum to ask all questions regarding the Onigiri theme.
------------------------------------------------------------------------------------------------------------------------------------


Changelog:

Version 1.0.4 (15/03/2017)
------------------------------- -----------------------------------------------------------------------------------------------------
- New: Support for the One Click Demo Import plugin.
- Bugfix: Updated all links to support https.
- Enhancement: Added theme support for title-tag (header.php and functions.php)


Version 1.0.3 (15/01/2015)
------------------------------- -----------------------------------------------------------------------------------------------------
-	Bugfix: Fixed the hide site title option (inc/customizer.php)


Version 1.0.2 (30/12/2014)
------------------------------- -----------------------------------------------------------------------------------------------------
-	New: RTL language support (rtl.css)
-	New: Option to set count of further projects below single projects under Appearance / Customize / Theme
	(single-jetpack-portfolio.php, inc/customizer.php)
-	Enhancement: Update of German theme translation (languages folder)


Version 1.0.1 (07/12/2014)
------------------------------- -----------------------------------------------------------------------------------------------------
- CSS optimizations for Custom About Text color on mobile (style.css)
- CSS optimizations for Pagination (style.css)
- Optimizations in js/onigiri.js


Version 1.0 (05/12/2014)
------------------------------------------------------------------------------------------------------------------------------------
- Onigiri theme release
