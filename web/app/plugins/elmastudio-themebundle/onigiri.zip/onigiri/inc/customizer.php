<?php
/**
 * Onigiri Theme Customizer
 *
 * @package Onigiri
 * @since Onigiri 1.0
 */

/**
 * Implement Theme Customizer additions and adjustments.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 *
 * @since Onigiri 1.0
 */
function onigiri_customize_register( $wp_customize ) {

	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	$wp_customize->add_section( 'onigiri_themeoptions', array(
		'title'         => __( 'Theme', 'onigiri' ),
		'priority'      => 135,
	) );

	// Add the custom settings and controls.
	$wp_customize->add_setting( 'header_textcolor' , array(
    	'default'     => '#000',
		'transport'   => 'refresh',
	) );

	$wp_customize->add_setting( 'link_color' , array(
    	'default'     => '#3232dc',
		'transport'   => 'refresh',
		'sanitize_callback' => 'sanitize_hex_color',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'link_color', array(
		'label'        => __( 'Link Color', 'onigiri' ),
		'section'    => 'colors',
		'settings'   => 'link_color',
	) ) );

	$wp_customize->add_setting( 'aboutpage_bg_color' , array(
    	'default'     => '#fdddcb',
		'transport'   => 'refresh',
		'sanitize_callback' => 'sanitize_hex_color',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'aboutpage_bg_color', array(
		'label'        => __( 'About Page Background Color', 'onigiri' ),
		'section'    => 'colors',
		'settings'   => 'aboutpage_bg_color',
	) ) );

	$wp_customize->add_setting( 'aboutpage_text_color' , array(
    	'default'     => '#000000',
		'transport'   => 'refresh',
		'sanitize_callback' => 'sanitize_hex_color',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'aboutpage_text_color', array(
		'label'        => __( 'About Page Text Color', 'onigiri' ),
		'section'    => 'colors',
		'settings'   => 'aboutpage_text_color',
	) ) );

	// Theme Options.
	$wp_customize->add_setting( 'logo_height', array(
		'default'       => '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'logo_height', array(
		'label'         => __( 'If fixed positioned logo image: Height of logo image (value only)', 'onigiri' ),
		'section'    => 'onigiri_themeoptions',
		'type'          => 'text',
	) );

	// Theme Options.
	$wp_customize->add_setting( 'title_fixed', array(
		'default'       => '',
	) );

	$wp_customize->add_control( 'title_fixed', array(
		'label'         => __( 'Fixed position title/logo image', 'onigiri' ),
		'section'       => 'onigiri_themeoptions',
		'priority' => 1,
		'type'          => 'checkbox',
	) );

	$wp_customize->add_setting( 'hide_search', array(
		'default'	=> '',
	) );

	$wp_customize->add_control( 'hide_search', array(
		'label'		=> __( 'Hide Footer Search', 'onigiri' ),
		'section'	=> 'onigiri_themeoptions',
		'priority'	=> 2,
		'type'		=> 'checkbox',
	) );

	$wp_customize->add_setting( 'header_intro', array(
		'default' => '',
		'type' => 'theme_mod',
		'capability' => 'edit_theme_options',
		'transport' => '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'header_intro', array(
    	'type' => 'textarea',
		'section'       => 'onigiri_themeoptions',
		'label' => __( 'Front Page Header Intro Text', 'onigiri' ),
		'description' => '',
	) );

	$wp_customize->add_setting( 'contact_mail', array(
		'default'       => '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'contact_mail', array(
		'label'         => __( 'Header Email', 'onigiri' ),
		'section'       => 'onigiri_themeoptions',
		'type'          => 'text',
	) );

	$wp_customize->add_setting( 'contact_phone', array(
		'default'       => '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'contact_phone', array(
		'label'         => __( 'Header Phone Number', 'onigiri' ),
		'section'       => 'onigiri_themeoptions',
		'type'          => 'text',
	) );

	$wp_customize->add_setting( 'credit_text', array(
		'default'       => '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'credit_text', array(
		'label'         => __( 'Footer Credit Text', 'onigiri' ),
		'section'       => 'onigiri_themeoptions',
		'type'          => 'text',
	) );


}
add_action( 'customize_register', 'onigiri_customize_register' );

/**
 * Sanitize Checkboxes.
 */
function onigiri_sanitize_title_fixed( $title_fixed ) {
	 if ( $title_fixed == 1 ) {
        return 1;
    } else {
        return '';
    }
}

function onigiri_sanitize_hide_search( $hide_search ) {
	 if ( $hide_search == 1 ) {
        return 1;
    } else {
        return '';
    }
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function onigiri_customize_preview_js() {
	wp_enqueue_script( 'onigiri-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20131221', true );
}
add_action( 'customize_preview_init', 'onigiri_customize_preview_js' );