<?php
/**
 * Demo Installer content, One Click Demo Import plugin required
 * See: https://wordpress.org/plugins/one-click-demo-import/
 *
 * @package Onigiri
 * @since Onigiri 1.0.4
 */

function ocdi_import_files() {
	return array(

		array(
			'import_file_name'             => 'Demo Onigiri',
			'categories'                   => array( 'Portfolio' ),
			'local_import_file'            => trailingslashit( get_template_directory() ) . 'assets/demo/onigiri-content.xml',
			'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'assets/demo/onigiri-widgets.wie',
			'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'assets/demo/onigiri-customizer.dat',
			'import_notice'            		=> esc_html__( 'Make sure you have the Jetpack plugin for your portfolio feature installed, before importing this demo!', 'onigri' ),
		),
	);
}
add_filter( 'pt-ocdi/import_files', 'ocdi_import_files' );
