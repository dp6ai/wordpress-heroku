<?php
/**
 *
 * @package Onigiri
 * @since Onigiri 1.0
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<header class="entry-header">
		<?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>
		<div class="entry-details">
			<?php
				echo get_the_term_list( get_the_ID(), 'jetpack-portfolio-type', '<span class="portfolio-type-links">', _x(', ', 'Used between list items, there is a space after the comma.', 'onigiri' ), '</span>' );
			?>
			<?php edit_post_link( __( 'Edit', 'onigiri' ), ', ', '' ); ?>
		</div><!-- end .entry-details -->
	</header><!-- end .entry-header -->

	<div class="entry-content">
		<?php the_content( __( 'Continue reading <span class="meta-nav">&rarr;</span>', 'onigiri' ) ); ?>
		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'onigiri' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->

	<footer class="entry-meta cf">
		<?php
			echo get_the_term_list( $post->ID, 'jetpack-portfolio-tag', '<div class="entry-tags">', ' ', '</div>' );
		?>

	</footer><!-- .entry-meta -->

</article><!-- #post-## -->