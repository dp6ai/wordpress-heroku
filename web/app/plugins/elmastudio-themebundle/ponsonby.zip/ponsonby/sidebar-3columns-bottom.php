<?php
/**
 * The bottom 3 column widget areas on the Front Page Template.
 *
 * @package Ponsonby
 * @since Ponsonby 1.0
 */
?>

<?php
	/* Check if any of the widget areas have widgets.
	 *
	 * If none of the widget areas have widgets, let's bail early.
	 */
	if (   ! is_active_sidebar( '3columns-bottom-1' )
		&& ! is_active_sidebar( '3columns-bottom-2' )
		&& ! is_active_sidebar( '3columns-bottom-3' )
		)
		return;
	// If we get this far, we have widgets. Let do this.
?>

<div id="three-columns-bottom" class="three-columns-wrap sidebar-front cf">

	<?php if ( is_active_sidebar( '3columns-bottom-1' ) ) : ?>
		<div id="three-columns-bottom-left" class="three-columns widget-area" role="complementary">
			<?php dynamic_sidebar( '3columns-bottom-1' ); ?>
		</div><!-- end #three-columns-bottom-left -->
	<?php endif; ?>

	<?php if ( is_active_sidebar( '3columns-bottom-2' ) ) : ?>
		<div id="three-columns-bottom-middle" class="three-columns widget-area" role="complementary">
			<?php dynamic_sidebar( '3columns-bottom-2' ); ?>
		</div><!-- end #three-columns-bottom-middle -->
	<?php endif; ?>

	<?php if ( is_active_sidebar( '3columns-bottom-3' ) ) : ?>
		<div id="three-columns-bottom-right" class="three-columns widget-area" role="complementary">
			<?php dynamic_sidebar( '3columns-bottom-3' ); ?>
		</div><!-- end #three-columns-bottom-right -->
	<?php endif; ?>

</div><!-- end #three-columns-bottom -->