<?php
/**
 * The center 2 column widget area with a small left-aligned and a big right-aligned widget area on the Front Page Template.
 *
 * @package Ponsonby
 * @since Ponsonby 1.0
 */
?>

<?php
	/* Check if any of the widget areas have widgets.
	 *
	 * If none of the widget areas have widgets, let's bail early.
	 */
	if (   ! is_active_sidebar( '2columns-center-smallleft' )
		&& ! is_active_sidebar( '2columns-center-bigright' )
		)
		return;
	// If we get this far, we have widgets. Let do this.
?>

<div id="two-columns-center-bottom" class="two-columns-wrap sidebar-front cf">

	<?php if ( is_active_sidebar( '2columns-center-smallleft' ) ) : ?>
		<div id="two-columns-center-smallleft" class="two-columns-small widget-area" role="complementary">
			<?php dynamic_sidebar( '2columns-center-smallleft' ); ?>
		</div><!-- end #two-columns-center-smallleft -->
	<?php endif; ?>

	<?php if ( is_active_sidebar( '2columns-center-bigright' ) ) : ?>
		<div id="two-columns-center-bigright" class="two-columns-big widget-area" role="complementary">
			<?php dynamic_sidebar( '2columns-center-bigright' ); ?>
		</div><!-- end #two-columns-center-bigright -->
	<?php endif; ?>

</div><!-- end #two-columns-center-bottom -->