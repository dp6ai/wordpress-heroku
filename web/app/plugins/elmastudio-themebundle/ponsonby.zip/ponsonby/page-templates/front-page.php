<?php
/**
 * Template Name: Front Page
 *
 * Description: A page template for a Custom Front Page
 *
 * @package Ponsonby
 * @since Ponsonby 1.0
 */

get_header(); ?>

<div id="primary" class="site-content" role="main">

<?php get_sidebar( '3columns-top' ); ?>
<?php get_sidebar( '2columns-center1' ); ?>
<?php get_sidebar( '2columns-center2' ); ?>
<?php get_sidebar( '3columns-bottom' ); ?>

</div><!-- end #primary -->

<?php get_footer(); ?>