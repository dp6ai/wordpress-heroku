<?php
/**
 * The Header for our theme
 *
 * Displays all of the <head> section and everything up till <div id="main-wrap">
 *
 * @package Ponsonby
 * @since Ponsonby 1.0
 */
 ?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<div id="wrap" class="header-wrap">
	<header id="masthead" class="cf" role="banner">
		<div class="title-wrap">
			<div id="site-title">
				<?php if ( get_header_image() ) : ?>
				<div id="site-header">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php header_image(); ?>" width="<?php echo get_custom_header()->width; ?>" height="<?php echo get_custom_header()->height; ?>" alt=""></a>
				</div><!-- end #site-header -->
				<?php endif; ?>
				<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"><?php bloginfo( 'name' ); ?></a></h1>
				<p class="site-description"><?php bloginfo( 'description' ); ?></p>
			</div><!-- end #site-title -->

			<div id="mobile-menu-toggle"><span><?php _e( 'Menu', 'ponsonby' ); ?></span></div>
			<div id="main-menu-wrap" class="sticky-element cf">
				<div class="sticky-anchor"></div>
				<nav id="site-nav" class="sticky-content cf">
					<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_class' => 'nav-menu', 'container' => 'false') ); ?>
					<div class="searchbox">
						<?php get_search_form(); ?>
					</div><!-- end .searchbox -->
				</nav><!-- end #site-nav -->
				<div id="mobile-menu-close"><span><?php _e( 'Close Menu', 'ponsonby' ); ?></span></div>
			</div><!-- end #mobile-menu-wrap -->
		</div><!-- end .title-wrap -->

		<?php if ( get_theme_mod('header_intro') || has_nav_menu('header-top') ) : ?>
		<div class="header-info-wrap">
			<div class="moreinfo-btn-wrap">
				<div id="moreinfo-toggle"><span><?php _e( 'More Info', 'ponsonby' ); ?></span></div>
			</div>
			<div class="header-info">
				<?php if ( get_theme_mod('header_intro') ) : ?>
				<div class="intro-text">
					<?php echo wpautop( get_theme_mod( 'header_intro' ) ); ?>
				</div><!-- end .intro-text -->
				<?php endif; ?>
				<?php if (has_nav_menu( 'header-top' ) ) : ?>
				<nav id="header-top-nav">
					<?php wp_nav_menu( array('theme_location' => 'header-top', 'container' => 'false'));  ?>
				</nav><!-- end #header-top -->
				<?php endif; ?>
				<div id="moreinfo-close"><span><?php _e( 'Close More Info', 'ponsonby' ); ?></span></div>
			</div><!-- end .header-info -->
		<?php endif; ?>
		</div><!-- end .header-info-wrap -->
	</header><!-- end #masthead -->
	</div><!-- end .header-wrap -->

<div id="main-container">