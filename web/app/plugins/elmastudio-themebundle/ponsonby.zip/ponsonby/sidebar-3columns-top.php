<?php
/**
 * The top 3 column widget area on the Front Page Template.
 *
 * @package Ponsonby
 * @since Ponsonby 1.0
 */
?>

<?php
	/* Check if any of the widget areas have widgets.
	 *
	 * If none of the widget areas have widgets, let's bail early.
	 */
	if (   ! is_active_sidebar( '3columns-top-1' )
		&& ! is_active_sidebar( '3columns-top-2' )
		&& ! is_active_sidebar( '3columns-top-3' )
		)
		return;
	// If we get this far, we have widgets. Let do this.
?>

<div id="three-columns-top" class="three-columns-wrap sidebar-front cf">

	<?php if ( is_active_sidebar( '3columns-top-1' ) ) : ?>
		<div id="three-columns-top-left" class="three-columns widget-area" role="complementary">
			<?php dynamic_sidebar( '3columns-top-1' ); ?>
		</div><!-- end #three-columns-top-left -->
	<?php endif; ?>

	<?php if ( is_active_sidebar( '3columns-top-2' ) ) : ?>
		<div id="three-columns-top-middle" class="three-columns widget-area" role="complementary">
			<?php dynamic_sidebar( '3columns-top-2' ); ?>
		</div><!-- end #three-columns-top-middle -->
	<?php endif; ?>

	<?php if ( is_active_sidebar( '3columns-top-3' ) ) : ?>
		<div id="three-columns-top-right" class="three-columns widget-area" role="complementary">
			<?php dynamic_sidebar( '3columns-top-3' ); ?>
		</div><!-- end #three-columns-top-right -->
	<?php endif; ?>

</div><!-- end #three-columns-top -->