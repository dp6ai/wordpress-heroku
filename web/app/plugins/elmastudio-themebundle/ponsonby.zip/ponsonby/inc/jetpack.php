<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package Ponsonby
 * @since Ponsonby 1.0
 */

/**
 * Add theme support for Infinite Scroll.
 * See: http://jetpack.me/support/infinite-scroll/
 */
function ponsonby_jetpack_setup() {
	add_theme_support( 'infinite-scroll', array(
		'container' 		=> 'primary',
		'footer_widgets' 	=> array( 'footer-1', 'footer-2', 'footer-3' ),
		'footer'    		=> 'main-container',
	) );
}
add_action( 'after_setup_theme', 'ponsonby_jetpack_setup' );


/**
 * Remove default positioning of Jetpack sharing buttons.
 */
function ponsonby_remove_jetpack_sharing_display() {
    remove_filter( 'the_content', 'sharing_display', 19 );
    remove_filter( 'the_excerpt', 'sharing_display', 19 );
}
add_action( 'init', 'ponsonby_remove_jetpack_sharing_display' );