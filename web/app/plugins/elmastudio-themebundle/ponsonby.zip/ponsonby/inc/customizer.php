<?php
/**
 * Ponsonby Theme Customizer
 *
 * @package Ponsonby
 * @since Ponsonby 1.0
 */

/**
 * Implement Theme Customizer additions and adjustments.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 *
 * @since Ponsonby 1.0
 */
function ponsonby_customize_register( $wp_customize ) {

	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	$wp_customize->add_section( 'ponsonby_themeoptions', array(
		'title'         => __( 'Theme', 'ponsonby' ),
		'priority'      => 135,
	) );

	// Add the custom settings and controls.
	$wp_customize->add_setting( 'header_textcolor' , array(
    	'default'     => '#222222',
		'transport'   => 'refresh',
	) );

	// Custom Colors.
	$wp_customize->add_setting( 'link_color' , array(
    	'default'     => '#54a8d0',
		'transport'   => 'refresh',
		'sanitize_callback'	=> 'sanitize_hex_color',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'special_color', array(
		'label'        => __( 'Link Color', 'ponsonby' ),
		'section'    => 'colors',
		'settings'   => 'link_color',
	) ) );

	// Custom Theme Options.
	$wp_customize->add_setting( 'hide_tagline', array(
		'default'	=> 'true',
		'sanitize_callback' => 'ponsonby_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'hide_tagline', array(
		'label'		=> __( 'Display Tagline', 'ponsonby' ),
		'section'	=> 'title_tagline',
		'type'		=> 'checkbox',
		'priority'	=> 20,
	) );

	$wp_customize->add_setting( 'fixed_nav', array(
		'default'	=> '',
		'sanitize_callback' => 'ponsonby_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'fixed_nav', array(
		'label'		=> __( 'Fix-positioned main menu', 'ponsonby' ),
		'section'	=> 'ponsonby_themeoptions',
		'type'		=> 'checkbox',
		'priority'	=> 1,
		'description'	=> __( '(on wider screens only)', 'ponsonby' ),
	) );

	$wp_customize->add_setting( 'hide_search', array(
		'default'	=> '',
		'sanitize_callback' => 'ponsonby_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'hide_search', array(
		'label'		=> __( 'Hide search in main menu', 'ponsonby' ),
		'section'	=> 'ponsonby_themeoptions',
		'type'		=> 'checkbox',
		'priority'	=> 2,
	) );

	$wp_customize->add_setting( 'hide_singlethumb', array(
		'default'	=> '',
		'sanitize_callback' => 'ponsonby_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'hide_singlethumb', array(
		'label'		=> __( 'Hide Featured Image on single posts', 'ponsonby' ),
		'section'	=> 'ponsonby_themeoptions',
		'type'		=> 'checkbox',
		'priority'	=> 3,
	) );

	$wp_customize->add_setting( 'header_intro', array(
		'default'	=> '',
		'type'		=> 'theme_mod',
		'capability'=> 'edit_theme_options',
		'transport'	=> '',
		'sanitize_callback'	=> 'wp_kses_post',
	) );

	$wp_customize->add_control( 'header_intro', array(
    	'type' 		=> 'textarea',
		'section'	=> 'ponsonby_themeoptions',
		'label'		=> __( 'Header intro text', 'ponsonby' ),
		'description'	=> __( 'Your text will be visible in the left-aligned column of the header (HTML is allowed).', 'ponsonby' ),
	) );

	$wp_customize->add_setting( 'credit_text', array(
		'default'       => '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'credit_text', array(
		'label'         => __( 'Customize footer credit text', 'ponsonby' ),
		'section'       => 'ponsonby_themeoptions',
		'type'          => 'text',
	) );

}
add_action( 'customize_register', 'ponsonby_customize_register' );

/**
 * Sanitize Checkboxes.
 */
function ponsonby_sanitize_checkbox( $input ) {
	if ( 1 == $input ) {
		return true;
	} else {
		return false;
	}
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function ponsonby_customize_preview_js() {
	wp_enqueue_script( 'ponsonby-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20131221', true );
}
add_action( 'customize_preview_init', 'ponsonby_customize_preview_js' );