<?php
/**
 * Ponsonby Custom Widgets
 *
 *
 * @package Ponsonby
 * @since Ponsonby 1.0
 */

/*-----------------------------------------------------------------------------------*/
/* Ponsonby Widget: Recent Posts for Front Page
/*-----------------------------------------------------------------------------------*/

class ponsonby_recentposts extends WP_Widget {
	
	public function __construct() {
		parent::__construct( 'ponsonby_recentposts', __( 'Ponsonby Front - Recent Posts', 'ponsonby' ), array(
			'classname'   => 'widget_ponsonby_recentposts',
			'description' => __( 'A number of recent posts on the Ponsonby Front Page filtered by categories or tags.', 'ponsonby' ),
		) );
	}

	public function widget($args, $instance) {
		$title = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$type = isset( $instance['type'] ) ? esc_attr( $instance['type'] ) : '';
   		$postnumber = isset( $instance['postnumber'] ) ? esc_attr( $instance['postnumber'] ) : '';
   		$category = isset( $instance['category'] ) ? esc_attr( $instance['category'] ) : '';
   		$tag = isset( $instance['tag'] ) ? esc_attr( $instance['tag'] ) : '';

		echo $args['before_widget']; ?>

		<?php if ( ! empty( $title ) )
			echo $args['before_title'] . esc_html($title) . $args['after_title']; ?>

<?php
// The Query
	$ponsonby_rp_query = new WP_Query(array (
		'post_status'	   => 'publish',
		'posts_per_page' => $postnumber,
		'category_name' => $category,
		'tag' => $tag,
		'ignore_sticky_posts' => 1,
	) );
?>

<?php
// The Loop
if($ponsonby_rp_query->have_posts()) : ?>

   <?php while($ponsonby_rp_query->have_posts()) : $ponsonby_rp_query->the_post() ?>

   <?php if ( $type=='nothumb' ) : ?>

	<article id="post-<?php the_ID(); ?>" <?php post_class('no-thumb'); ?>>
   		<header class="rp-header">
   			<h2 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php ponsonby_title_limit( 60, '...'); ?></a></h2>
   		</header><!-- end .rp-header -->
		<div class="entry-summary">
			<?php the_excerpt(); ?>
		</div><!-- end .entry-summary -->
	</article><!-- end .post-<?php the_ID(); ?> -->

	<?php elseif ( $type=='smallthumb' ) : ?>

	<article id="post-<?php the_ID(); ?>" <?php post_class('small-thumb'); ?>>
   		<header class="rp-header">
   			<h2 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php ponsonby_title_limit( 60, '...'); ?></a></h2>
   		</header><!-- end .rp-header -->
	   	<?php if ( has_post_thumbnail() ) : ?>
		<div class="entry-thumbnail">
			<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('ponsonby-small'); ?></a>
		</div><!-- end .entry-thumbnail -->
		<?php endif; // has_post_thumbnail() ?>
		<div class="entry-summary">
			<?php the_excerpt(); ?>
		</div><!-- end .entry-summary -->
	</article><!-- end .post-<?php the_ID(); ?> -->

	<?php else : ?>

	<article id="post-<?php the_ID(); ?>" <?php post_class('big-thumb'); ?>>
   		<header class="rp-header">
   			<h2 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php ponsonby_title_limit( 60, '...'); ?></a></h2>
   		</header><!-- end .rp-header -->
	   	<?php if ( has_post_thumbnail() ) : ?>
		<div class="entry-thumbnail">
			<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('ponsonby-big'); ?></a>
		</div><!-- end .entry-thumbnail -->
		<?php endif; // has_post_thumbnail() ?>
		<div class="entry-summary">
			<?php the_excerpt(); ?>
		</div><!-- end .entry-summary -->
	</article><!-- end .post-<?php the_ID(); ?> -->

	<?php endif; ?>



   <?php endwhile; ?>

<?php endif ?>

		<?php
		echo $args['after_widget'];

		 // Reset the post globals as this query will have stomped on it
		wp_reset_postdata();
		}

   function update($new_instance, $old_instance) {
   		$instance['title'] = $new_instance['title'];
   		$instance['type'] = $new_instance['type'];
   		$instance['postnumber'] = $new_instance['postnumber'];
   		$instance['category'] = $new_instance['category'];
   		$instance['tag'] = $new_instance['tag'];

	   return $new_instance;
   }

   function form($instance) {
   		$title = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
   		$type = isset( $instance['type'] ) ? esc_attr( $instance['type'] ) : '';
   		$postnumber = isset( $instance['postnumber'] ) ? esc_attr( $instance['postnumber'] ) : '';
   		$category = isset( $instance['category'] ) ? esc_attr( $instance['category'] ) : '';
   		$tag = isset( $instance['tag'] ) ? esc_attr( $instance['tag'] ) : '';
   	?>

	<p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:','ponsonby'); ?></label>
		<input type="text" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo esc_attr($title); ?>" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" /></p>

	<p><label for="<?php echo $this->get_field_id('type'); ?>"><?php _e('Choose Post Layout:','ponsonby'); ?></label>
		<select name="<?php echo $this->get_field_name('type'); ?>" class="widefat" id="<?php echo $this->get_field_id('type'); ?>">
			<option value="smallthumb" <?php if($type == "smallthumb"){ echo "selected='selected'";} ?>><?php _e('small Featured Image', 'ponsonby'); ?></option>
			<option value="nothumb" <?php if($type == "nothumb"){ echo "selected='selected'";} ?>><?php _e('no Featured Image', 'ponsonby'); ?></option>
			<option value="bigthumb" <?php if($type == "bigthumb"){ echo "selected='selected'";} ?>><?php _e('big Featured Image (for 2-column big only)', 'ponsonby'); ?></option>
		</select></p>

	<p><label for="<?php echo $this->get_field_id('postnumber'); ?>"><?php _e('Number of posts:','ponsonby'); ?></label>
		<input type="text" name="<?php echo $this->get_field_name('postnumber'); ?>" value="<?php echo esc_attr($postnumber); ?>" class="widefat" id="<?php echo $this->get_field_id('postnumber'); ?>" /></p>

	<p><label for="<?php echo $this->get_field_id('category'); ?>"><?php _e('Category slug (optional), separate multiple category slugs by comma:','ponsonby'); ?></label>
	<input type="text" name="<?php echo $this->get_field_name('category'); ?>" value="<?php echo esc_attr($category); ?>" class="widefat" id="<?php echo $this->get_field_id('category'); ?>" /></p>

	<p><label for="<?php echo $this->get_field_id('tag'); ?>"><?php _e('Tags (optional), separate multiple tags by comma:','ponsonby'); ?></label>
	<input type="text" name="<?php echo $this->get_field_name('tag'); ?>" value="<?php echo esc_attr($tag); ?>" class="widefat" id="<?php echo $this->get_field_id('tag'); ?>" /></p>

	<?php
	}
}

register_widget('ponsonby_recentposts');


/*-----------------------------------------------------------------------------------*/
/* Ponsonby Widget: Quote
/*-----------------------------------------------------------------------------------*/

class ponsonby_quote extends WP_Widget {

	public function __construct() {
		parent::__construct( 'ponsonby_quote', __( 'Ponsonby - Quote', 'ponsonby' ), array(
			'classname'   => 'widget_ponsonby_quote',
			'description' => __( 'A quote or text slogan.', 'ponsonby' ),
		) );
	}

	public function widget($args, $instance) {
		extract( $args );
		$title = $instance['title'];
		$quotetext = $instance['quotetext'];
		$quoteauthor = $instance['quoteauthor'];

		echo $before_widget; ?>

		<?php if($title != '')
			echo '<div class="widget-title-wrap"><h3 class="widget-title"><span>'. esc_html($title) .'</span></h3></div>'; ?>

			<div class="quote-wrap">
				<blockquote class="quote-text"><?php echo ( wp_kses_post(wpautop($quotetext))  ); ?>
				<?php if($quoteauthor != '') {
					echo '<cite class="quote-author"> ' . ( wp_kses_post($quoteauthor) ) . ' </cite>';
				}
				?>
				</blockquote>
			</div><!-- end .quote-wrap -->

	   <?php
	   echo $after_widget;

	   // Reset the post globals as this query will have stomped on it
	   wp_reset_postdata();
	   }

   function update($new_instance, $old_instance) {

   		$instance['title'] = $new_instance['title'];
   		$instance['quotetext'] = $new_instance['quotetext'];
   		$instance['quoteauthor'] = $new_instance['quoteauthor'];

       return $new_instance;
   }

   function form($instance) {
   		$title = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
   		$quotetext = isset( $instance['quotetext'] ) ? esc_attr( $instance['quotetext'] ) : '';
   		$quoteauthor = isset( $instance['quoteauthor'] ) ? esc_attr( $instance['quoteauthor'] ) : '';
	?>

	<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:','ponsonby'); ?></label>
		<input type="text" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo esc_attr($title); ?>" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" />
	</p>

	<p>
		<label for="<?php echo $this->get_field_id('quotetext'); ?>"><?php _e('Quote Text:','ponsonby'); ?></label>
		<textarea name="<?php echo $this->get_field_name('quotetext'); ?>" class="widefat" rows="8" cols="12" id="<?php echo $this->get_field_id('quotetext'); ?>"><?php echo( $quotetext ); ?></textarea>
	</p>

	<p>
	<label for="<?php echo $this->get_field_id('quoteauthor'); ?>"><?php _e('Quote Author (optional):','ponsonby'); ?></label>
	<input type="text" name="<?php echo $this->get_field_name('quoteauthor'); ?>" value="<?php echo esc_attr($quoteauthor); ?>" class="widefat" id="<?php echo $this->get_field_id('quoteauthor'); ?>" />
	</p>

	<?php
	}
}

register_widget('ponsonby_quote');