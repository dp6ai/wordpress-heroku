/**
 * Ponsonby JavaScript
 *
 * The main JavaScript file for Ponsonby.
 */
( function($) {

	// Scroll Top + Fix-position Main Menu.
	var StickyElement = function(node){
	var doc = $(document),
      fixed = false,
      anchor = node.find('.sticky-anchor'),
      content = node.find('.sticky-content');

	var onScroll = function(e){
    var docTop = doc.scrollTop(),
        anchorTop = anchor.offset().top;

    if(docTop > anchorTop){
      if(!fixed){
        anchor.height(content.outerHeight());
        content.addClass('fixed');
        fixed = true;
      }
    }  else   {
      if(fixed){
        anchor.height(0);
        content.removeClass('fixed');
        fixed = false;
      }
    }
  };
  $(window).on('scroll', onScroll);
};

var demo = new StickyElement($('#main-menu-wrap'));

// Mobile Menu.
    $('#main-menu-wrap').hide();
	$('#mobile-menu-toggle').on( 'click', function () {
		$('#main-menu-wrap').slideToggle('600');
    });

	$('#mobile-menu-close').on( 'click', function () {
		$('#main-menu-wrap').slideToggle('600');
    });

    // More Info Header Menu.
    $('.header-info').hide();
	$('#moreinfo-toggle').on( 'click', function () {
		$('.header-info').slideToggle('600');
		$('#moreinfo-toggle').toggleClass('menu-open');
    });

    $('#moreinfo-close').on( 'click', function () {
		$('.header-info').slideToggle('600');
		jQuery('#moreinfo-toggle').removeClass('menu-open');
    });

	// Responsive Videos.
	$('#primary').fitVids();

} )(jQuery);