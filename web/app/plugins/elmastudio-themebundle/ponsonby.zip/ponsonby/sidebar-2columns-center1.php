<?php
/**
 * The center 2 column widget area with a big left-aligned and a small right-aligned widget area on the Front Page Template.
 *
 * @package Ponsonby
 * @since Ponsonby 1.0
 */
?>

<?php
	/* Check if any of the widget areas have widgets.
	 *
	 * If none of the widget areas have widgets, let's bail early.
	 */
	if (   ! is_active_sidebar( '2columns-center-bigleft' )
		&& ! is_active_sidebar( '2columns-center-smallright' )
		)
		return;
	// If we get this far, we have widgets. Let do this.
?>

<div id="two-columns-center-top" class="two-columns-wrap sidebar-front cf">

	<?php if ( is_active_sidebar( '2columns-center-bigleft' ) ) : ?>
		<div id="two-columns-center-bigleft" class="two-columns-big widget-area" role="complementary">
			<?php dynamic_sidebar( '2columns-center-bigleft' ); ?>
		</div><!-- end #two-columns-center-bigleft -->
	<?php endif; ?>

	<?php if ( is_active_sidebar( '2columns-center-smallright' ) ) : ?>
		<div id="two-columns-center-smallright" class="two-columns-small widget-area" role="complementary">
			<?php dynamic_sidebar( '2columns-center-smallright' ); ?>
		</div><!-- end #two-columns-center-smallright -->
	<?php endif; ?>

</div><!-- end #two-columns-center-top -->