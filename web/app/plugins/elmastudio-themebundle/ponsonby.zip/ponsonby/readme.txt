
----------------------------------------------------------------------------------------------------------------------------

For a detailed theme documentation + video tutorials please visit:
https://www.elmastudio.de/en/themes/ponsonby/ (English) or https://www.elmastudio.de/wordpress-themes/ponsonby/ (German)

Please use the the Elmastudio theme forum to ask all questions regarding the Ponsonby theme.

----------------------------------------------------------------------------------------------------------------------------


Changelog:

Version 1.1.2 (15/03/2017)
----------------------------------------------------------------------------------------------------------------------------
- New: Support for the One Click Demo Import plugin.


Version 1.1.1 (19/08/2015)
----------------------------------------------------------------------------------------------------------------------------
- Bug Fix: Update of inc/widget.php file to make theme WordPress 4.3 compatible (see inc/widgets.php)
- Security Improvement: Genericons icon font update to version 3.3.1


Version 1.1 (16/01/2015)
----------------------------------------------------------------------------------------------------------------------------
- Bug Fix: Fixed option to hide site title and change site title color (inc/custom-header.php)
- Bug Fix: Optimizations in js/ponsonby.js
- Enhancement: Added new title tag (header.php, functions.php)
- New: Added option to show header tagline. See Appearance / Customizer / Site Title & Tagline
	(header.php, style.css, inc/customizer.php, functions.php).
 - New: Added CSS styles for larger screens (style.css)
 - New: RTL language support (rtl.css)


Version 1.0 (24/12/2014)
----------------------------------------------------------------------------------------------------------------------------
- Ponsonby theme release
