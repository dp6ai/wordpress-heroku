<?php
/**
 * Ponsonby functions and definitions
 *
 * @package Ponsonby
 * @since Ponsonby 1.0
 */

/*-----------------------------------------------------------------------------------*/
/* Sets up the content width value based on the theme's design.
/*-----------------------------------------------------------------------------------*/

if ( ! isset( $content_width ) )
		$content_width = 975;

function ponsonby_adjust_content_width() {
		global $content_width;

		if ( is_page_template( 'full-width.php' ) )
				$content_width = 1530;
}
add_action( 'template_redirect', 'ponsonby_adjust_content_width' );

/*-----------------------------------------------------------------------------------*/
/* Sets up theme defaults and registers support for various WordPress features.
/*-----------------------------------------------------------------------------------*/

function ponsonby_setup() {

	// Make Ponsonby available for translation. Translations can be added to the /languages/ directory.
	load_theme_textdomain( 'ponsonby', get_template_directory() . '/languages' );

	// This theme styles the visual editor to resemble the theme style.
	add_editor_style( array( 'editor-style.css' ) );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	// Let WordPress manage the document title.
	add_theme_support( 'title-tag' );

	// This theme uses wp_nav_menu().
	register_nav_menus( array (
		'primary' => __( 'Primary menu', 'ponsonby' ),
		'header-top' => __( 'Header Top menu', 'ponsonby' ),
	) );

	// Implement the Custom Header feature
	require get_template_directory() . '/inc/custom-header.php';

	// This theme allows users to set a custom background.
	add_theme_support( 'custom-background', apply_filters( 'ponsonby_custom_background_args', array(
		'default-color'	=> 'fff',
		'default-image'	=> '',
	) ) );

	// This theme uses post thumbnails.
	add_theme_support( 'post-thumbnails' );

	//  Adding several sizes for Post Thumbnails
	add_image_size( 'ponsonby-small', 560 ); // Small Recent Post thumbnails
	add_image_size( 'ponsonby-big', 975 ); // Default blog thumbnails
	add_image_size( 'ponsonby-blog', 975 ); // Default blog thumbnails
	add_image_size( 'ponsonby-single', 1530 ); // Single Post thumbnails

}
add_action( 'after_setup_theme', 'ponsonby_setup' );


/*-----------------------------------------------------------------------------------*/
/*  Returns the Google font stylesheet URL if available.
/*-----------------------------------------------------------------------------------*/

function ponsonby_font_url() {
	$fonts_url = '';

	/* Translators: If there are characters in your language that are not
	 * supported by the used fonts translate this to 'off'. Do not translate
	 * into your own language.
	 */
	$open_sans = _x( 'on', 'Open Sans: on or off', 'ponsonby' );

	$pt_serif = _x( 'on', 'PT Serif: on or off', 'ponsonby' );

	if ( 'off' !== $open_sans || 'off' !== $montserrat || 'off' !== $pt_serif ) {
		$font_families = array();

		if ( 'off' !== $open_sans )
			$font_families[] = 'Open Sans:400italic,700italic,400,700';

		if ( 'off' !== $pt_serif )
			$font_families[] = 'PT Serif:400,700,400italic,700italic';

		$query_args = array(
			'family' => urlencode( implode( '|', $font_families ) ),
			'subset' => urlencode( 'latin,latin-ext' ),
		);
		$fonts_url = add_query_arg( $query_args, "//fonts.googleapis.com/css" );
	}

	return $fonts_url;
}


/*-----------------------------------------------------------------------------------*/
/*  Enqueue scripts and styles
/*-----------------------------------------------------------------------------------*/

function ponsonby_scripts() {
	global $wp_styles;

	// Loads JavaScript to pages with the comment form to support sites with threaded comments (when in use)
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) )
	wp_enqueue_script( 'comment-reply' );

	// Add Google fonts, used in the main stylesheet.
	wp_enqueue_style( 'ponsonby-fonts', ponsonby_font_url(), array(), null );

	// Loads main stylesheet.
	wp_enqueue_style( 'ponsonby-style', get_stylesheet_uri(), array(), '20140630' );

	// Add Genericons font, used in the main stylesheet.
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/assets/genericons/genericons.css', array(), '3.0.3' );

	// FitVids for responsive videos
	wp_enqueue_script( 'ponsonby-fitvids', get_template_directory_uri() . '/js/jquery.fitvids.js', array( 'jquery' ), '1.1' );

	// Loads Custom Ponsonby JavaScript functionality
	wp_enqueue_script( 'ponsonby-script', get_template_directory_uri() . '/js/ponsonby.js', array( 'jquery' ), '20141201',true );


}
add_action( 'wp_enqueue_scripts', 'ponsonby_scripts' );


/*-----------------------------------------------------------------------------------*/
/* Get our wp_nav_menu() fallback, wp_page_menu(), to show a home link.
/*-----------------------------------------------------------------------------------*/

function ponsonby_page_menu_args( $args ) {
	$args['show_home'] = true;
	return $args;
}
add_filter( 'wp_page_menu_args', 'ponsonby_page_menu_args' );


/*-----------------------------------------------------------------------------------*/
/* Sets the authordata global when viewing an author archive.
/*-----------------------------------------------------------------------------------*/

function ponsonby_setup_author() {
	global $wp_query;

	if ( $wp_query->is_author() && isset( $wp_query->post ) ) {
		$GLOBALS['authordata'] = get_userdata( $wp_query->post->post_author );
	}
}
add_action( 'wp', 'ponsonby_setup_author' );


/*-----------------------------------------------------------------------------------*/
/* Short Title.
/*-----------------------------------------------------------------------------------*/
function ponsonby_title_limit($length, $replacer = '...') {
 $string = the_title('','',FALSE);
 if(strlen($string) > $length)
 $string = (preg_match('/^(.*)\W.*$/', substr($string, 0, $length+1), $matches) ? $matches[1] : substr($string, 0, $length)) . $replacer;
 echo $string;
}


/*-----------------------------------------------------------------------------------*/
/* Add custom max excerpt lengths.
/*-----------------------------------------------------------------------------------*/

function ponsonby_excerpt_length( $length ) {
	return 28;
}
add_filter( 'excerpt_length', 'ponsonby_excerpt_length', 999 );


/*-----------------------------------------------------------------------------------*/
/* Replace "[...]" with an ellipsis in excerpts.
/*-----------------------------------------------------------------------------------*/

function ponsonby_auto_excerpt_more( $more ) {
	return ' &hellip;';
}
add_filter( 'excerpt_more', 'ponsonby_auto_excerpt_more' );


/*-----------------------------------------------------------------------------------*/
/* Add Theme Customizer CSS
/*-----------------------------------------------------------------------------------*/

function ponsonby_customize_css() {
		?>
	<style type="text/css" id="ponsonby-themeoptions-css">
	.entry-content a,
	.author-description a,
	.comment-text a,
	a.more-link,
	#colophon a,
	.entry-cats a,
	.intro-text a,
	.textwidget a,
	a.more-link,
	.widget_ponsonby_recentposts h3.widget-title,
	.two-columns-big .widget_ponsonby_quote h3.widget-title {
		color: <?php echo get_theme_mod('link_color'); ?>;
	}
	#mobile-menu-toggle,
	#mobile-menu-close,
	#moreinfo-close,
	input[type="button"],
	input[type="submit"] {
		background: <?php echo get_theme_mod('link_color'); ?>;
	}
	input[type="button"],
	input[type="submit"] {
		border: 1px solid <?php echo get_theme_mod('link_color'); ?>;
	}
	<?php if ( '' != get_theme_mod( 'hide_search' ) ) { ?>
		.searchbox {display: none;}
	<?php } ?>
	<?php if ( '' != get_theme_mod( 'fixed_nav' ) ) { ?>
		@media screen and (min-width: 1240px) {
			.sticky-content {display: none;}
			.sticky-content.fixed {position: fixed; display: block;}
		}
	<?php } ?>
	<?php if ( '' != get_theme_mod( 'hide_tagline' ) ) { ?>
			p.site-description {display: block;}
	<?php } ?>
	</style>
		<?php
}
add_action( 'wp_head', 'ponsonby_customize_css');


/*-----------------------------------------------------------------------------------*/
/* Remove inline styles printed when the gallery shortcode is used.
/*-----------------------------------------------------------------------------------*/

add_filter('use_default_gallery_style', '__return_false');


if ( ! function_exists( 'ponsonby_comment' ) ) :
/*-----------------------------------------------------------------------------------*/
/* Comments template ponsonby_comment
/*-----------------------------------------------------------------------------------*/
function ponsonby_comment( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	switch ( $comment->comment_type ) :
		case '' :
	?>

	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
		<article id="comment-<?php comment_ID(); ?>" class="comment">

			<div class="comment-avatar">
				<?php echo get_avatar( $comment, 80 ); ?>
			</div>

			<div class="comment-content">
				<div class="comment-details cf">
					<span class="comment-author">
						<?php printf( __( '%s <span class="says">says</span>', 'ponsonby' ), wp_kses_post( sprintf( '%s', get_comment_author_link() ) ) ); ?>
					</span><!-- end .comment-author -->
					<span class="comment-time"><a href="<?php echo esc_url( get_comment_link( $comment->comment_ID ) ); ?>">
						<?php
						/* translators: 1: date */
							printf( __( 'on %1$s', 'ponsonby' ),
							get_comment_date());
						?></a>
					</span><!-- end .comment-time -->
					<span class="comment-edit">
						<?php edit_comment_link( __( 'Edit', 'ponsonby' ));?>
					</span><!-- end .comment-edit -->
				</div><!-- end .comment-details -->

				<div class="comment-text">
				<?php comment_text(); ?>
					<?php if ( $comment->comment_approved == '0' ) : ?>
						<p class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.', 'ponsonby' ); ?></p>
					<?php endif; ?>
				</div><!-- end .comment-text -->
			</div><!-- end .comment-content -->
			<?php if ( comments_open () ) : ?>
				<div class="comment-reply"><?php comment_reply_link( array_merge( $args, array( 'reply_text' => __( 'Reply to this comment', 'ponsonby' ), 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?></div>
			<?php endif; ?>

		</article><!-- end .comment -->

	<?php
			break;
		case 'pingback'  :
		case 'trackback' :
	?>
	<li class="pingback">
		<p><?php _e( '<span>Pingback:</span>', 'ponsonby' ); ?> <?php comment_author_link(); ?></p>
		<p class="pingback-edit"><?php edit_comment_link(); ?></p>
	<?php
			break;
	endswitch;
}
endif;


/*-----------------------------------------------------------------------------------*/
/* Register widgetized areas
/*-----------------------------------------------------------------------------------*/

function ponsonby_widgets_init() {

	register_sidebar( array (
		'name' => __( 'Blog Sidebar', 'ponsonby' ),
		'id' => 'blog-sidebar',
		'description' => __( 'Widgets appear in the blog sidebar and on single posts.', 'ponsonby' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array (
		'name' => __( 'Front: Top 3-columns (left)', 'ponsonby' ),
		'id' => '3columns-top-1',
		'description' => __( 'Widgets appear in the left column of the top three-column widget area on the Front Page.', 'ponsonby' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array (
		'name' => __( 'Front: Top 3-columns (middle)', 'ponsonby' ),
		'id' => '3columns-top-2',
		'description' => __( 'Widgets appear in the middle column of the top three-column widget area on the Front Page.', 'ponsonby' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array (
		'name' => __( 'Front: Top 3-columns (right)', 'ponsonby' ),
		'id' => '3columns-top-3',
		'description' => __( 'Widgets appear in the right column of the top three-column widget area on the Front Page.', 'ponsonby' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array (
		'name' => __( 'Front: Center 2-columns A (big left)', 'ponsonby' ),
		'id' => '2columns-center-bigleft',
		'description' => __( 'Widgets appear in the big left column of the Center two-column A widget area on the Front Page.', 'ponsonby' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array (
		'name' => __( 'Front: Center 2-columns A (small right)', 'ponsonby' ),
		'id' => '2columns-center-smallright',
		'description' => __( 'Widgets appear in the small right column of the center two-column A widget area on the Front Page.', 'ponsonby' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array (
		'name' => __( 'Front: Center 2-columns B (big right)', 'ponsonby' ),
		'id' => '2columns-center-bigright',
		'description' => __( 'Widgets appear in the big right column of the center two-column B widget area on the Front Page.', 'ponsonby' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array (
		'name' => __( 'Front: Center 2-columns B (small left)', 'ponsonby' ),
		'id' => '2columns-center-smallleft',
		'description' => __( 'Widgets appear in the small left column of the center two-column B widget area on the Front Page.', 'ponsonby' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array (
		'name' => __( 'Front: Bottom 3-columns (left)', 'ponsonby' ),
		'id' => '3columns-bottom-1',
		'description' => __( 'Widgets appear in the left column of the bottom three-column widget area on the Front Page.', 'ponsonby' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array (
		'name' => __( 'Front: Bottom 3-columns (middle)', 'ponsonby' ),
		'id' => '3columns-bottom-2',
		'description' => __( 'Widgets appear in the middle column of the bottom three-column widget area on the Front Page.', 'ponsonby' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array (
		'name' => __( 'Front: Bottom 3-columns (right)', 'ponsonby' ),
		'id' => '3columns-bottom-3',
		'description' => __( 'Widgets appear in the right column of the bottom three-column widget area on the Front Page.', 'ponsonby' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array (
		'name' => __( 'Footer: 3-columns (left)', 'ponsonby' ),
		'id' => 'footer-1',
		'description' => __( 'First widget area of the three-column Footer widget area.', 'ponsonby' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array (
		'name' => __( 'Footer: 3-columns (middle)', 'ponsonby' ),
		'id' => 'footer-2',
		'description' => __( 'Second widget area of the three-column Footer widget area.', 'ponsonby' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array (
		'name' => __( 'Footer: 3-columns (right)', 'ponsonby' ),
		'id' => 'footer-3',
		'description' => __( 'Third widget area of the three-column Footer widget area.', 'ponsonby' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );


}
add_action( 'widgets_init', 'ponsonby_widgets_init' );


if ( ! function_exists( 'ponsonby_content_nav' ) ) :


/*-----------------------------------------------------------------------------------*/
/* Display navigation to next/previous pages when applicable.
/*-----------------------------------------------------------------------------------*/

function ponsonby_content_nav( $nav_id ) {
	global $wp_query;

	if ( $wp_query->max_num_pages > 1 ) : ?>
		<div class="nav-wrap cf">
			<nav id="<?php echo $nav_id; ?>">
				<div class="nav-previous"><?php next_posts_link( __( '<span>Previous Posts</span>', 'ponsonby'  ) ); ?></div>
				<div class="nav-next"><?php previous_posts_link( __( '<span>Next Posts</span>', 'ponsonby' ) ); ?></div>
			</nav>
		</div><!-- end .nav-wrap -->
	<?php endif;
}

endif; // ponsonby_content_nav


/*-----------------------------------------------------------------------------------*/
/* Display navigation to next/previous post when applicable.
/*-----------------------------------------------------------------------------------*/

function ponsonby_post_nav() {
	global $post;

	// Don't print empty markup if there's nowhere to navigate.
	$previous = ( is_attachment() ) ? get_post( $post->post_parent ) : get_adjacent_post( false, '', true );
	$next     = get_adjacent_post( false, '', false );

	if ( ! $next && ! $previous )
		return;
	?>
	<div class="nav-wrap cf">
		<nav id="nav-single">
			<div class="nav-previous"><?php previous_post_link( '%link', __( '<span class="meta-nav">Previous</span>', 'ponsonby' ) ); ?></div>
			<div class="nav-next"><?php next_post_link('%link', __( '<span class="meta-nav">Next</span>', 'ponsonby' ) ); ?></div>
		</nav><!-- #nav-single -->
	</div><!-- end .nav-wrap -->
	<?php
}


/*-----------------------------------------------------------------------------------*/
/* Extends the default WordPress body classes
/*-----------------------------------------------------------------------------------*/
function ponsonby_body_class( $classes ) {

	if ( is_page_template( 'page-templates/front-page.php' ) )
		$classes[] = 'template-front';

	if ( is_page_template( 'page-templates/full-width.php' ) )
		$classes[] = 'template-fullwidth';

	return $classes;
}
add_filter( 'body_class', 'ponsonby_body_class' );


/*-----------------------------------------------------------------------------------*/
/* Customizer additions
/*-----------------------------------------------------------------------------------*/
require get_template_directory() . '/inc/customizer.php';

/*-----------------------------------------------------------------------------------*/
/* Load Jetpack compatibility file.
/*-----------------------------------------------------------------------------------*/
require get_template_directory() . '/inc/jetpack.php';

/*-----------------------------------------------------------------------------------*/
/* Grab the Ponsonby Custom widgets.
/*-----------------------------------------------------------------------------------*/
require( get_template_directory() . '/inc/widgets.php' );

/*-----------------------------------------------------------------------------------*/
/* Grab the Ponsonby Custom shortcodes.
/*-----------------------------------------------------------------------------------*/
require( get_template_directory() . '/inc/shortcodes.php' );

/*-----------------------------------------------------------------------------------*/
/* Add One Click Demo Import code.
/*-----------------------------------------------------------------------------------*/
require get_template_directory() . '/inc/demo-installer.php';
