
-----------------------------------------------------------------------------------------------------------------------

For a detailed theme documentation + video tutorials please visit:
https://www.elmastudio.de/en/themes/cocoa/ (English) or https://www.elmastudio.de/wordpress-themes/cocoa/ (German)

All questions regarding the Cocoa theme can be asked in the Elmastudio theme forum.

-----------------------------------------------------------------------------------------------------------------------


Changelog:

Version 1.0.5 (05/05/2017)
----------------------------------------------------------------------------------------------------------------------------
- Bug Fix: Fixed error in new assets folder and bug with included Genericons icons.


Version 1.0.4 (13/03/2017)
----------------------------------------------------------------------------------------------------------------------------
- New: Support for the One Click Demo Import plugin.


Version 1.0.3 (19/08/2015)
----------------------------------------------------------------------------------------------------------------------------
- Bug Fix: Update of inc/widget.php file to make theme WordPress 4.3 compatible (see inc/widgets.php)
- Security Improvement: Genericons icon font update to version 3.3.1


Version 1.0.2 (21/05/2014)
-----------------------------------------------------------------------------------------------------------------------
- Bugfix: Deleted double scrollbar in overlay header widget area in windows browsers (style.css + ie-only.css)
- Bugfix: Seleted  search widget searchform left-float (searchform.php, style.css)
- New: Menu Button Color Option under Appearance / Customizer / Colors (inc/customizer.php, functions.php)
- New: Filter by Categories option on Archive Page Template (content-archive.php, style.css)
- Enhancement: small CSS improvements (style.css)
- Enhancement: Improvements for German theme translation (languages)


Version 1.0.1 (15/05/2014)
-----------------------------------------------------------------------------------------------------------------------
- Bugfix: Optimized CSS for IE (header.php + ie-only.css)
- Bugfix: Deleted inc/jetpack.php + included functions in functions.php
- Bugfix: Optimized CSS for link post format (style.css)
- Bugfix: Support for Jetpack infinite scroll + Fitvids responsive videos (js/functions.js)
- Bugfix: Added translation for "Read More" (content.php, languages folder)
- Bugfix: Added extra searchform-footer.php for search in footer (searchform-footer.php)
- Enhancement: About widget improvements (inc/widgets.php, style.css)


Version 1.0 (13/05/2014)
-----------------------------------------------------------------------------------------------------------------------
- Cocoa theme release
