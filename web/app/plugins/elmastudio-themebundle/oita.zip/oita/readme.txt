
-------------------------------------------------------------------------------------------------------------------------------------------------

For a detailed theme documentation + video tutorials please visit:
http://www.elmastudio.de/en/themes/oita/ (English) or http://www.elmastudio.de/wordpress-themes/oita/ (German)

Questions about Oita can be asked in the theme forum: http://themeforum.elmastudio.de/

-------------------------------------------------------------------------------------------------------------------------------------------------

Oita Changelog:

Version 1.0.4 - 17/03/2017
-------------------------------------------------
- New: Support for the One Click Demo Import plugin.
- Bugfix: Updated all links to https.


Version 1.0.3 - 11/05/2016
-------------------------------------------------
- Bugfix: Make theme WordPress 4.5 compatible (functions.php)
- Enhancement: Include Google fonts using https (functions.php)
- Enhancement: Support for WordPress title-tag (functions.php, header.php)
- Enhancement: Update of theme options page (inc/theme-options.php)
- New: Italian theme translation (languages folder)


Version 1.0.2 - 09/03/2014
-------------------------------------------------
- Bugfix: Updated jquery.fitvids.js in folder "js" to fix Chrome font bug


Version 1.0.1 (June 3rd 2013)
-------------------------------------------------------------------------------------------------------------------------------------------------

- Bugfix: Fixed some errors in the German theme translation (folder: languages)
- Bugfix: For the Oita Video Widget (style.css, 688)
- Bugfix: Changed lightgrey font color to a slightly darker grey color due to readability (#bbb to #aaa, style.css)
- Bugfix: Columns background color fix in off canvas layout (style.css)
- Bugfix: CSS styles for Jetpack Subscribe widget (style.css)
- Bugfix: Scroll to top of the page, if sidebar or menu is opened / closed (js/custom.js)
- New: Footer Nav and site credit text now always visible in footer (style.css, footer.php, new template file: colophon.php)
- New: Support for Disqus comment plugin (style.css)


Version 1.0 (March 11th 2013)
-------------------------------------------------------------------------------------------------------------------------------------------------

- Oita Theme release
