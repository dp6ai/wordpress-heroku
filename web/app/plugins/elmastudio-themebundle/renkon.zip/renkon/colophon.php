<?php
/**
 * The template for displaying an optional footer nav and the site info.
 *
 * @package Renkon
 * @since Renkon 1.0
 */
?>

<div class="colophon" role="contentinfo">
	<div class="site-info">
	<?php
		$options = get_option('renkon_theme_options');
		if($options['custom_footertext'] != '' ){
			echo ('<ul class="credit"><li>');
			echo stripslashes($options['custom_footertext']);
			echo ('</li></ul>');
		} else { ?>
			<ul class="credit">
				<li>&copy; <?php echo date('Y'); ?> <a href="<?php echo home_url(); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a></li>
				<li><?php _e('Powered by', 'renkon') ?> <a href="<?php echo esc_url( __( 'https://wordpress.org/', 'renkon' ) ); ?>" title="<?php esc_attr_e( 'Semantic Personal Publishing Platform', 'renkon' ); ?>"><?php _e('WordPress', 'renkon') ?></a></li>
				<li><?php printf( __( 'Theme: %1$s by %2$s', 'renkon' ), 'Renkon', '<a href="https://www.elmastudio.de/en/" title="Elmastudio">Elmastudio</a>' ); ?></li>
			</ul>
	<?php } ?>

	</div><!-- end .site-info -->

	<?php if (has_nav_menu( 'optional' ) ) {
		wp_nav_menu( array('theme_location' => 'optional', 'container' => 'nav' , 'container_class' => 'footer-nav', 'depth' => 1 ));}
	?>

</div><!-- end .colophon -->
