
-----------------------------------------------------------------------------------------------------------------------

For a detailed theme documentation + video tutorials please visit:
http://www.elmastudio.de/en/themes/kioremoana/ (English) or http://www.elmastudio.de/wordpress-themes/kioremoana/ (German)

Questions about Kiore Moana can be asked in the Elmastudio theme forum: http://themeforum.elmastudio.de/

-----------------------------------------------------------------------------------------------------------------------

Version 1.0.4 (05/05/2017)
----------------------------------------------------------------------------------------------------------------------------
-Bug Fix: Updates to support https.

Version 1.0.3 (19/08/2015)
----------------------------------------------------------------------------------------------------------------------------
-Bug Fix: Update of inc/widget.php file to make theme WordPress 4.3 compatible (see inc/widgets.php)

Version 1.0.2 (09/03/2014)
-----------------------------------------------------------
- Bugfix: Updated jquery.fitvids.js in folder "js" to fix Chrome font bug

Version 1.0.1 (02/10/2013)
-----------------------------------------------------------
- Bug Fix: Widget title in white text color on info page (see style.css)
- Bug Fix: Support for custom Info page button + info button hover color (see inc/theme-options.php)
- Bug Fix: Support for custom logo image with flexible image size (see style.css)
- Bug Fix: Post Format Icons support in Firefox browser (see style.css)
- Enhancement: Jetpack Tiled Galleries content width with max. 1160px instead of 960px (see functions.php)


Version 1.0 (September 30th 2013)
-----------------------------------------------------------
- Kiore Moana Theme release
