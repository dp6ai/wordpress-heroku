
-----------------------------------------------------------------------------------------------------------------------

For a detailed theme documentation + video tutorials please visit:
http://www.elmastudio.de/en/themes/ubud/ (English) or http://www.elmastudio.de/wordpress-themes/ubud/ (German)

Questions about Ubud can be asked in the Elmastudio theme forum: http://themeforum.elmastudio.de/

-----------------------------------------------------------------------------------------------------------------------


Changelog:

Version 1.0.4 (13/03/2017)
-----------------------------------------------------------------------------------------------------------------------
- New: Support for the One Click Demo Import plugin.


Version 1.0.3 (07/09/2015)
-----------------------------------------------------------------------------------------------------------------------
- Bugfix: Update of widget.php to make the theme WordPress 4.3 compatible (inc/widget.php)
- Bugfix: CSS for Jetpack blog subscription widget (style.css)


Version 1.0.2 (10/04/2014)
-----------------------------------------------------------------------------------------------------------------------
- Bugfix: CSS for one-column layout list view (style.css)
- Enhancement: Black and White Image Hover option (style.css, inc/customizer.php)


Version 1.0.1 (10/03/2014)
-----------------------------------------------------------------------------------------------------------------------
- Bugfix: German translations (languages folder, content-single.php, comments.php)
- Bugfix: wide-content CSS class (style.css)
- Enhancement: Grid Switcher button not visible on single posts and pages (style.css)


Version 1.0 (08/03/2014)
-----------------------------------------------------------------------------------------------------------------------
- Ubud theme release
