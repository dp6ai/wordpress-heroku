<?php
/**
 * Jetpack Compatibility File
 *
 * @package Ubud
 * @since Ubud 1.0
 */


/**
 *Add theme support for Infinite Scroll.
 */
function ubud_infinite_scroll_setup() {
	add_theme_support( 'infinite-scroll', array(
		'container' 		=> 'primary',
		'footer_widgets' 	=> array( 'footer-sidebar-1', 'footer-sidebar-2', 'footer-sidebar-3', 'footer-sidebar-4', 'footer-sidebar-social' ),
		'footer'    		=> 'main-wrap',
	) );
}
add_action( 'after_setup_theme', 'ubud_infinite_scroll_setup' );
