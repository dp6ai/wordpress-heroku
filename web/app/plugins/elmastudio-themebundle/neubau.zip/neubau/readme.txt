
-----------------------------------------------------------------------------------------------------------------------------------

Theme documentationw:
https://www.elmastudio.de/en/themes/neubau/ (English)
https://www.elmastudio.de/wordpress-themes/neubau/ (German)

Please use the the Elmastudio theme forum to ask all questions regarding the Neubau theme.

-----------------------------------------------------------------------------------------------------------------------------------


Changelog:

Version 1.0.4 (13. September 2017):
-----------------------------------------------------------------------------------------------------------------------------------
- Bugfix: Update of jQuery viewport checker script due to bug in newest Google Chrome version.
(see: js/jquery.viewportchecker.min.js and functions.js)

Version 1.0.3 (05/05/2017)
-----------------------------------------------------------------------------------------------------------------------------------
- Bugfix: Fixed Genericons icons issue (from the 1.0.2 update).

Version 1.0.2 (08/03/2017)
-----------------------------------------------------------------------------------------------------------------------------------
- New: Support for the One Click Demo Import plugin.
- Enhancement: Updated footer.php to support https.

Version 1.0.1 (23/04/2016)
-----------------------------------------------------------------------------------------------------------------------------------
- Bugfix: Update of code in js/functions.js for new jQuery version (js/functions.js)
- Bugfix: Intro text CSS fix to make complete content visible (style.css)
- Bugfix: Optimized CSS styles of menu, if admin bar is active (style.css)
- Enhancement: Masonry grid on archive pages
- Enhancement: Changed post thumbnail position to top on single posts in mobile view (single.php, style.css)

Version 1.0 (17/12/2015)
-----------------------------------------------------------------------------------------------------------------------------------
- Neubau theme release
