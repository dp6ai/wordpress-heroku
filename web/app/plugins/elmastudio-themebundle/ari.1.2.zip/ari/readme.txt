------------------------------------------------------------------------------------------------------------
For detailed documentation and support please visit: http://www.elmastudio.de/wordpress-themes/ari/
------------------------------------------------------------------------------------------------------------

For details of all the theme improvements and bugfixes please see changelog.txt file in theme folder.